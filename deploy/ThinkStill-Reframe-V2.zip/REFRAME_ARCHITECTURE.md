# ThinkStill Reframe V2 architecture

Reframe V2 is a separate Framer component that turns a user's event and interpretation into a short predefined game. Circle continues to handle membership, payments and permissions. The old Reset, Release and Reframe implementations remain reference material and are not replaced by this build.

```mermaid
flowchart TD
    Circle[Circle membership and permissions] --> Framer[Framer Reframe V2 composer]
    Framer --> Safety{Immediate danger or threat?}
    Safety -->|Yes| Guidance[Safety-first guidance]
    Safety -->|No| Request[Transition and compact request]
    Request --> Apps[Google Apps Script web app]
    Apps --> Gemini[Gemini structured analysis]
    Gemini --> Validation[Validate allowed data]
    Apps -->|Unavailable, quota or error| Local[Local fallback analysis]
    Request -->|No URL, timeout or browser failure| Local
    Validation --> Router[Browser game router]
    Validation -->|Invalid response| Local
    Local --> Router
    Router --> Game[One of 15 predefined microgames]
    Game --> Reveal[Caught / Plot Twist / New Frame / Keep]
    Reveal --> Actions[Helpful / Another angle / Save / Share / Next]
    Actions --> Storage[Browser history and Vault]
```

## Source and deployment

- `ThinkStillReframeV2.tsx` is the modular Framer entry point and console.
- `reframe/` contains shared types, language/safety/API logic, games and browser storage.
- `ThinkStill_Reframe_Gemini.gs` is the complete Apps Script backend.
- `dev/` and Vite provide a local React preview with a small Framer property-control adapter.
- `scripts/bundle-framer.mjs` bundles the source through the TypeScript syntax tree into `deploy/ThinkStillReframeV2.tsx` during `npm run build`, preserving types and Framer layout annotations. It independently typechecks the resulting single-file artifact.
- `deploy/ThinkStillReframeV2.tsx` is the complete typed component to paste into a new Framer code file. It imports only React and Framer; no manual module merging is needed.

Completed validation is recorded in `VALIDATION.md`. Local preview checks do not establish successful deployment inside Framer or Google Apps Script. Those services and a real Gemini project need the live checks in `REFRAME_SETUP.txt`.

## Request, analysis and game boundary

The composer accepts free text, capped at 1,800 characters, without requiring a category selection. Submission starts the transition and request immediately. It sends only:

```json
{
  "input": "My manager hasn't replied. She must be unhappy with my work.",
  "session_id": "anonymous-session-id",
  "previous_patterns": [],
  "previous_game_families": []
}
```

The backend reads `GEMINI_API_KEY` from Apps Script Script Properties. `GEMINI_MODEL` is optional; the default is `gemini-2.5-flash-lite`. The model remains configurable so the owner can select a currently available free-tier model without changing client code. There is no paid provider fallback.

Apps Script validates the request, checks lightweight rate limits, calls the Gemini REST API for structured JSON, removes accidental Markdown fences and validates the resulting data. Only the 20 permitted pattern names and 15 permitted game families are accepted. Errors returned to the client omit API keys, sensitive request text and stack traces. The browser validates the response again before routing it.

`ReframeAnalysis` distinguishes event, interpretation, fact, story and unknown; it also contains a grounded reframe, one Keep sentence, permitted pattern/game identifiers and bounded game content. Gemini produces data. The browser never evaluates model JavaScript, React, HTML, CSS or arbitrary URLs. The router chooses from components already shipped with the application.

Each game has the shared `ReframeGameProps` contract: `analysis`, `onComplete`, and optional `onInteraction`. Adding a family means adding its type, permitted backend identifier, router choice and component; the console does not need to become a new game implementation.

## Fallback and safety

When no endpoint is configured, or a request times out, reaches quota, fails network/CORS checks or returns an invalid model response, the browser uses a conservative local analysis. The local engine recognises broad language cues and uses the user's wording. Local games are introduced as the closest pattern; an unsuccessful configured AI request also displays the fallback notice. It preserves uncertainty and does not invent another person's motives.

Client and backend checks identify obvious immediate danger and threats before normal routing. These inputs lead to safety-first guidance rather than cognitive games. Detection is a lightweight text safeguard, not a diagnosis or a guarantee that every dangerous situation can be recognised. The AI prompt also forbids reframing factual mistreatment away. For example, an insult remains the event; the unsupported conclusion that the insult defines the user can be separated from it.

## Console, feedback and storage

The console moves through composition, request/transition, play, completion/reveal and safety states. Vault and history views let the user revisit results without a video dependency. Game completion triggers a restrained eclipse response, then Caught, Plot Twist, New Frame and Keep. Helpful records feedback and momentum; Not Helpful requests another angle using prior pattern/game identifiers, with at most two retries per input.

Long game text has full-text reading controls. Long reveals offer Read Full Frame. The readers open inside the experience, with scrolling contained in the reader rather than extending the game page. This keeps complete event and interpretation text available when the compact stage truncates its preview.

Browser storage keys use `thinkstill.reframe.v2.*`. History is capped at 30 sessions; Vault at 50 personalised saves. Restored data is validated before use and corrupt or unavailable storage fails safely. Stored records contain user input and result text. They remain in the browser/site and do not create an account-synced database. Vault supports removing individual saves; history and Vault each have a separate clear-all action with confirmation. Share creates readable result text and does not expose raw JSON.

The Reset media bridge uses the existing key `__ts_reset_shared_media_v1` and the existing window-name prefix `__ts_reset_shared_media_v1__:`. Theme compatibility uses `__ts_chat_theme_v181`. This keeps the shared bubble/avatar and dark/bright behaviour compatible with the supplied references. The existing bubble-expression assets may be reused by URL; no video manifest, ritual loader, Vimeo or YouTube asset is required for the game loop.

## Hosting and abuse limits

The frontend sends JSON as a `text/plain` POST so the Apps Script request does not require a JSON content-type preflight. Apps Script ContentService serves its response through a Google redirect and does not allow arbitrary CORS response headers. The published Framer browser must be tested against the actual deployed URL; successful server-side or command-line calls alone do not prove browser compatibility.

Apps Script allows up to 4 requests per session per minute, 12 globally per minute and 100 per UTC day. Attempted AI calls count even when they fail. A script lock protects the daily budget, which is maintained in the automatically created `REFRAME_BUDGET_DAY` and `REFRAME_BUDGET_COUNT` Script Properties; minute-level cache limits are best effort. Anonymous session identifiers are forgeable. These are lightweight guards for a public anonymous endpoint, not authenticated membership enforcement. The Gemini key stays server-side, but inputs leave the browser when AI is enabled. Google project eligibility and quotas must be checked by the owner; the implementation does not enable billing or promise current provider prices.

Speech input uses the browser Speech Recognition API when available and requires browser permission. Local automation can check the control and unsupported-browser behaviour; it cannot establish that a real microphone works. Keyboard/touch controls, labelled buttons and reduced-motion handling support accessible use; published-page testing remains necessary for Framer sizing and mobile virtual keyboards.
