import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import vm from 'node:vm'

const source = fs.readFileSync(new URL('../ThinkStill_Reframe_Gemini.gs', import.meta.url), 'utf8')
const safeAnalysis = () => ({
    ok: true,
    event: "My boss hasn't replied.",
    interpretation: 'She must be unhappy with my work.',
    emotion: ['uncertain'],
    primary_pattern: 'Mind Reading',
    secondary_patterns: ['Personalisation'],
    fact: "My boss hasn't replied.",
    story: 'She is unhappy with my work.',
    unknown: 'Why no reply, and what she thinks about my work.',
    reframe: "I know I have no reply. I don't yet know what the silence means.",
    keep: "Missing information isn't proof of criticism.",
    game_family: 'FACT_VS_GUESS',
    game_content: {
        fact_card: "My boss hasn't replied.",
        story_card: 'She is unhappy with my work.',
        unknown_card: 'Why no reply.'
    },
    confidence: 0.91
})
const request = (overrides = {}) => ({
    input: "My boss hasn't replied. She must be unhappy with my work.",
    session_id: 'anon_test_session', previous_patterns: [], previous_game_families: [], ...overrides
})

function runtime(options = {}) {
    const properties = new Map(Object.entries(options.properties ?? { GEMINI_API_KEY: 'server-only-secret' }))
    const cache = new Map()
    const fetchCalls = []
    let locked = false
    let releaseCount = 0
    const scriptProperties = {
        getProperty: key => properties.get(key) ?? null,
        setProperties: object => { for (const [key, value] of Object.entries(object)) properties.set(key, value) }
    }
    const context = vm.createContext({
        ContentService: {
            MimeType: { JSON: 'application/json' },
            createTextOutput(text) { return { text, setMimeType(mime) { this.mime = mime; return this } } }
        },
        PropertiesService: { getScriptProperties: () => scriptProperties },
        CacheService: { getScriptCache: () => ({ get: key => cache.get(key) ?? null, put: (key, value) => cache.set(key, value) }) },
        LockService: { getScriptLock: () => ({
            tryLock: () => { if (options.lockFail) return false; assert.equal(locked, false); locked = true; return true },
            releaseLock: () => { assert.equal(locked, true); locked = false; releaseCount++ }
        }) },
        UrlFetchApp: { fetch(url, config) {
            assert.equal(locked, false, 'network call must not hold the shared quota lock')
            fetchCalls.push({ url, config })
            if (options.throwFetch) throw new Error('Provider diagnostic contains server-only-secret and sensitive text')
            return {
                getResponseCode: () => options.status ?? 200,
                getContentText: () => options.rawResponse ?? JSON.stringify({ candidates: [{
                    finishReason: options.finishReason ?? 'STOP',
                    content: { parts: [{ text: options.modelText ?? JSON.stringify(options.analysis ?? safeAnalysis()) }] }
                }] })
            }
        } },
        console: { log: () => assert.fail('sensitive logging is forbidden'), error: () => assert.fail('sensitive logging is forbidden') },
        Logger: { log: () => assert.fail('sensitive logging is forbidden') }
    })
    vm.runInContext(source, context, { filename: 'ThinkStill_Reframe_Gemini.gs' })
    const post = body => {
        const result = context.doPost({ postData: { type: 'text/plain', contents: typeof body === 'string' ? body : JSON.stringify(body) } })
        assert.equal(result.mime, 'application/json')
        assert.equal(result.text.includes('server-only-secret'), false)
        return JSON.parse(result.text)
    }
    return { context, post, fetchCalls, cache, properties, get releaseCount() { return releaseCount } }
}

test('doPost validates requests before spending quota or invoking Gemini', async t => {
    const cases = {
        'malformed JSON': '{', 'missing body shape': [], 'null body': null,
        'blank input': request({ input: ' \n ' }), 'overlong input': request({ input: 'a'.repeat(1801) }),
        'missing anonymous session': request({ session_id: '' }),
        'unsafe anonymous session characters': request({ session_id: 'session?a=b' }),
        'missing history arrays': { input: 'Something happened.', session_id: 'anon_session' },
        'invented previous pattern': request({ previous_patterns: ['Made-up pattern'] }),
        'too much previous history': request({ previous_game_families: Array(9).fill('FACT_VS_GUESS') }),
        'extra browser metadata': request({ device: 'phone' }),
        'control characters': request({ input: 'hello\u0000world' }),
        'oversized body': 'a'.repeat(8193)
    }
    for (const [name, body] of Object.entries(cases)) await t.test(name, () => {
        const app = runtime()
        assert.equal(app.post(body).ok, false)
        assert.equal(app.fetchCalls.length, 0)
        assert.equal(app.properties.has('REFRAME_BUDGET_COUNT'), false)
    })
})

test('obvious self-harm, medical emergencies and threats bypass Gemini even without a configured key', async t => {
    const cases = [
        ['I am going to kill myself.', 'immediate'],
        ["I'm planning to hurt myself tonight.", 'immediate'],
        ["I overdosed and can't breathe.", 'immediate'],
        ['My daughter is not breathing.', 'immediate'],
        ["My daughter isn't breathing.", 'immediate'],
        ["My son says he's going to kill himself.", 'immediate'],
        ['He is unconscious.', 'immediate'],
        ['I have severe chest pain now.', 'immediate'],
        ['I will seriously hurt him.', 'immediate'],
        ['I want to kill my boss.', 'immediate'],
        ['My partner is hitting me.', 'threat'],
        ['My partner threatened to hit me.', 'threat'],
        ['My partner says he will hurt me tonight.', 'threat']
    ]
    for (const [input, kind] of cases) await t.test(input, () => {
        const app = runtime({ properties: {} })
        const response = app.post(request({ input }))
        assert.equal(response.ok, false)
        assert.equal(response.safety.kind, kind)
        assert.ok(response.safety.title && response.safety.message)
        assert.equal(response.analysis, undefined)
        assert.equal(app.fetchCalls.length, 0)
    })
})

test('explicitly negated self-harm does not erase another emergency clause', () => {
    const app = runtime()
    assert.equal(app.post(request({ input: "I'm not going to kill myself. My manager hasn't replied." })).ok, true)
    assert.equal(app.post(request({ input: "I'm not going to end my life. I just made a mistake at work." })).ok, true)
    assert.equal(app.post(request({ input: 'My boss threatened to fire me. I must be useless.' })).ok, true)
    assert.equal(app.post(request({ input: "I'm not unconscious, and have no severe chest pain. I feel anxious about tomorrow." })).ok, true)
    const result = app.post(request({ input: "I'm not going to kill myself, but my sister is not breathing." }))
    assert.equal(result.safety.kind, 'immediate')
    assert.equal(app.fetchCalls.length, 4)
})

test('historical, fictional and negated descriptions retain the normal flow without hiding present emergencies', async t => {
    const safeInputs = [
        'I overdosed last year and recovered. I am anxious about my meeting.',
        'The film character overdosed. It brought back memories.',
        'The movie character says "I am going to kill myself".',
        'My partner never threatened to hit me. I worry they might leave.',
        'I will kill myself laughing.',
        'If I were to overdose, what would happen?'
    ]
    for (const input of safeInputs) await t.test(input, () => {
        const app = runtime()
        assert.equal(app.post(request({ input })).ok, true)
        assert.equal(app.fetchCalls.length, 1)
    })
    const urgentInputs = [
        'I am watching a film and I will kill myself.',
        'I am not joking, I will kill myself.',
        'I overdosed years ago and now I am going to kill myself.',
        'I want to die.', "I'm suicidal.", 'I will end my life.', 'I am going to take my life.',
        'I took too many pills.'
    ]
    for (const input of urgentInputs) await t.test(input, () => {
        const app = runtime()
        assert.equal(app.post(request({ input })).safety.kind, 'immediate')
        assert.equal(app.fetchCalls.length, 0)
    })
})

test('colloquial intent, explicit methods, short emergencies and independent current violence override the provider', async t => {
    const cases = [
        ["I'm gonna hurt myself.", 'immediate'],
        ['I wanna harm someone.', 'immediate'],
        ['I will harm someone.', 'immediate'],
        ['I am going to slit my wrists.', 'immediate'],
        ['I plan to jump off a bridge.', 'immediate'],
        ['I swallowed a whole bottle of pills.', 'immediate'],
        ['Severe chest pain', 'immediate'],
        ['Not breathing', 'immediate'],
        ['Unconscious', 'immediate'],
        ['I will kill my\u202Eself.', 'immediate'],
        ["He'll hit me.", 'threat'],
        ['He never threatened to hit me, he is hitting me now.', 'threat'],
        ['I did not say he threatened me, my partner keeps choking me.', 'threat']
    ]
    for (const [input, kind] of cases) await t.test(input, () => {
        const app = runtime({ properties: {} })
        const response = app.post(request({ input }))
        assert.equal(response.safety.kind, kind)
        assert.equal(response.analysis, undefined)
        assert.equal(app.fetchCalls.length, 0)
    })
})

test('valid analysis uses current REST JSON schema and sends only situation data to Gemini', () => {
    const app = runtime()
    const response = app.post(request())
    assert.deepEqual(response, { ok: true, analysis: safeAnalysis() })
    assert.equal(app.fetchCalls.length, 1)
    const { url, config } = app.fetchCalls[0]
    assert.equal(url, 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent')
    assert.equal(url.includes('server-only-secret'), false)
    assert.equal(config.headers['x-goog-api-key'], 'server-only-secret')
    assert.equal(config.validateHttpsCertificates, true)
    assert.equal(config.followRedirects, false)
    const payload = JSON.parse(config.payload)
    const situation = JSON.parse(payload.contents[0].parts[0].text)
    assert.deepEqual(Object.keys(situation), ['input', 'previous_patterns', 'previous_game_families'])
    assert.equal(payload.generationConfig.responseMimeType, 'application/json')
    const schema = payload.generationConfig.responseJsonSchema
    assert.equal(schema.type, 'object')
    assert.equal(schema.additionalProperties, false)
    assert.ok(schema.properties.primary_pattern.enum.includes('Mind Reading'))
    assert.ok(schema.properties.game_family.enum.includes('FACT_VS_GUESS'))
    assert.equal(schema.properties.game_content.properties.choices.items.properties.role.enum.includes('grounded'), true)
    assert.ok(payload.systemInstruction.parts[0].text.includes('Never minimise actual mistreatment'))
    assert.equal(app.properties.get('REFRAME_BUDGET_COUNT'), '1')
    assert.equal(app.releaseCount, 1)
})

test('model override stays on the fixed Google API host', () => {
    const app = runtime({ properties: { GEMINI_API_KEY: 'server-only-secret', GEMINI_MODEL: 'gemini-3.1-flash-lite' } })
    assert.equal(app.post(request()).ok, true)
    assert.match(app.fetchCalls[0].url, /\/gemini-3\.1-flash-lite:generateContent$/)
    const unsafe = runtime({ properties: { GEMINI_API_KEY: 'server-only-secret', GEMINI_MODEL: 'https://evil.invalid/?key=' } })
    assert.equal(unsafe.post(request()).ok, false)
    assert.equal(unsafe.fetchCalls.length, 0)
})

test('accepts only a complete optional Markdown JSON fence', () => {
    const good = runtime({ modelText: '```json\n' + JSON.stringify(safeAnalysis()) + '\n```' })
    assert.equal(good.post(request()).ok, true)
    const prose = runtime({ modelText: 'Here is your answer:\n```json\n' + JSON.stringify(safeAnalysis()) + '\n```' })
    assert.equal(prose.post(request()).ok, false)
})

test('malformed or unsafe Gemini output fails closed across nested fields', async t => {
    const cases = {
        'invented pattern': a => { a.primary_pattern = 'Definitely wrong' },
        'unknown game': a => { a.game_family = 'ARBITRARY_CODE' },
        'incompatible game': a => { a.game_family = 'PEEL_LABEL' },
        'missing fact': a => { delete a.fact },
        'blank frame': a => { a.reframe = ' ' },
        'long keep': a => { a.keep = 'k'.repeat(181) },
        'long fact': a => { a.fact = 'f'.repeat(421) },
        'numeric strings': a => { a.confidence = '0.9' },
        'invalid confidence': a => { a.confidence = 1.1 },
        'repeated primary secondary': a => { a.secondary_patterns = ['Mind Reading'] },
        'duplicate secondary': a => { a.secondary_patterns = ['Personalisation', 'Personalisation'] },
        'invalid emotion array': a => { a.emotion = [42] },
        'unknown root field': a => { a.code = 'alert(1)' },
        'custom game field': a => { a.game_content.custom = { url: 'https://evil.invalid' } },
        'HTML text': a => { a.reframe = '<script>doSomething()</script>' },
        'arbitrary URL': a => { a.keep = 'Visit https://evil.invalid' },
        'executable JavaScript': a => { a.keep = 'const action = () => alert(1)' },
        'text injection controls': a => { a.fact += '\u202E' },
        'invalid choice role': a => { a.game_content.choices = [{ id: 'a', text: 'Fact', role: 'execute' }, { id: 'b', text: 'Story' }] },
        'duplicate choice ids': a => { a.game_content.choices = [{ id: 'a', text: 'Fact' }, { id: 'a', text: 'Story' }] },
        'HTML choice id': a => { a.game_content.choices = [{ id: '<a>', text: 'Fact' }, { id: 'b', text: 'Story' }] },
        'overlong choices': a => { a.game_content.choices = Array.from({ length: 9 }, (_, id) => ({ id: String(id), text: 'Choice' })) },
        'incorrect chain scalar': a => { a.game_content.chain_items = ['A', 1] },
        'overlong chain': a => { a.game_content.chain_items = Array(7).fill('A') },
        'out of bounds scale': a => { a.game_content.scale_target = 101 },
        'invalid control boolean': a => { a.game_content.control_items = [{ text: 'My response', controllable: 'yes' }, { text: 'The reply', controllable: false }] },
        'invalid optional influence': a => { a.game_content.control_items = [{ text: 'My response', controllable: true, influence: 1 }, { text: 'The reply', controllable: false }] },
        'out of bounds responsibility': a => { a.game_content.responsibility_items = [{ text: 'My part', weight: -1 }, { text: 'Unknown' }] },
        'unknown nested responsibility field': a => { a.game_content.responsibility_items = [{ text: 'My part', callback: 'fn' }, { text: 'Unknown' }] },
        'analysis is not marked valid': a => { a.ok = false }
    }
    for (const [name, mutate] of Object.entries(cases)) await t.test(name, () => {
        const analysis = safeAnalysis()
        mutate(analysis)
        const app = runtime({ analysis })
        const response = app.post(request())
        assert.equal(response.ok, false)
        assert.equal(response.analysis, undefined)
        assert.ok(response.error)
    })
})

test('valid nested game data preserves boolean and numerical boundary values as data', () => {
    const analysis = safeAnalysis()
    analysis.primary_pattern = 'Control Error'
    analysis.secondary_patterns = []
    analysis.game_family = 'CONTROL_SORTER'
    analysis.confidence = 0
    analysis.game_content = {
        fact_card: analysis.fact, story_card: analysis.story, unknown_card: analysis.unknown,
        prediction_text: 'The silence means criticism.', label_text: 'Incompetent',
        choices: [{ id: 'known', text: analysis.fact, role: 'fact' }, { id: 'grounded', text: analysis.reframe, role: 'grounded' }],
        chain_items: [analysis.fact, analysis.story], scale_start: 0, scale_target: 100,
        control_items: [{ text: 'My next response', controllable: true }, { text: 'When a reply arrives', controllable: false, influence: true }],
        responsibility_items: [{ text: 'My next action', weight: 0 }, { text: 'What remains unknown', weight: 100 }]
    }
    const app = runtime({ analysis })
    assert.deepEqual(app.post(request()).analysis, analysis)
})

test('provider quota, truncation, exceptions and invalid transport responses return safe fallback errors', async t => {
    const cases = [
        { status: 429, rawResponse: 'server-only-secret stacktrace and input' },
        { status: 500 }, { throwFetch: true }, { rawResponse: '{' },
        { rawResponse: 'x'.repeat(65537) }, { modelText: 'x'.repeat(16001) },
        { finishReason: 'MAX_TOKENS' }, { finishReason: 'SAFETY' },
        { rawResponse: JSON.stringify({ promptFeedback: { blockReason: 'SAFETY' }, candidates: [] }) },
        { rawResponse: JSON.stringify({ candidates: [{ finishReason: 'STOP', content: { parts: [{ functionCall: { name: 'execute' } }] } }] }) },
        { rawResponse: JSON.stringify({ candidates: [] }) }
    ]
    for (const options of cases) await t.test(JSON.stringify(Object.keys(options)), () => {
        const app = runtime(options)
        const response = app.post(request())
        assert.equal(response.ok, false)
        assert.equal(response.error, app.context.TS_FALLBACK_ERROR)
        assert.equal(app.fetchCalls.length, 1, 'no retry to another provider')
        assert.equal(response.analysis, undefined)
    })
})

test('missing key and unavailable lock fail safely before any provider request', () => {
    for (const options of [{ properties: {} }, { lockFail: true }]) {
        const app = runtime(options)
        assert.equal(app.post(request()).ok, false)
        assert.equal(app.fetchCalls.length, 0)
        assert.equal(app.properties.has('REFRAME_BUDGET_COUNT'), false)
    }
})

test('anonymous session and global minute budgets conserve provider quota', () => {
    const app = runtime()
    for (let i = 0; i < 4; i++) assert.equal(app.post(request()).ok, true)
    assert.equal(app.post(request()).ok, false)
    assert.equal(app.fetchCalls.length, 4)
    for (let i = 0; i < 8; i++) assert.equal(app.post(request({ session_id: `another_session_${i}` })).ok, true)
    assert.equal(app.post(request({ session_id: 'another_session_final' })).ok, false)
    assert.equal(app.fetchCalls.length, 12)
})

test('persistent daily budget remains enforced even when cache entries are evicted', () => {
    const today = new Date().toISOString().slice(0, 10)
    const app = runtime({ properties: { GEMINI_API_KEY: 'server-only-secret', REFRAME_BUDGET_DAY: today, REFRAME_BUDGET_COUNT: '99' } })
    assert.equal(app.post(request()).ok, true)
    app.cache.clear()
    assert.equal(app.post(request({ session_id: 'another_session' })).ok, false)
    assert.equal(app.fetchCalls.length, 1)
    assert.equal(app.properties.get('REFRAME_BUDGET_COUNT'), '100')
    assert.equal(app.releaseCount, 2)
})

test('daily budget resets at UTC date boundary and safety remains accessible after quota exhaustion', () => {
    const app = runtime({ properties: { GEMINI_API_KEY: 'server-only-secret', REFRAME_BUDGET_DAY: '2000-01-01', REFRAME_BUDGET_COUNT: '100' } })
    assert.equal(app.post(request()).ok, true)
    assert.equal(app.properties.get('REFRAME_BUDGET_COUNT'), '1')
    app.properties.set('REFRAME_BUDGET_COUNT', '100')
    assert.equal(app.post(request()).ok, false)
    assert.equal(app.post(request({ input: 'My partner threatened to hit me.' })).safety.kind, 'threat')
    assert.equal(app.fetchCalls.length, 1)
})
