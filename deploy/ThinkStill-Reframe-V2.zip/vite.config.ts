import { defineConfig } from 'vite'
import { fileURLToPath } from 'node:url'
export default defineConfig({
    resolve: { alias: { framer: fileURLToPath(new URL('./dev/framer.ts', import.meta.url)) } },
    server: { port: 5173, strictPort: true },
    build: { outDir: 'dist' },
})
