import assert from "node:assert/strict"
import { afterEach, beforeEach, test } from "node:test"
import { localAnalysis } from "../reframe/engine"
import {
    loadHistory, loadMomentum, loadVault, saveHistory, saveMomentum, saveVault, shareText, toSaved,
} from "../reframe/storage"
import type { ReframeSession } from "../reframe/types"

const PREFIX = "thinkstill.reframe.v2"
let values: Map<string, string>
const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window")

function setWindow(value: unknown): void {
    Object.defineProperty(globalThis, "window", { configurable: true, value })
}

function example(id = "session-1"): ReframeSession {
    const input = "My boss has not replied. She thinks my work is bad."
    const analysis = localAnalysis(input)
    return {
        id, input, analysis, gameFamily: analysis.game_family,
        completed: true, createdAt: 1_700_000_000_000, source: "local",
    }
}

beforeEach(() => {
    values = new Map()
    setWindow({ localStorage: {
        getItem: (key: string) => values.get(key) ?? null,
        setItem: (key: string, value: string) => values.set(key, value),
    } })
})

afterEach(() => {
    if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow)
    else Reflect.deleteProperty(globalThis, "window")
})

test("history and vault round-trip complete personalized results with separate bounded keys", () => {
    const history = Array.from({ length: 60 }, (_, index) => example(`session-${index}`))
    assert.equal(saveHistory(history), true)
    assert.equal(saveVault(history.map(toSaved)), true)
    assert.equal(loadHistory().length, 30)
    assert.equal(loadVault().length, 50)
    assert.deepEqual(loadHistory()[0], history[0])
    assert.deepEqual(loadVault()[0], toSaved(history[0]))
    assert.deepEqual([...values.keys()], [`${PREFIX}.history`, `${PREFIX}.vault`])
})

test("restored history rejects tampered analysis, game family, source, identity and timestamp", () => {
    const good = example()
    values.set(`${PREFIX}.history`, JSON.stringify([
        { ...good, id: "bad-pattern", analysis: { ...good.analysis, primary_pattern: "made up" } },
        { ...good, id: "bad-game", gameFamily: "MADE_UP" },
        { ...good, id: "bad-source", source: "trusted-ish" },
        { ...good, id: "bad-time", createdAt: -1 },
        { ...good, id: " " },
        { ...good, id: "bad-complete", completed: "yes" },
        { ...good, id: "bad-analysis", analysis: null },
        good,
    ]))
    assert.deepEqual(loadHistory(), [good])
})

test("unknown analysis game content cannot be restored from local storage", () => {
    const good = example()
    values.set(`${PREFIX}.history`, JSON.stringify([
        { ...good, analysis: { ...good.analysis, game_content: { choices: [{ text: "tampered", role: "invented" }] } } },
    ]))
    assert.deepEqual(loadHistory(), [])
})

test("vault enforces known patterns, game family and bounded text, and deduplicates IDs", () => {
    const good = toSaved(example())
    values.set(`${PREFIX}.vault`, JSON.stringify([
        { ...good, id: "bad-primary", primaryPattern: "Fake" },
        { ...good, id: "bad-secondary", secondaryPatterns: ["Fake"] },
        { ...good, id: "bad-game", gameFamily: "Fake" },
        { ...good, id: "bad-time", createdAt: "yesterday" },
        { ...good, id: "bad-text", reframe: { message: "bad" } },
        { ...good, input: "i".repeat(10_000), fact: "f".repeat(10_000), keep: "k".repeat(10_000) },
        good,
    ]))
    const restored = loadVault()
    assert.equal(restored.length, 1)
    assert.equal(restored[0].input.length, 1_800)
    assert.equal(restored[0].fact.length, 420)
    assert.equal(restored[0].keep.length, 180)
})

test("vault rejects known games incompatible with the pattern and more than three secondary patterns", () => {
    const good = toSaved(example())
    values.set(`${PREFIX}.vault`, JSON.stringify([
        { ...good, id: "mismatched-game", primaryPattern: "Mind Reading", gameFamily: "PEEL_LABEL" },
        { ...good, id: "too-many-patterns", secondaryPatterns: [
            "Fortune Telling", "Catastrophising", "Emotional Reasoning", "Overgeneralising",
        ] },
        good,
    ]))
    assert.deepEqual(loadVault(), [good])
})

test("history caps input without retaining unknown record fields", () => {
    const good = example()
    assert.equal(saveHistory([{ ...good, input: "i".repeat(10_000), extra: "private" } as ReframeSession]), true)
    const restored = loadHistory()[0]
    assert.equal(restored.input.length, 1_800)
    assert.equal("extra" in restored, false)
})

test("malformed, missing, oversized and non-array storage stays safe", () => {
    assert.deepEqual(loadHistory(), [])
    assert.deepEqual(loadVault(), [])
    for (const raw of ["{", "null", "{}", "true", "[]".repeat(1_000_001)]) {
        values.set(`${PREFIX}.history`, raw)
        values.set(`${PREFIX}.vault`, raw)
        assert.deepEqual(loadHistory(), [])
        assert.deepEqual(loadVault(), [])
    }
})

test("server rendering and blocked private-mode storage do not throw", () => {
    Reflect.deleteProperty(globalThis, "window")
    assert.deepEqual(loadHistory(), [])
    assert.deepEqual(loadVault(), [])
    assert.equal(loadMomentum(), 0)
    assert.equal(saveHistory([example()]), false)
    assert.equal(saveVault([toSaved(example())]), false)
    assert.equal(saveMomentum(10), false)

    setWindow(Object.defineProperty({}, "localStorage", {
        get() { throw new Error("SecurityError") },
    }))
    assert.deepEqual(loadHistory(), [])
    assert.equal(saveHistory([example()]), false)
    assert.equal(saveMomentum(10), false)

    setWindow({ localStorage: {
        getItem() { throw new Error("SecurityError") },
        setItem() { throw new Error("QuotaExceededError") },
    } })
    assert.deepEqual(loadVault(), [])
    assert.equal(saveVault([toSaved(example())]), false)
    assert.equal(loadMomentum(), 0)
    assert.equal(saveMomentum(10), false)
})

test("momentum only restores or writes nonnegative safe integers", () => {
    assert.equal(loadMomentum(), 0)
    assert.equal(saveMomentum(20), true)
    assert.equal(loadMomentum(), 20)
    for (const value of [-1, 1.5, Infinity, NaN, Number.MAX_SAFE_INTEGER + 1]) {
        assert.equal(saveMomentum(value), false)
        assert.equal(loadMomentum(), 20)
    }
    for (const raw of ["null", "{}", '"20"', "-1", "1.5", "not-json"]) {
        values.set(`${PREFIX}.momentum`, raw)
        assert.equal(loadMomentum(), 0)
    }
})

test("saved cards copy taxonomy and sharing provides concise human text without raw input or JSON", () => {
    const current = example()
    const saved = toSaved(current)
    saved.secondaryPatterns.push("Catastrophising")
    assert.notDeepEqual(saved.secondaryPatterns, current.analysis.secondary_patterns)
    const result = shareText(current)
    assert.equal(result, shareText(toSaved(current)))
    assert.match(result, /^THINKSTILL REFRAME\n\nCAUGHT\n/)
    assert.ok(result.includes(current.analysis.fact))
    assert.ok(result.includes(current.analysis.reframe))
    assert.ok(result.includes(current.analysis.keep))
    assert.ok(!result.includes(current.input))
    assert.ok(!result.includes('"game_family"'))
})
