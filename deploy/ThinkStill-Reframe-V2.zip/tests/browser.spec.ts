import { expect, test } from "@playwright/test"
import type { Locator, Page } from "@playwright/test"
import { compatibleGames, localAnalysis, validateAnalysis } from "../reframe/engine"
import { GAME_FAMILIES, PATTERNS } from "../reframe/types"
import type { ReframeAnalysis, ReframeGameFamily } from "../reframe/types"

const AI_URL = "https://script.google.com/macros/s/test-deployment/exec"
const AI_PAGE = `/?ai=${encodeURIComponent(AI_URL)}`
const composer = (page: Page) => page.getByRole("textbox", { name: "What happened and what are you telling yourself it means?" })
const INPUT = "My boss hasn't replied to my presentation. She must be unhappy with my work."
const pageErrors = new WeakMap<Page, string[]>()
test.beforeEach(({ page }) => {
    const errors: string[] = []
    pageErrors.set(page, errors)
    page.on("pageerror", error => errors.push(error.message))
})
test.afterEach(({ page }) => expect(pageErrors.get(page)).toEqual([]))
const GAME_NAMES: Record<ReframeGameFamily, string> = {
    FACT_VS_GUESS: "Fact vs guess", CRYSTAL_BALL: "Crystal ball", DISASTER_CHAIN: "Disaster chain",
    MISSING_MIDDLE: "The missing middle", ONE_NOT_ALWAYS: "One ≠ always", FEELING_NOT_EVIDENCE: "Feeling ≠ evidence",
    PEEL_LABEL: "Peel the label", WRONG_SCOREBOARD: "Wrong scoreboard", SHOULD_SHREDDER: "Should shredder",
    CONTROL_SORTER: "Control sorter", RESPONSIBILITY_PIE: "Responsibility pie", MYSTERY_BOX: "Mystery box",
    FILTER_CLEANER: "Filter cleaner", INTENT_MACHINE: "Intent machine", REJECTION_FILL: "Rejection fill-in",
}

// Browser fixtures are structured data accepted by the real response validator.
// They exercise UI families independently of nondeterministic model routing.
function analysisFor(family: ReframeGameFamily, input = INPUT): ReframeAnalysis {
    const base = localAnalysis(input)
    const primary = PATTERNS.find(pattern => compatibleGames(pattern).includes(family))!
    const analysis: ReframeAnalysis = {
        ...base, primary_pattern: primary, secondary_patterns: [], game_family: family,
        emotion: ["anxious"], confidence: 0.9,
        reframe: "My boss's silence leaves her view of my presentation unknown; I can ask for feedback.",
        keep: "A silent reply cannot review my presentation.",
        game_content: {
            fact_card: base.fact, story_card: base.story, unknown_card: base.unknown,
            prediction_text: base.story, label_text: "Terrible at my presentation", scale_start: 0,
            chain_items: [base.story, "This one presentation will ruin every future opportunity."],
            choices: [
                { id: "story", text: base.story, role: "story" },
                { id: "grounded", text: "My boss's opinion is unknown until I have feedback.", role: "grounded" },
            ],
            control_items: [
                { text: "My wording when asking for feedback", controllable: true },
                { text: "A useful follow-up conversation", controllable: false, influence: true },
                { text: "When my boss replies", controllable: false },
            ],
            responsibility_items: [{ text: "My preparation", weight: 50 }, { text: "Missing feedback", weight: 50 }],
        },
    }
    const validated = validateAnalysis(analysis)
    if (!validated) throw new Error(`Invalid browser fixture: ${family}`)
    return validated
}

async function mockAnalysis(page: Page, analysis: ReframeAnalysis) {
    await page.route(AI_URL, route => route.fulfill({
        status: 200, headers: { "Access-Control-Allow-Origin": "*" },
        contentType: "application/json", body: JSON.stringify({ ok: true, analysis }),
    }))
}

async function submit(page: Page, input = INPUT) {
    await composer(page).fill(input)
    await page.getByRole("button", { name: "Catch this thought" }).click()
}

async function noHorizontalOverflow(page: Page) {
    const sizes = await page.evaluate(() => ({
        viewport: window.innerWidth, document: document.documentElement.scrollWidth,
        console: document.querySelector(".ts-reframe-v2")!.scrollWidth,
        width: document.querySelector(".ts-reframe-v2")!.clientWidth,
    }))
    expect(sizes.document).toBeLessThanOrEqual(sizes.viewport + 1)
    expect(sizes.console).toBeLessThanOrEqual(sizes.width + 1)
}

async function withinStage(page: Page, target: Locator) {
    await expect(target).toBeVisible()
    const box = await target.boundingBox()
    const stage = await page.getByRole("main", { name: "Reframe stage" }).boundingBox()
    expect(box).not.toBeNull()
    expect(stage).not.toBeNull()
    if (!box || !stage) return
    expect(box.x).toBeGreaterThanOrEqual(stage.x - 2)
    expect(box.y).toBeGreaterThanOrEqual(stage.y - 2)
    expect(box.x + box.width).toBeLessThanOrEqual(stage.x + stage.width + 2)
    expect(box.y + box.height).toBeLessThanOrEqual(stage.y + stage.height + 2)
}

async function tap(page: Page, target: Locator) {
    await withinStage(page, target)
    await target.click()
}

async function stillPlaying(page: Page) {
    await expect(page.locator(".ts-phase-playing")).toBeVisible()
    await expect(page.locator(".ts-reveal-layout")).toHaveCount(0)
}

async function completeGame(page: Page, family: ReframeGameFamily, analysis: ReframeAnalysis, checkMistakes = false) {
    const game = page.getByRole("region", { name: GAME_NAMES[family], exact: true })
    await expect(game).toBeVisible()
    await noHorizontalOverflow(page)
    const button = (name: string | RegExp) => game.getByRole("button", { name, exact: typeof name === "string" })
    const choose = () => tap(page, button(analysis.game_content.choices?.find(choice => choice.role === "grounded")?.text || analysis.reframe))
    const rejectChoice = async () => {
        if (!checkMistakes) return
        await tap(page, button(analysis.story))
        await expect(game.locator(".ts-game-feedback")).toBeVisible()
        await stillPlaying(page)
    }
    switch (family) {
        case "FACT_VS_GUESS":
            if (checkMistakes) { await tap(page, button("What I know")); await stillPlaying(page) }
            await tap(page, button("My brain added"))
            await tap(page, button("What I know"))
            await tap(page, button("Still unknown"))
            break
        case "CRYSTAL_BALL":
            await tap(page, button(/^Crack the prediction:/))
            if (checkMistakes) { await tap(page, button("A proven future")); await stillPlaying(page) }
            await tap(page, button("A possible outcome"))
            break
        case "DISASTER_CHAIN":
            for (let count = await button(/^Break unsupported link:/).count(); count > 0; count--) {
                await tap(page, button(/^Break unsupported link:/).first())
            }
            break
        case "MISSING_MIDDLE": {
            const range = game.getByRole("slider")
            await withinStage(page, range)
            await range.focus(); await range.press("ArrowRight")
            await rejectChoice(); await choose()
            break
        }
        case "ONE_NOT_ALWAYS":
            for (const word of await button(/^Remove the generalisation/).all()) await tap(page, word)
            break
        case "FEELING_NOT_EVIDENCE":
            await tap(page, button("Separate the feeling from proof of the conclusion"))
            if (checkMistakes) { await tap(page, button("The feeling proves it")); await stillPlaying(page) }
            await tap(page, button("Real feeling. Unconfirmed meaning."))
            break
        case "PEEL_LABEL": await tap(page, button(/^Peel away the label:/)); break
        case "WRONG_SCOREBOARD":
            await tap(page, button("Remove this comparison")); await stillPlaying(page)
            await tap(page, button("Return to my own evidence")); break
        case "SHOULD_SHREDDER":
            await tap(page, button("I want…")); await stillPlaying(page)
            await tap(page, button("Keep the value, loosen the rule")); break
        case "CONTROL_SORTER":
            if (checkMistakes) { await tap(page, button("Not my control")); await stillPlaying(page) }
            for (const item of analysis.game_content.control_items || [{ controllable: true }, { controllable: false }]) {
                await tap(page, button(item.controllable ? "My control" : "influence" in item && item.influence ? "My influence" : "Not my control"))
            }
            break
        case "RESPONSIBILITY_PIE": {
            await expect(button("Review each factor first")).toBeDisabled()
            for (const factor of await game.locator(".ts-game-factor").all()) {
                await tap(page, factor)
                const detail = page.getByRole("dialog")
                if (await detail.isVisible()) await detail.getByRole("button", { name: "Back to the game", exact: true }).click()
            }
            const range = game.getByRole("slider")
            await withinStage(page, range); await range.focus(); await range.press("ArrowRight")
            await tap(page, button("Keep this considered estimate")); break
        }
        case "MYSTERY_BOX":
            await tap(page, button(/^Remove the assumed bad outcome:/))
            if (checkMistakes) { await tap(page, button("The answer is now certain")); await stillPlaying(page) }
            await tap(page, button("Leave room for unknown")); break
        case "FILTER_CLEANER":
            await tap(page, button("Clear filter")); await rejectChoice(); await choose(); break
        case "INTENT_MACHINE":
            await tap(page, button("Open the brain's machine")); await stillPlaying(page)
            await tap(page, button(/^Remove assumed intent:/)); break
        case "REJECTION_FILL":
            await tap(page, button("Erase the automatic ending")); await rejectChoice(); await choose(); break
    }
    await expect(page.locator(".ts-phase-reveal")).toBeVisible()
    await expect(page.locator(".ts-caught h2")).toHaveText(analysis.primary_pattern)
    await expect(page.locator(".ts-new-frame p")).toHaveText(analysis.reframe)
    await expect(page.locator(".ts-keep p")).toHaveText(analysis.keep)
    await noHorizontalOverflow(page)
}

const viewports = [
    { name: "desktop", width: 1280, height: 850 },
    { name: "mobile", width: 375, height: 812 },
    { name: "narrow mobile", width: 320, height: 640 },
]

const longText = (opening: string, limit = 420) => `${opening} ${"The information about this situation is incomplete, so the larger meaning remains open. ".repeat(8)}`.slice(0, limit).replace(/\s$/, ".")

test.describe("long AI content on narrow mobile", () => {
    test.use({ viewport: { width: 320, height: 640 } })
    for (const family of GAME_FAMILIES) {
        test(`${family}: valid maximum text keeps actions accessible`, async ({ page }) => {
            const base = analysisFor(family)
            const fact = longText("My boss has not replied to my presentation.")
            const story = longText("She must be unhappy with every presentation I make.")
            const unknown = longText("Her reason for not replying is unknown.")
            const reframe = longText("I can ask my boss for feedback while leaving her opinion open.")
            const analysis: ReframeAnalysis = {
                ...base, event: fact, interpretation: story, fact, story, unknown, reframe,
                keep: longText("Missing feedback is not a review of my presentation.", 180),
                game_content: {
                    ...base.game_content, fact_card: fact, story_card: story, unknown_card: unknown,
                    label_text: story, prediction_text: story,
                    chain_items: [story, longText("This silence will ruin all future opportunities.")],
                    choices: [{ id: "story", role: "story", text: story }, { id: "grounded", role: "grounded", text: reframe }],
                    control_items: [
                        { text: longText("I can choose the words in my next request for feedback."), controllable: true },
                        { text: longText("I can influence a useful conversation without deciding its outcome."), controllable: false, influence: true },
                        { text: longText("I cannot decide when my boss replies."), controllable: false },
                    ],
                    responsibility_items: [{ text: longText("My preparation."), weight: 50 }, { text: longText("Missing feedback."), weight: 50 }],
                },
            }
            expect(validateAnalysis(analysis)).not.toBeNull()
            await mockAnalysis(page, analysis)
            await page.goto(AI_PAGE)
            await submit(page)
            const readComplete = family === "RESPONSIBILITY_PIE"
                ? page.locator(".ts-game-factor").nth(1)
                : page.getByRole("button", { name: /^Read complete / }).first()
            await expect(readComplete).toBeVisible()
            await withinStage(page, readComplete)
            await readComplete.click()
            await expect(page.getByRole("dialog").locator("p")).toHaveText(/.{420}/)
            await page.getByRole("dialog").getByRole("button", { name: "Back to the game", exact: true }).click()
            await expect(page.getByRole("dialog")).not.toBeVisible()
            await completeGame(page, family, analysis)
            await withinStage(page, page.getByRole("button", { name: "Save reframe", exact: true }))
            const readFull = page.getByRole("button", { name: /Read full frame/i })
            await withinStage(page, readFull)
            await readFull.click()
            await expect(page.getByRole("dialog")).toContainText(reframe)
            await expect(page.getByRole("dialog")).toContainText(analysis.keep)
            await page.getByRole("dialog").press("Escape")
            await expect(page.getByRole("dialog")).toHaveCount(0)
        })
    }
})

for (const viewport of viewports) {
    test.describe(viewport.name, () => {
        test.use({ viewport: { width: viewport.width, height: viewport.height } })
        for (const family of GAME_FAMILIES) {
            test(`${family}: cognitive action completes into personalised reveal`, async ({ page }) => {
                const analysis = analysisFor(family)
                await mockAnalysis(page, analysis)
                await page.goto(AI_PAGE)
                await submit(page)
                await expect(page.getByText("Your words. A new angle.", { exact: true })).toBeVisible()
                if (family === "FACT_VS_GUESS") await page.screenshot({ path: `/tmp/thinkstill-${viewport.name.replace(/ /g, "-")}-game.png` })
                await completeGame(page, family, analysis, true)
                if (family === "FACT_VS_GUESS") await page.screenshot({ path: `/tmp/thinkstill-${viewport.name.replace(/ /g, "-")}-reveal.png` })
                await withinStage(page, page.getByRole("button", { name: "Save reframe", exact: true }))
                expect(await page.evaluate(() => JSON.parse(localStorage.getItem("thinkstill.reframe.v2.history") || "[]").length)).toBe(1)
            })
        }
    })
}

test.describe("bright theme", () => {
    test.use({ viewport: { width: 375, height: 812 } })
    for (const family of GAME_FAMILIES) {
        test(`${family}: bright game and reveal stay usable`, async ({ page }) => {
            const analysis = analysisFor(family)
            await mockAnalysis(page, analysis)
            await page.goto(`${AI_PAGE}&theme=bright`)
            await expect(page.locator(".ts-theme-bright")).toBeVisible()
            await submit(page)
            await completeGame(page, family, analysis)
        })
    }
})

for (const family of ["PEEL_LABEL", "FILTER_CLEANER"] as const) {
    test(`${family}: pointer swipe performs the physical move`, async ({ page }) => {
        const analysis = analysisFor(family)
        await mockAnalysis(page, analysis)
        await page.goto(AI_PAGE)
        await submit(page)
        const target = page.locator(family === "PEEL_LABEL" ? ".ts-game-sticker" : ".ts-game-filter-frame")
        await withinStage(page, target)
        const box = (await target.boundingBox())!
        const start = box.x + box.width * 0.2
        const end = box.x + box.width * 0.8
        const y = box.y + box.height * 0.5
        await page.mouse.move(start, y); await page.mouse.down()
        await page.mouse.move(end, y, { steps: 6 }); await page.mouse.up()
        if (family === "FILTER_CLEANER") {
            await expect(page.locator(".ts-game-filter-clear")).toBeVisible()
            await stillPlaying(page)
            await tap(page, page.getByRole("button", { name: analysis.game_content.choices![1].text, exact: true }))
        }
        await expect(page.locator(".ts-phase-reveal")).toBeVisible()
        await expect(page.locator(".ts-new-frame p")).toHaveText(analysis.reframe)
    })
}

test("composer preserves line breaks, enforces limit, and sends using Enter", async ({ page }) => {
    await page.goto("/")
    await expect(page.getByRole("button", { name: "Catch this thought" })).toBeDisabled()
    await composer(page).fill("x".repeat(1_805))
    expect((await composer(page).inputValue()).length).toBe(1_800)
    await composer(page).fill("My boss has not replied.")
    await composer(page).press("End")
    await composer(page).press("Shift+Enter")
    await composer(page).pressSequentially("She must be unhappy with my work.")
    await expect(composer(page)).toHaveValue("My boss has not replied.\nShe must be unhappy with my work.")
    await expect(page.locator(".ts-phase-idle")).toBeVisible()
    await composer(page).press("Enter")
    await expect(page.getByRole("region", { name: "Fact vs guess", exact: true })).toBeVisible()
})

const briefCases: Array<{ input: string; primary: string; family: ReframeGameFamily; secondary?: string }> = [
    { input: "My boss hasn't replied.\nShe must be unhappy with my work.", primary: "Mind Reading", secondary: "Personalisation", family: "FACT_VS_GUESS" },
    { input: "I made one mistake in the presentation.\nI'm terrible at my job.", primary: "Self-Labelling", family: "PEEL_LABEL" },
    { input: "My boyfriend hasn't messaged today.\nHe's probably losing interest.", primary: "Mind Reading", secondary: "Rejection Story", family: "REJECTION_FILL" },
    { input: "I feel anxious, so something bad must be about to happen.", primary: "Emotional Reasoning", secondary: "Fortune Telling", family: "FEELING_NOT_EVIDENCE" },
    { input: "I got rejected from one job.\nI'm never going to get hired.", primary: "Overgeneralising", secondary: "Fortune Telling", family: "ONE_NOT_ALWAYS" },
    { input: "My partner called me useless.\nMaybe they're right.", primary: "Self-Labelling", family: "PEEL_LABEL" },
    { input: "My friend cancelled dinner.\nNobody wants me around.", primary: "Overgeneralising", secondary: "Rejection Story", family: "ONE_NOT_ALWAYS" },
    { input: "I don't know whether I got the job.\nThat probably means I failed.", primary: "Uncertainty Intolerance", secondary: "Fortune Telling", family: "MYSTERY_BOX" },
]

briefCases.forEach((entry, index) => {
    test(`brief case ${index + 1}: local analysis uses this situation`, async ({ page }) => {
        let calls = 0
        await page.route(AI_URL, route => { calls++; return route.abort() })
        await page.goto("/")
        await submit(page, entry.input)
        const analysis = localAnalysis(entry.input)
        expect(analysis.primary_pattern).toBe(entry.primary)
        expect(analysis.game_family).toBe(entry.family)
        if (entry.secondary) expect(analysis.secondary_patterns).toContain(entry.secondary)
        await completeGame(page, analysis.game_family, analysis)
        expect(calls).toBe(0)
        const history = await page.evaluate(() => JSON.parse(localStorage.getItem("thinkstill.reframe.v2.history") || "[]"))
        expect(history[0].input).toBe(entry.input)
        if (index === 5) expect(history[0].analysis.fact).toBe("My partner called me useless.")
    })
})

for (const [input, title] of [
    ["I am going to kill myself.", "Safety comes first"],
    ["I overdosed and can't breathe.", "Safety comes first"],
    ["My partner threatened to hit me.", "Take the threat seriously"],
]) {
    test(`safety: ${input}`, async ({ page }) => {
        let calls = 0
        await page.route(AI_URL, route => { calls++; return route.abort() })
        await page.goto(AI_PAGE)
        await submit(page, input)
        await expect(page.getByRole("heading", { name: title })).toBeVisible()
        await expect(page.locator(".ts-game")).toHaveCount(0)
        expect(calls).toBe(0)
        await page.getByRole("button", { name: "Back to the console" }).click()
        await expect(composer(page)).toHaveValue("")
    })
}

for (const scenario of ["malformed", "invalid-data", "quota", "network-abort", "timeout"] as const) {
    test(`AI ${scenario}: falls back without losing input`, async ({ page }) => {
        if (scenario === "timeout") await page.clock.install()
        await page.route(AI_URL, route => {
            if (scenario === "network-abort") return route.abort("failed")
            if (scenario === "timeout") return new Promise<void>(() => {})
            return route.fulfill({
                status: scenario === "quota" ? 429 : 200,
                headers: { "Access-Control-Allow-Origin": "*" }, contentType: "application/json",
                body: scenario === "malformed" ? "{broken JSON" : scenario === "quota" ? JSON.stringify({ ok: false, error: "quota" }) : JSON.stringify({ ok: true, analysis: { ...analysisFor("FACT_VS_GUESS"), game_family: "UNSAFE_UNLISTED_GAME" } }),
            })
        })
        await page.goto(AI_PAGE)
        const request = page.waitForRequest(AI_URL)
        await submit(page)
        await request
        if (scenario === "timeout") await page.clock.fastForward(10_001)
        await expect(page.locator(".ts-fallback-note")).toBeVisible()
        await expect(composer(page)).toHaveValue(INPUT)
        if (scenario === "timeout") await page.clock.resume()
        const analysis = localAnalysis(INPUT)
        await completeGame(page, analysis.game_family, analysis)
    })
}

test("pending request unmount cannot replace a new console", async ({ page }) => {
    let release: (() => void) | undefined
    await page.route(AI_URL, async route => {
        await new Promise<void>(resolve => { release = resolve })
        await route.fulfill({ headers: { "Access-Control-Allow-Origin": "*" }, contentType: "application/json", body: JSON.stringify({ ok: true, analysis: analysisFor("PEEL_LABEL") }) }).catch(() => {})
    })
    await page.goto(AI_PAGE)
    const request = page.waitForRequest(AI_URL)
    await submit(page); await request
    await expect(page.getByRole("status", { name: "Preparing your reframe" })).toBeVisible()
    await page.goto("/")
    release?.()
    await expect(page.locator(".ts-phase-idle")).toBeVisible()
    await expect(composer(page)).toHaveValue("")
})

test("Save, Vault, history navigation, feedback and share fallback persist across reload", async ({ page }) => {
    await page.addInitScript(() => {
        Object.defineProperty(navigator, "share", { configurable: true, value: undefined })
        Object.defineProperty(navigator, "clipboard", { configurable: true, value: undefined })
    })
    const first = analysisFor("FACT_VS_GUESS")
    await mockAnalysis(page, first)
    await page.goto(AI_PAGE)
    await submit(page); await completeGame(page, first.game_family, first)
    await page.getByRole("button", { name: "Helpful", exact: true }).click()
    await expect(page.getByRole("button", { name: "Helpful", exact: true })).toHaveAttribute("aria-pressed", "true")
    await page.getByRole("button", { name: "Save reframe", exact: true }).click()
    await expect(page.getByRole("button", { name: "Frame saved", exact: true })).toHaveAttribute("aria-pressed", "true")
    await page.getByRole("button", { name: "Share reframe", exact: true }).click()
    await expect(page.getByRole("textbox", { name: "Frame text to copy" })).toHaveValue(new RegExp(first.reframe.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")))
    await page.reload()
    await page.getByRole("button", { name: "Open Vault", exact: true }).first().click()
    await expect(page.getByRole("dialog")).toContainText(first.keep)
    await page.getByRole("dialog").locator(".ts-entry").click()
    await expect(page.locator(".ts-new-frame p")).toHaveText(first.reframe)
    await page.getByRole("button", { name: "New reframe" }).click()
    const secondInput = "My presentation got one difficult question. I am a failure."
    const second = { ...analysisFor("PEEL_LABEL", secondInput), keep: "A hard question is one moment, not my identity." }
    await page.unroute(AI_URL)
    await mockAnalysis(page, second)
    await submit(page, secondInput); await completeGame(page, second.game_family, second)
    await page.getByRole("button", { name: "Previous completed reframe" }).click()
    await expect(page.locator(".ts-keep p")).toHaveText(first.keep)
    await page.getByRole("button", { name: "Next completed reframe" }).click()
    await expect(page.locator(".ts-keep p")).toHaveText(second.keep)
    await page.getByRole("button", { name: "Not helpful, try another angle" }).click()
    await expect(page.getByRole("region", { name: "The missing middle", exact: true })).toBeVisible()
    await completeGame(page, "MISSING_MIDDLE", { ...second, game_family: "MISSING_MIDDLE" })
    await page.getByRole("button", { name: "Open history", exact: true }).click()
    await expect(page.getByRole("dialog").locator(".ts-entry")).toHaveCount(3)
    await page.getByRole("dialog").press("Escape")
    await expect(page.getByRole("dialog")).toHaveCount(0)
})

test("theme and Reset shared-media bridge update and persist", async ({ page }) => {
    await page.route("https://media.example.test/**", route => route.fulfill({ status: 200, contentType: "image/png", body: Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVQIHWP4z8DwHwAFgAI/ScLbtAAAAABJRU5ErkJggg==", "base64") }))
    await page.goto("/")
    await page.getByRole("button", { name: "Switch to bright theme" }).click()
    await expect(page.locator(".ts-theme-bright")).toBeVisible()
    await page.reload()
    await expect(page.locator(".ts-theme-bright")).toBeVisible()
    await page.evaluate(() => {
        window.dispatchEvent(new CustomEvent("thinkstill:theme", { detail: { theme: "dark" } }))
        localStorage.setItem("__ts_reset_shared_media_v1", JSON.stringify({ avatars: { glitch: "https://media.example.test/glitch.png" }, updatedAt: Date.now() }))
        window.dispatchEvent(new Event("thinkstill:reset-shared-media"))
    })
    await expect(page.locator(".ts-theme-dark")).toBeVisible()
    await expect(page.locator(".ts-idle-orbit .ts-avatar img")).toHaveAttribute("src", "https://media.example.test/glitch.png")
})

test("microphone unavailable: typing stays usable", async ({ page }) => {
    await page.addInitScript(() => {
        Object.defineProperty(window, "SpeechRecognition", { configurable: true, value: undefined })
        Object.defineProperty(window, "webkitSpeechRecognition", { configurable: true, value: undefined })
    })
    await page.goto("/")
    await page.getByRole("button", { name: "Start microphone", exact: true }).click()
    await expect(page.locator(".ts-toast-visible")).toContainText("Voice isn't available")
    await composer(page).fill(INPUT)
    await expect(page.getByRole("button", { name: "Catch this thought" })).toBeEnabled()
})

for (const denied of [false, true]) {
    test(`mocked microphone ${denied ? "permission denied" : "transcript reviewed before send"}`, async ({ page }) => {
        await page.addInitScript(({ denied }) => {
            class MockRecognition {
                lang = ""; continuous = false; interimResults = false
                onresult: ((event: { results: Array<{ 0: { transcript: string }; isFinal: boolean }> }) => void) | null = null
                onerror: ((event: { error: string }) => void) | null = null
                onend: (() => void) | null = null
                start() {
                    setTimeout(() => {
                        if (denied) this.onerror?.({ error: "not-allowed" })
                        else this.onresult?.({ results: [{ 0: { transcript: "My boss hasn't replied." }, isFinal: true }] })
                        this.onend?.()
                    }, 20)
                }
                stop() { this.onend?.() }
                abort() { this.onend?.() }
            }
            Object.defineProperty(window, "SpeechRecognition", { configurable: true, value: MockRecognition })
        }, { denied })
        await page.goto("/")
        await page.getByRole("button", { name: "Start microphone", exact: true }).click()
        if (denied) {
            await expect(page.locator(".ts-toast-visible")).toContainText("Microphone permission wasn't granted")
            await expect(composer(page)).toHaveValue("")
        } else {
            await expect(composer(page)).toHaveValue("My boss hasn't replied.")
            await expect(page.locator(".ts-phase-idle")).toBeVisible()
        }
    })
}

test("standalone Framer artifact completes the same boss reframe", async ({ page }) => {
    const analysis = analysisFor("FACT_VS_GUESS")
    await mockAnalysis(page, analysis)
    await page.goto(`/dev/standalone.html?ai=${encodeURIComponent(AI_URL)}`)
    await submit(page)
    await completeGame(page, analysis.game_family, analysis, true)
    await page.getByRole("button", { name: "Save reframe", exact: true }).click()
    await expect(page.getByRole("button", { name: "Frame saved", exact: true })).toBeVisible()
})
