// Local preview adapter only. The distributable imports the real Framer module.
export const ControlType = { String: 'string', Boolean: 'boolean', Number: 'number', File: 'file', Enum: 'enum' } as const
export type PropertyControl = {
    type: typeof ControlType[keyof typeof ControlType]; title?: string; defaultValue?: unknown
    options?: string[]; optionTitles?: string[]; allowedFileTypes?: string[]
    min?: number; max?: number; step?: number; placeholder?: string; description?: string
}
export function addPropertyControls(_component: unknown, _controls: Record<string, PropertyControl>): void {
    // Framer provides the property panel in production; the browser harness does not.
    void _component; void _controls
}
