export const PATTERNS = [
    "Mind Reading", "Fortune Telling", "Catastrophising", "Personalisation",
    "All-or-Nothing Thinking", "Overgeneralising", "Emotional Reasoning",
    "Negative Filter", "Discounting the Positive", "Should / Must", "Self-Labelling",
    "Comparison Story", "Rejection Story", "Intent Assumption", "Perfectionism",
    "Blame", "Control Error", "Uncertainty Intolerance", "Meaning-Making", "Failure Interpretation",
] as const
export type ReframePattern = typeof PATTERNS[number]
export const GAME_FAMILIES = [
    "FACT_VS_GUESS", "CRYSTAL_BALL", "DISASTER_CHAIN", "MISSING_MIDDLE", "ONE_NOT_ALWAYS",
    "FEELING_NOT_EVIDENCE", "PEEL_LABEL", "WRONG_SCOREBOARD", "SHOULD_SHREDDER",
    "CONTROL_SORTER", "RESPONSIBILITY_PIE", "MYSTERY_BOX", "FILTER_CLEANER", "INTENT_MACHINE", "REJECTION_FILL",
] as const
export type ReframeGameFamily = typeof GAME_FAMILIES[number]
export type ChoiceRole = "fact" | "story" | "grounded" | "distorted" | "unknown"
export type ReframeGameContent = {
    fact_card?: string; story_card?: string; unknown_card?: string
    choices?: Array<{ id: string; text: string; role?: ChoiceRole }>
    prediction_text?: string; chain_items?: string[]; label_text?: string
    scale_start?: number; scale_target?: number
    control_items?: Array<{ text: string; controllable: boolean; influence?: boolean }>
    responsibility_items?: Array<{ text: string; weight?: number }>
}
export type ReframeAnalysis = {
    ok: true; event: string; interpretation: string; emotion?: string[]
    primary_pattern: ReframePattern; secondary_patterns: ReframePattern[]
    fact: string; story: string; unknown: string; reframe: string; keep: string
    game_family: ReframeGameFamily; game_content: ReframeGameContent; confidence: number
}
export type ReframeApiResponse = { ok: true; analysis: ReframeAnalysis } | { ok: false; error?: string; safety?: SafetyResult }
export type SafetyResult = { kind: "immediate" | "threat"; title: string; message: string }
export type ReframeRequest = {
    input: string; session_id: string
    previous_patterns: ReframePattern[]; previous_game_families: ReframeGameFamily[]
}
export type AnalysisResult =
    | { kind: "analysis"; analysis: ReframeAnalysis; source: "ai" | "local" }
    | { kind: "safety"; safety: SafetyResult }
export type ReframeSession = {
    id: string; input: string; analysis: ReframeAnalysis; gameFamily: ReframeGameFamily
    completed: boolean; createdAt: number; source: "ai" | "local"
    feedback?: "helpful" | "not-helpful"
}
export type SavedReframe = {
    id: string; input: string; event: string; interpretation: string
    primaryPattern: ReframePattern; secondaryPatterns: ReframePattern[]
    fact: string; story: string; unknown: string; reframe: string; keep: string
    gameFamily: ReframeGameFamily; createdAt: number
}
export type ReframeGameProps = {
    analysis: ReframeAnalysis; onComplete: () => void; onInteraction?: () => void
}
export type BubbleSlug = "glitch" | "sync" | "patch" | "drop" | "still" | "rush" | "loopie"
