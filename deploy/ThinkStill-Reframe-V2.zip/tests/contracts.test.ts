import test from "node:test"
import assert from "node:assert/strict"
import { readFileSync } from "node:fs"
import vm from "node:vm"
import { detectSafety, GAME_MAP, localAnalysis, validateAnalysis } from "../reframe/engine"
import { GAME_FAMILIES, PATTERNS } from "../reframe/types"
import type { ReframeAnalysis } from "../reframe/types"

const context = vm.createContext({})
vm.runInContext(readFileSync(new URL("../ThinkStill_Reframe_Gemini.gs", import.meta.url), "utf8"), context)
const backendMap: unknown = JSON.parse(vm.runInContext("JSON.stringify(TS_GAME_MAP)", context))
const serverValidate = vm.runInContext("TS_validateAnalysis", context) as (value: unknown) => ReframeAnalysis | null
const serverSafety = vm.runInContext("TS_checkSafety", context) as (input: string) => { kind: string } | null

test("frontend and Apps Script enforce the same complete taxonomy and compatible routes", () => {
    assert.deepEqual(backendMap, GAME_MAP)
    assert.deepEqual(JSON.parse(vm.runInContext("JSON.stringify(TS_PATTERNS)", context)), [...PATTERNS])
    assert.deepEqual(JSON.parse(vm.runInContext("JSON.stringify(TS_GAMES)", context)), [...GAME_FAMILIES])
})

test("backend response data for every game crosses the frontend trust boundary", async t => {
    for (const game of GAME_FAMILIES) await t.test(game, () => {
        const pattern = PATTERNS.find(candidate => GAME_MAP[candidate].includes(game))!
        const fixture: ReframeAnalysis = {
            ...localAnalysis("My boss hasn't replied. She must be unhappy with my work."),
            primary_pattern: pattern, secondary_patterns: [], game_family: game,
        }
        const serverOutput = serverValidate(fixture)
        assert.ok(serverOutput, "backend accepts bounded, compatible game data")
        const transferred: unknown = JSON.parse(JSON.stringify(serverOutput))
        const received = validateAnalysis(transferred)
        assert.ok(received, "client accepts actual serialized server schema")
        assert.equal(received.game_family, game)
        assert.equal(received.fact, fixture.fact)
    })
})

test("frontend and backend safety agree on emergencies, threats and ordinary uncertainty", () => {
    for (const input of [
        "I am going to kill myself.", "I overdosed and can't breathe.", "My partner threatened to hit me.",
        "My sister is not breathing.", "He's going to kill himself.",
        "My partner called me useless. Maybe they're right.",
        "My boss hasn't replied. She must be unhappy with my work.",
        "I overdosed last year and recovered. I worry about tomorrow.",
        'The movie character says "I am going to kill myself".',
    ]) assert.equal(serverSafety(input)?.kind ?? null, detectSafety(input)?.kind ?? null, input)
})
