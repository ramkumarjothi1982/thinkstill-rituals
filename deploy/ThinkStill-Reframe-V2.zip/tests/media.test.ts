import assert from "node:assert/strict"
import { afterEach, test } from "node:test"
import {
    loadSharedMedia, loadSharedTheme, parseSharedMedia, safeMediaUrl,
    SHARED_MEDIA_KEY, SHARED_MEDIA_WINDOW_PREFIX, SHARED_THEME_KEY,
} from "../reframe/media"

const originalWindow = Object.getOwnPropertyDescriptor(globalThis, "window")
function setWindow(value: unknown): void {
    Object.defineProperty(globalThis, "window", { configurable: true, value })
}
afterEach(() => {
    if (originalWindow) Object.defineProperty(globalThis, "window", originalWindow)
    else Reflect.deleteProperty(globalThis, "window")
})

test("shared URLs reject active content and preserve verified image-only data prefixes", () => {
    assert.equal(safeMediaUrl(" https://assets.example/avatar.webp "), "https://assets.example/avatar.webp")
    const blob = "blob:https://thinkstill.app/01234567-89ab-cdef-0123-456789abcdef"
    assert.equal(safeMediaUrl(blob), blob)
    assert.equal(safeMediaUrl("blob:null/01234567-89ab-cdef-0123-456789abcdef"), "blob:null/01234567-89ab-cdef-0123-456789abcdef")
    const png = "data:image/png;base64,iVBORw0KGgo="
    assert.equal(safeMediaUrl(png), png)
    for (const unsafe of [
        "javascript:alert(1)", "http://assets.example/avatar.png", "/avatar.png",
        "https://user:password@assets.example/avatar.png", "https://assets.example/\nimage.png",
        "blob:javascript:alert(1)", "blob:https://thinkstill.app/not-a-blob-token",
        "data:text/html;base64,PHNjcmlwdD4=", "data:image/svg+xml;base64,PHN2Zz4=",
        "data:image/png;base64,PHNjcmlwdD4=", "data:image/png;base64,%%%",
        "data:image/png;base64," + "A".repeat(500_001), 7, null,
    ]) assert.equal(safeMediaUrl(unsafe), "", String(unsafe).slice(0, 100))
})

test("shared media parser accepts only known bubble and overlay slots, preserving video classification", () => {
    const parsed = parseSharedMedia(JSON.stringify({
        updatedAt: 20, avatars: { still: "https://assets.example/still.png", invented: "https://assets.example/other.png", rush: "javascript:alert(1)" },
        overlays: { still_overlay_1: "https://assets.example/transition", still_overlay_5: "https://assets.example/last.webm", still_overlay_6: "https://assets.example/extra.webm", __proto__: "unused" },
        videoOverlayKeys: ["still_overlay_1", "still_overlay_1", "still_overlay_6", 42], private: "discard",
    }))
    assert.deepEqual(parsed, {
        updatedAt: 20, avatars: { still: "https://assets.example/still.png" },
        overlays: { still_overlay_1: "https://assets.example/transition", still_overlay_5: "https://assets.example/last.webm" },
        videoOverlayKeys: ["still_overlay_1"],
    })
    for (const raw of ["{", "null", "[]", "true", " ".repeat(4_000_001), null]) {
        assert.equal(parseSharedMedia(raw), null)
    }
    assert.equal(parseSharedMedia('{"updatedAt":"latest"}')?.updatedAt, 0)
})

test("latest valid browser payload wins and blocked storage still uses the same-tab fallback", () => {
    const old = JSON.stringify({ updatedAt: 10, avatars: { still: "https://assets.example/old.png" } })
    const next = JSON.stringify({ updatedAt: 20, avatars: { still: "https://assets.example/new.png" } })
    const values = new Map([[SHARED_MEDIA_KEY, old]])
    setWindow({ localStorage: { getItem: (key: string) => values.get(key) ?? null }, name: SHARED_MEDIA_WINDOW_PREFIX + next })
    assert.equal(loadSharedMedia().avatars?.still, "https://assets.example/new.png")
    values.set(SHARED_MEDIA_KEY, JSON.stringify({ updatedAt: 30, avatars: { patch: "https://assets.example/patch.png" } }))
    assert.deepEqual(loadSharedMedia(), { avatars: { patch: "https://assets.example/patch.png" } })
    setWindow(Object.defineProperty({ name: SHARED_MEDIA_WINDOW_PREFIX + next }, "localStorage", {
        get() { throw new Error("SecurityError") },
    }))
    assert.equal(loadSharedMedia().avatars?.still, "https://assets.example/new.png")
    setWindow({ localStorage: { getItem: () => "broken" }, name: "unrelated-window-name" })
    assert.deepEqual(loadSharedMedia(), {})
})

test("theme respects existing exact shared key and otherwise uses the caller's default", () => {
    const values = new Map<string, string>()
    setWindow({ localStorage: { getItem: (key: string) => values.get(key) ?? null } })
    assert.equal(loadSharedTheme("bright"), "bright")
    values.set(SHARED_THEME_KEY, "dark")
    assert.equal(loadSharedTheme("bright"), "dark")
    values.set(SHARED_THEME_KEY, "bright")
    assert.equal(loadSharedTheme("dark"), "bright")
    values.set(SHARED_THEME_KEY, "invalid")
    assert.equal(loadSharedTheme("bright"), "bright")
    Reflect.deleteProperty(globalThis, "window")
    assert.deepEqual(loadSharedMedia(), {})
    assert.equal(loadSharedTheme("bright"), "bright")
})
