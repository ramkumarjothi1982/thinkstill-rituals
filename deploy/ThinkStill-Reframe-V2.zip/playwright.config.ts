import { existsSync } from "node:fs"
import { defineConfig } from "@playwright/test"

// Use the environment's installed Chromium when Playwright's optional download
// is unavailable. An explicit executable path always takes precedence.
const executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH
    || (existsSync("/usr/bin/chromium") ? "/usr/bin/chromium" : undefined)

export default defineConfig({
    testDir: "./tests",
    testMatch: "browser.spec.ts",
    fullyParallel: true,
    workers: 2,
    timeout: 30_000,
    expect: { timeout: 6_000 },
    reporter: "list",
    outputDir: "/tmp/thinkstill-browser-results",
    use: {
        baseURL: "http://127.0.0.1:5173",
        browserName: "chromium",
        launchOptions: { executablePath },
        viewport: { width: 1280, height: 850 },
        trace: "retain-on-failure",
        screenshot: "only-on-failure",
    },
    webServer: {
        command: "npm run dev -- --port 5173 --strictPort",
        url: "http://127.0.0.1:5173",
        reuseExistingServer: !process.env.CI,
        timeout: 30_000,
    },
})
