# ThinkStill Reframe V2 game map

Gemini selects only permitted patterns and predefined families. The browser validates the response and runs its own game code. A game preserves the reported event while testing the interpretation; it does not promise that another person's intentions are benign.

| Thinking pattern | Preferred game | Alternative game |
| --- | --- | --- |
| Mind Reading | `FACT_VS_GUESS` | `INTENT_MACHINE` |
| Fortune Telling | `CRYSTAL_BALL` | `MYSTERY_BOX` |
| Catastrophising | `DISASTER_CHAIN` | `CRYSTAL_BALL` |
| Personalisation | `RESPONSIBILITY_PIE` | `CONTROL_SORTER` |
| All-or-Nothing Thinking | `MISSING_MIDDLE` | `PEEL_LABEL` |
| Overgeneralising | `ONE_NOT_ALWAYS` | `DISASTER_CHAIN` |
| Emotional Reasoning | `FEELING_NOT_EVIDENCE` | `FACT_VS_GUESS` |
| Negative Filter | `FILTER_CLEANER` | `FACT_VS_GUESS` |
| Discounting the Positive | `FILTER_CLEANER` | `FACT_VS_GUESS` |
| Should / Must | `SHOULD_SHREDDER` | `CONTROL_SORTER` |
| Self-Labelling | `PEEL_LABEL` | `MISSING_MIDDLE` |
| Comparison Story | `WRONG_SCOREBOARD` | `FILTER_CLEANER` |
| Rejection Story | `REJECTION_FILL` | `FACT_VS_GUESS` |
| Intent Assumption | `INTENT_MACHINE` | `FACT_VS_GUESS` |
| Perfectionism | `MISSING_MIDDLE` | `SHOULD_SHREDDER` |
| Blame | `RESPONSIBILITY_PIE` | `CONTROL_SORTER` |
| Control Error | `CONTROL_SORTER` | `RESPONSIBILITY_PIE` |
| Uncertainty Intolerance | `MYSTERY_BOX` | `FACT_VS_GUESS` |
| Meaning-Making | `FACT_VS_GUESS` | `REJECTION_FILL` |
| Failure Interpretation | `PEEL_LABEL` | `MISSING_MIDDLE` |

| Game family | Cognitive interaction | Completion condition |
| --- | --- | --- |
| `FACT_VS_GUESS` | Place personalised cards into known, added story and unknown. | All cards are placed correctly. |
| `CRYSTAL_BALL` | Crack the unsupported prediction. | After cracking the ball, identify a possible outcome rather than a proven future. |
| `DISASTER_CHAIN` | Break unsupported links after the factual starting event. | All unsupported links are broken; the event remains. |
| `MISSING_MIDDLE` | Explore space away from an extreme judgement. | Move the slider away from its starting point to a position inside the extremes, then choose the grounded frame; no fixed percentage defines a user's worth. |
| `ONE_NOT_ALWAYS` | Remove absolute generalisations attached to one event. | The absolute words are removed and the event remains. |
| `FEELING_NOT_EVIDENCE` | Separate a valid feeling from the factual evidence. | Break the equals connection, then confirm the feeling does not prove the meaning. |
| `PEEL_LABEL` | Peel an identity label away from the described event. | The label is removed; the event stays visible. |
| `WRONG_SCOREBOARD` | Remove conclusions drawn from incomparable data. | Remove the comparison, then return to the user's own evidence. |
| `SHOULD_SHREDDER` | Transform the user's rigid must/should into a preference or aim. | Choose a flexible intention, read the rewritten standard, then confirm keeping the value while loosening the rule. |
| `CONTROL_SORTER` | Sort actions from outcomes and other people's choices. | Items are sorted; influence is acknowledged where supplied. |
| `RESPONSIBILITY_PIE` | Review known factors and an unknown remainder before estimating responsibility. | Review the factors and Unknown, optionally adjust the allocation, then confirm the estimate; 100% can remain when supported. |
| `MYSTERY_BOX` | Remove bad news from a gap in information. | Remove the assumed outcome, then confirm leaving the answer unknown. |
| `FILTER_CLEANER` | Clear an interpretation filter to widen the available frame. | Clear or wipe the filter, then choose a grounded frame without inventing positive facts. |
| `INTENT_MACHINE` | Remove an assumed motive from the observed behaviour. | Behaviour remains; unsupported intent is removed. |
| `REJECTION_FILL` | Remove an automatic rejection ending. | Erase the ending, then choose a grounded replacement. |

Each family receives `ReframeAnalysis` and an `onComplete` callback. Games use tap/button interactions or an accessible slider rather than requiring drag gestures. Long clauses have a Read Complete control that opens the full text inside a dialog; closing it returns to the current game. Completion leads to Caught, Plot Twist, New Frame and Keep. Long results also offer Read Full Frame.

The preferred and alternative columns match the first two entries of `GAME_MAP` in `reframe/engine.ts` and `TS_GAME_MAP` in the backend. Some patterns have a third compatible family for another angle. The map is a guide, not a diagnosis. Secondary patterns and previous games can support another angle after Not Helpful. The console permits at most two retries per input. Immediate danger and described threats bypass this map. An actual insult remains a fact: only an unsupported identity conclusion is a candidate for a game.

## Alignment with existing ThinkStill taxonomy

The existing `rituals.json` thinking-error labels were reviewed to align useful interpretation concepts with V2's controlled names. These are conceptual mappings from that review, not additional runtime aliases or a dependency on the old ritual loader. The existing taxonomy data remains intact.

| Existing thinking-error label | Controlled V2 name |
| --- | --- |
| Mind reading | Mind Reading |
| Fortune telling | Fortune Telling |
| Overgeneralisation / Relationship overgeneralisation | Overgeneralising |
| Black-and-white thinking | All-or-Nothing Thinking |
| Emotional reasoning | Emotional Reasoning |
| Should statements / Internalised rules | Should / Must |
| Social comparison | Comparison Story |
| Positive discounting | Discounting the Positive |
| Control confusion / Control struggle | Control Error |
| Ambiguity intolerance | Uncertainty Intolerance |

Specialised physiology and optical-illusion patterns in the broader library belong to other ThinkStill experiences. They were not added arbitrarily to Reframe's controlled schema.
