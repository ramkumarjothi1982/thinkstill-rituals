import { compatibleGames, validateAnalysis } from "./engine"
import { GAME_FAMILIES, PATTERNS } from "./types"
import type { ReframeSession, SavedReframe } from "./types"

const PREFIX = "thinkstill.reframe.v2"
const HISTORY_LIMIT = 30
const VAULT_LIMIT = 50
const MAX_STORED_BYTES = 1_800_000
const MAX_SCANNED_ITEMS = 1_000

function storage(): Storage | null {
    try {
        return typeof window === "undefined" ? null : window.localStorage
    } catch {
        return null
    }
}

function record(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null && !Array.isArray(value)
}

function text(value: unknown, limit = 420): string | null {
    if (typeof value !== "string" || !value.trim()) return null
    return value.trim().slice(0, limit)
}

function validIdentity(value: Record<string, unknown>): boolean {
    return typeof value.id === "string" && /^[a-zA-Z0-9_-]{1,128}$/.test(value.id)
        && typeof value.createdAt === "number" && Number.isSafeInteger(value.createdAt)
        && value.createdAt > 0 && value.createdAt <= 8_640_000_000_000_000
}

function session(value: unknown): ReframeSession | null {
    if (!record(value) || !validIdentity(value) || typeof value.completed !== "boolean"
        || (value.source !== "ai" && value.source !== "local")) return null
    const input = text(value.input, 1_800)
    // Never restore model output merely because it came from our own storage key.
    const analysis = validateAnalysis(value.analysis)
    if (!input || !analysis || value.gameFamily !== analysis.game_family) return null
    const result: ReframeSession = {
        id: value.id as string, input, analysis, gameFamily: analysis.game_family,
        completed: value.completed, createdAt: value.createdAt as number, source: value.source,
    }
    if (value.feedback === "helpful" || value.feedback === "not-helpful") result.feedback = value.feedback
    return result
}

function saved(value: unknown): SavedReframe | null {
    if (!record(value) || !validIdentity(value)
        || !PATTERNS.includes(value.primaryPattern as never)
        || !GAME_FAMILIES.includes(value.gameFamily as never)
        || !compatibleGames(value.primaryPattern as SavedReframe["primaryPattern"])
            .includes(value.gameFamily as SavedReframe["gameFamily"])
        || !Array.isArray(value.secondaryPatterns)
        || value.secondaryPatterns.length > 3
        || value.secondaryPatterns.some(pattern => !PATTERNS.includes(pattern as never))) return null
    const input = text(value.input, 1_800)
    const event = text(value.event)
    const interpretation = text(value.interpretation)
    const fact = text(value.fact)
    const story = text(value.story)
    const unknown = text(value.unknown)
    const reframe = text(value.reframe)
    const keep = text(value.keep, 180)
    if (!input || !event || !interpretation || !fact || !story || !unknown || !reframe || !keep) return null
    return {
        id: value.id as string, input, event, interpretation,
        primaryPattern: value.primaryPattern as SavedReframe["primaryPattern"],
        secondaryPatterns: [...new Set(value.secondaryPatterns)]
            .filter(pattern => pattern !== value.primaryPattern) as SavedReframe["secondaryPatterns"],
        fact, story, unknown, reframe, keep,
        gameFamily: value.gameFamily as SavedReframe["gameFamily"], createdAt: value.createdAt as number,
    }
}

function boundedItems<T extends { id: string }>(value: unknown, limit: number, validate: (item: unknown) => T | null): T[] {
    if (!Array.isArray(value)) return []
    const results: T[] = []
    const ids = new Set<string>()
    for (const item of value.slice(0, MAX_SCANNED_ITEMS)) {
        const valid = validate(item)
        if (!valid) continue
        const id = valid.id
        if (ids.has(id)) continue
        ids.add(id)
        results.push(valid)
        if (results.length === limit) break
    }
    return results
}

function readItems<T extends { id: string }>(key: string, limit: number, validate: (item: unknown) => T | null): T[] {
    try {
        const raw = storage()?.getItem(`${PREFIX}.${key}`)
        if (!raw || raw.length > MAX_STORED_BYTES) return []
        return boundedItems(JSON.parse(raw), limit, validate)
    } catch {
        return []
    }
}

function writeItems<T extends { id: string }>(key: string, items: T[], limit: number, validate: (item: unknown) => T | null): boolean {
    try {
        const target = storage()
        if (!target || !Array.isArray(items)) return false
        const raw = JSON.stringify(boundedItems(items, limit, validate))
        if (raw.length > MAX_STORED_BYTES) return false
        target.setItem(`${PREFIX}.${key}`, raw)
        return true
    } catch {
        return false
    }
}

export function loadHistory(): ReframeSession[] {
    return readItems("history", HISTORY_LIMIT, session)
}

export function saveHistory(items: ReframeSession[]): boolean {
    return writeItems("history", items, HISTORY_LIMIT, session)
}

export function loadVault(): SavedReframe[] {
    return readItems("vault", VAULT_LIMIT, saved)
}

export function saveVault(items: SavedReframe[]): boolean {
    return writeItems("vault", items, VAULT_LIMIT, saved)
}

export function toSaved(value: ReframeSession): SavedReframe {
    const analysis = value.analysis
    return {
        id: value.id, input: value.input.slice(0, 1_800), event: analysis.event.slice(0, 420),
        interpretation: analysis.interpretation.slice(0, 420), primaryPattern: analysis.primary_pattern,
        secondaryPatterns: [...analysis.secondary_patterns], fact: analysis.fact.slice(0, 420),
        story: analysis.story.slice(0, 420), unknown: analysis.unknown.slice(0, 420),
        reframe: analysis.reframe.slice(0, 420), keep: analysis.keep.slice(0, 180),
        gameFamily: value.gameFamily, createdAt: value.createdAt,
    }
}

export function shareText(value: ReframeSession | SavedReframe): string {
    const item = "analysis" in value ? toSaved(value) : value
    return `THINKSTILL REFRAME\n\nCAUGHT\n${item.primaryPattern}\n\nFACT\n${item.fact.slice(0, 420)}\n\nNEW FRAME\n${item.reframe.slice(0, 420)}\n\nKEEP\n${item.keep.slice(0, 180)}`
}

function validMomentum(value: unknown): value is number {
    return typeof value === "number" && Number.isSafeInteger(value) && value >= 0
}

export function loadMomentum(): number {
    try {
        const raw = storage()?.getItem(`${PREFIX}.momentum`)
        if (!raw || raw.length > 32) return 0
        const value: unknown = JSON.parse(raw)
        return validMomentum(value) ? value : 0
    } catch {
        return 0
    }
}

export function saveMomentum(value: number): boolean {
    try {
        const target = storage()
        if (!target || !validMomentum(value)) return false
        target.setItem(`${PREFIX}.momentum`, JSON.stringify(value))
        return true
    } catch {
        return false
    }
}
