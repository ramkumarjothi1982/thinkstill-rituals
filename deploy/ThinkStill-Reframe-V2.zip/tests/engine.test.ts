import assert from "node:assert/strict"
import { test } from "node:test"
import { bubbleForPattern, compatibleGames, detectSafety, GAME_MAP, localAnalysis, plotTwist, validateAnalysis } from "../reframe/engine"
import { GAME_FAMILIES, PATTERNS } from "../reframe/types"

const scenarios = [
    { input: "My boss hasn't replied. She must be unhappy with my work.", pattern: "Mind Reading", game: "FACT_VS_GUESS", secondary: "Personalisation" },
    { input: "I made one mistake in the presentation. I'm terrible at my job.", pattern: "Self-Labelling", game: "PEEL_LABEL", secondary: "All-or-Nothing Thinking" },
    { input: "My boyfriend hasn't messaged today. He's probably losing interest.", pattern: "Mind Reading", game: "REJECTION_FILL", secondary: "Rejection Story" },
    { input: "I feel anxious, so something bad must be about to happen.", pattern: "Emotional Reasoning", game: "FEELING_NOT_EVIDENCE", secondary: "Fortune Telling" },
    { input: "I got rejected from one job. I'm never going to get hired.", pattern: "Overgeneralising", game: "ONE_NOT_ALWAYS", secondary: "Fortune Telling" },
    { input: "My partner called me useless. Maybe they're right.", pattern: "Self-Labelling", game: "PEEL_LABEL" },
    { input: "My friend cancelled dinner. Nobody wants me around.", pattern: "Overgeneralising", game: "ONE_NOT_ALWAYS", secondary: "Rejection Story" },
    { input: "I don't know whether I got the job. That probably means I failed.", pattern: "Uncertainty Intolerance", game: "MYSTERY_BOX", secondary: "Fortune Telling" },
] as const

for (const [index, scenario] of scenarios.entries()) {
    test(`brief scenario ${index + 1} gives a personalised compatible fallback`, () => {
        const analysis = localAnalysis(scenario.input)
        assert.equal(analysis.primary_pattern, scenario.pattern)
        assert.equal(analysis.game_family, scenario.game)
        if ("secondary" in scenario) assert.ok(analysis.secondary_patterns.includes(scenario.secondary))
        assert.ok(scenario.input.startsWith(analysis.fact))
        assert.equal(analysis.game_content.fact_card, analysis.fact)
        assert.equal(analysis.game_content.story_card, analysis.story)
        assert.equal(analysis.game_content.unknown_card, analysis.unknown)
        assert.ok(analysis.confidence < 0.7, "local fallback must remain cautious")
        assert.deepEqual(validateAnalysis(analysis), analysis)
    })
}

test("partner insult remains factual and its label is peeled without guessing motives", () => {
    const analysis = localAnalysis(scenarios[5].input)
    assert.equal(analysis.fact, "My partner called me useless.")
    assert.equal(analysis.story, "Maybe they're right.")
    assert.equal(analysis.game_content.label_text, "useless")
    assert.match(analysis.reframe, /take the hurt seriously/u)
    assert.doesNotMatch(analysis.reframe, /didn't mean|did not mean|everything is fine|imagining/u)
    assert.equal(plotTwist(analysis), "A label said to you isn't your identity.")
})

test("the definition-of-done example catches another person's guessed opinion", () => {
    const analysis = localAnalysis("My boss ignored my message. She probably thinks I'm incompetent.")
    assert.equal(analysis.primary_pattern, "Mind Reading")
    assert.equal(analysis.fact, "My boss ignored my message.")
    assert.equal(analysis.story, "She probably thinks I'm incompetent.")
})

test("Unicode contractions preserve the user's actual words", () => {
    const analysis = localAnalysis("My boss hasn’t replied. She’s probably unhappy with my work.")
    assert.equal(analysis.primary_pattern, "Mind Reading")
    assert.equal(analysis.fact, "My boss hasn’t replied.")
    assert.equal(localAnalysis("I made a mistake. I’m terrible at my job.").primary_pattern, "Self-Labelling")
})

test("an unsupported single self-label is a reported thought, not a factual identity", () => {
    const analysis = localAnalysis("I'm useless.")
    assert.equal(analysis.primary_pattern, "Self-Labelling")
    assert.match(analysis.fact, /thought into words/u)
    assert.equal(analysis.story, "I'm useless.")
})

test("unknown situations don't invent an event, positive facts, or a diagnosis", () => {
    const analysis = localAnalysis("The meeting was difficult.")
    assert.equal(analysis.fact, "The meeting was difficult.")
    assert.equal(analysis.primary_pattern, "Meaning-Making")
    assert.equal(analysis.confidence, 0.3)
    assert.doesNotMatch(analysis.reframe, /they love|everyone likes|everything is fine|disorder/u)
})

test("retry rotates compatible games rather than repeating or inventing an unrelated family", () => {
    const first = localAnalysis(scenarios[0].input)
    const second = localAnalysis(scenarios[0].input, [first.primary_pattern], [first.game_family])
    assert.notEqual(second.game_family, first.game_family)
    assert.ok(compatibleGames(second.primary_pattern).includes(second.game_family))
    assert.equal(second.fact, first.fact)
})

test("the complete controlled taxonomy routes only to all fifteen predefined families", () => {
    const routed = new Set<string>()
    for (const pattern of PATTERNS) {
        assert.ok(GAME_MAP[pattern].length >= 2)
        assert.deepEqual(compatibleGames(pattern), GAME_MAP[pattern])
        for (const game of compatibleGames(pattern)) {
            assert.ok((GAME_FAMILIES as readonly string[]).includes(game))
            routed.add(game)
        }
        assert.ok(["glitch", "sync", "patch", "drop", "still", "rush", "loopie"].includes(bubbleForPattern(pattern)))
    }
    assert.equal(routed.size, 15)
})

const emergencies = [
    "I am going to kill myself.", "I’m going to kill myself.", "I want to die.", "I am suicidal.",
    "I am going to end my life.", "I will take my life.", "I plan to hurt myself.", "I'm cutting myself.",
    "I overdosed and can't breathe.", "I took too many pills.", "My friend isn't breathing.",
    "Someone is not breathing.", "My dad is unconscious.", "I have severe chest pain.",
    "I want to kill my boss.", "I am going to seriously hurt someone.",
    "I'm not joking, I will kill myself.", "I overdosed years ago and I am going to kill myself.",
    "I am watching a film and I will kill myself.", "My friend said \"I am going to kill myself\".",
    "My son says he's going to kill himself.", "My sister is not breathing.", "Severe chest pain.", "Not breathing.",
    "I will harm someone.", "I'm gonna hurt myself.", "I am going to slit my wrists.", "I will jump off a bridge.",
    "I swallowed a whole bottle of pills.",
    "I am going to kill my\u202Eself.",
]
for (const input of emergencies) test(`safety overrides imminent danger: ${input}`, () => assert.equal(detectSafety(input)?.kind, "immediate"))

const threats = [
    "My partner threatened to hit me.", "My partner threatened to hit me and I don't know what to do.",
    "He said he would hit me.", "My partner is choking me.", "I am being attacked.",
    "My partner isn't threatening to hit me, he is hitting me.", "My partner says he'll hit me.",
]
for (const input of threats) test(`reported harm is not a catastrophe game: ${input}`, () => assert.equal(detectSafety(input)?.kind, "threat"))

const notEmergencies = [
    "I am not going to kill myself.", "I don’t want to hurt myself.", "I don't want to die.", "I'm not suicidal.",
    "I have no intention of killing myself.", "I didn't say I am going to kill myself.",
    "My partner has never threatened to hit me.", "My partner hasn't threatened to hit me.", "Nobody threatened to hit me.",
    "My partner called me useless. Maybe they're right.", "I don't have severe chest pain.", "She is not unconscious.",
    "I haven't overdosed.", "I overdosed years ago and recovered.", "When someone is unconscious, what do doctors do?",
    "The movie character says \"I am going to kill myself\".", "I'm quoting a song that says \"I want to die\".",
    "A fictional character says I will kill someone.", "I want to kill the presentation.", "I am going to kill myself laughing.",
]
for (const input of notEmergencies) test(`avoids clear negation, history, fiction and idioms: ${input}`, () => assert.equal(detectSafety(input), null))

test("runtime validation canonicalises permitted data and rejects unsafe output", () => {
    const valid = localAnalysis(scenarios[0].input)
    assert.ok(validateAnalysis({ ...valid, ok: undefined, game_content: {} }))
    for (const invalid of [null, "bad", [], { ...valid, ok: false }, { ...valid, primary_pattern: "Invented diagnosis" },
        { ...valid, game_family: "RUN_CODE" }, { ...valid, game_family: "PEEL_LABEL" }, { ...valid, confidence: 4 },
        { ...valid, confidence: Number.NaN }, { ...valid, keep: "x".repeat(181) }, { ...valid, fact: "x".repeat(421) },
        { ...valid, story: "https://evil.example/" }, { ...valid, story: "<script>alert(1)</script>" },
        { ...valid, story: "Hidden\u007Fcontrol" }, { ...valid, story: "Hidden\u009Fcontrol" },
        { ...valid, story: "Spoofed\u202Etext" }, { ...valid, story: "Spoofed\u2066text\u2069" },
        { ...valid, secondary_patterns: [valid.primary_pattern] }, { ...valid, secondary_patterns: ["Personalisation", "Personalisation"] },
        { ...valid, game_content: { custom: { code: "eval()" } } }, { ...valid, game_content: { scale_start: -1 } },
        { ...valid, game_content: { choices: [{ id: "same", text: "A" }, { id: "same", text: "B" }] } },
        { ...valid, game_content: { choices: [{ id: "a", text: "A", role: "execute" }, { id: "b", text: "B" }] } },
        { ...valid, game_content: { chain_items: ["only one"] } }, { ...valid, game_content: { control_items: [{ text: "A", controllable: "true" }, { text: "B", controllable: false }] } },
        { ...valid, game_content: { responsibility_items: [{ text: "A", weight: 110 }, { text: "Unknown" }] } },
        { ...valid, html: "<b>injected</b>" },
    ]) assert.equal(validateAnalysis(invalid), null)
})

test("bounded fallback survives extremely long input", () => {
    const analysis = localAnalysis(`${"The meeting was difficult ".repeat(1000)}. I am useless.`)
    assert.ok(analysis.fact.length <= 420)
    assert.ok(analysis.story.length <= 420)
    assert.ok(analysis.keep.length <= 180)
    assert.match(analysis.reframe, /leave its larger meaning open/u)
    assert.ok(validateAnalysis(analysis))
})

test("local fallback strips non-display and bidirectional control characters", () => {
    const analysis = localAnalysis("My boss\u202E hasn't replied. She\u2066 must be unhappy with my work\u007F.\u2069")
    assert.equal(analysis.primary_pattern, "Mind Reading")
    assert.ok(validateAnalysis(analysis))
    assert.equal(analysis.fact, "My boss hasn't replied.")
})
