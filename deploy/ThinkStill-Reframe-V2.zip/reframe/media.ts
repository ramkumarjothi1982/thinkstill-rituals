import * as React from "react"
import type { BubbleSlug } from "./types"

export type SharedMedia = {
    avatars?: Partial<Record<BubbleSlug, string>>
    overlays?: Record<string, string>
    videoOverlayKeys?: string[]
}
export type SharedTheme = "dark" | "bright"

export const SHARED_MEDIA_KEY = "__ts_reset_shared_media_v1"
export const SHARED_MEDIA_WINDOW_PREFIX = "__ts_reset_shared_media_v1__:"
export const SHARED_MEDIA_EVENT = "thinkstill:reset-shared-media"
export const SHARED_THEME_KEY = "__ts_chat_theme_v181"
export const SHARED_THEME_EVENT = "thinkstill:theme"

const BUBBLES: BubbleSlug[] = ["still", "patch", "sync", "loopie", "drop", "rush", "glitch"]
const OVERLAY_KEYS = new Set(BUBBLES.flatMap(bubble =>
    Array.from({ length: 5 }, (_, index) => `${bubble}_overlay_${index + 1}`)))
const MAX_PAYLOAD_LENGTH = 4_000_000
const MAX_IMAGE_DATA_LENGTH = 500_000
type ParsedSharedMedia = SharedMedia & { updatedAt: number }

function record(value: unknown): value is Record<string, unknown> {
    return !!value && typeof value === "object" && !Array.isArray(value)
}

/** URLs supplied by shared browser storage are untrusted media sources. */
export function safeMediaUrl(value: unknown): string {
    if (typeof value !== "string") return ""
    const source = value.trim()
    if (!source) return ""
    for (let index = 0; index < source.length; index++) {
        const code = source.charCodeAt(index)
        if (code <= 32 || code === 127) return ""
    }
    if (source.startsWith("data:")) {
        if (source.length > MAX_IMAGE_DATA_LENGTH) return ""
        const match = /^data:image\/(png|jpeg|gif|webp|avif);base64,([A-Za-z0-9+/]+={0,2})$/i.exec(source)
        if (!match || match[2].length % 4 !== 0) return ""
        try {
            const header = atob(match[2].slice(0, 64))
            const kind = match[1].toLowerCase()
            const valid = kind === "png" ? header.startsWith("\x89PNG\r\n\x1a\n")
                : kind === "jpeg" ? header.startsWith("\xff\xd8\xff")
                : kind === "gif" ? /^GIF8[79]a/.test(header)
                : kind === "webp" ? header.startsWith("RIFF") && header.slice(8, 12) === "WEBP"
                : header.slice(4, 8) === "ftyp" && /avif|avis/.test(header.slice(8))
            return valid ? source : ""
        } catch { return "" }
    }
    if (source.length > 8192) return ""
    try {
        const url = new URL(source)
        if (url.protocol === "https:" && !url.username && !url.password) return url.href
        if (url.protocol !== "blob:") return ""
        // Opaque-origin blobs occur in sandboxed previews; their token must be a UUID.
        if (/^null\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(url.pathname)) return url.href
        const origin = new URL(url.pathname)
        if ((origin.protocol === "https:" || origin.protocol === "http:") &&
            !origin.username && !origin.password &&
            /^\/[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(origin.pathname)) return url.href
    } catch { /* Invalid URLs are ignored rather than surfaced to the user. */ }
    return ""
}

/** Parse only the seven shared avatars and the documented 35 overlay slots. */
export function parseSharedMedia(raw: unknown): ParsedSharedMedia | null {
    if (typeof raw !== "string" || raw.length > MAX_PAYLOAD_LENGTH) return null
    let value: unknown
    try { value = JSON.parse(raw) } catch { return null }
    if (!record(value)) return null
    const result: ParsedSharedMedia = {
        updatedAt: typeof value.updatedAt === "number" && Number.isSafeInteger(value.updatedAt) && value.updatedAt >= 0
            ? value.updatedAt : 0,
    }
    if (record(value.avatars)) {
        const avatars: Partial<Record<BubbleSlug, string>> = {}
        for (const bubble of BUBBLES) {
            const url = safeMediaUrl(value.avatars[bubble])
            if (url) avatars[bubble] = url
        }
        result.avatars = avatars
    }
    if (record(value.overlays)) {
        const overlays: Record<string, string> = {}
        for (const key of OVERLAY_KEYS) {
            const url = safeMediaUrl(value.overlays[key])
            if (url) overlays[key] = url
        }
        result.overlays = overlays
    }
    if (Array.isArray(value.videoOverlayKeys)) {
        result.videoOverlayKeys = [...new Set(value.videoOverlayKeys.filter(
            (key): key is string => typeof key === "string" && OVERLAY_KEYS.has(key),
        ))]
    }
    return result
}

/** The newest valid payload wins, matching the legacy Reset-to-Reframe bridge. */
export function loadSharedMedia(): SharedMedia {
    if (typeof window === "undefined") return {}
    const candidates: ParsedSharedMedia[] = []
    try {
        const media = parseSharedMedia(window.localStorage.getItem(SHARED_MEDIA_KEY))
        if (media) candidates.push(media)
    } catch { /* Storage may be unavailable in private or isolated previews. */ }
    try {
        const name = window.name
        if (typeof name === "string" && name.startsWith(SHARED_MEDIA_WINDOW_PREFIX)) {
            const media = parseSharedMedia(name.slice(SHARED_MEDIA_WINDOW_PREFIX.length))
            if (media) candidates.push(media)
        }
    } catch { /* Same-tab fallback is optional. */ }
    const newest = candidates.sort((a, b) => b.updatedAt - a.updatedAt)[0]
    if (!newest) return {}
    const media: SharedMedia = {}
    if (newest.avatars) media.avatars = newest.avatars
    if (newest.overlays) media.overlays = newest.overlays
    if (newest.videoOverlayKeys) media.videoOverlayKeys = newest.videoOverlayKeys
    return media
}

export function useSharedMedia(): SharedMedia {
    const [media, setMedia] = React.useState<SharedMedia>(loadSharedMedia)
    React.useEffect(() => {
        if (typeof window === "undefined") return
        const sync = () => setMedia(loadSharedMedia())
        const onStorage = (event: StorageEvent) => {
            if (!event.key || event.key === SHARED_MEDIA_KEY) sync()
        }
        const onVisibility = () => {
            if (document.visibilityState === "visible") sync()
        }
        window.addEventListener("storage", onStorage)
        window.addEventListener("focus", sync)
        window.addEventListener(SHARED_MEDIA_EVENT, sync)
        document.addEventListener("visibilitychange", onVisibility)
        sync()
        return () => {
            window.removeEventListener("storage", onStorage)
            window.removeEventListener("focus", sync)
            window.removeEventListener(SHARED_MEDIA_EVENT, sync)
            document.removeEventListener("visibilitychange", onVisibility)
        }
    }, [])
    return media
}

function validTheme(value: unknown): value is SharedTheme {
    return value === "dark" || value === "bright"
}

export function loadSharedTheme(fallback: SharedTheme): SharedTheme {
    if (typeof window !== "undefined") {
        try {
            const theme = window.localStorage.getItem(SHARED_THEME_KEY)
            if (validTheme(theme)) return theme
        } catch { /* The caller's default remains usable without browser storage. */ }
    }
    return fallback
}

export function useSharedTheme(defaultTheme: SharedTheme): [SharedTheme, React.Dispatch<React.SetStateAction<SharedTheme>>] {
    // Start from the prop so server and hydration markup agree; read saved state on mount.
    const [theme, setThemeState] = React.useState<SharedTheme>(defaultTheme)
    const current = React.useRef(theme)
    React.useEffect(() => {
        if (typeof window === "undefined") return
        const update = (next: SharedTheme) => {
            current.current = next
            setThemeState(next)
        }
        const sync = () => update(loadSharedTheme(defaultTheme))
        const onStorage = (event: StorageEvent) => {
            if (!event.key || event.key === SHARED_THEME_KEY) sync()
        }
        const onTheme = (event: Event) => {
            const detail: unknown = (event as CustomEvent<unknown>).detail
            const next = record(detail) ? detail.theme : detail
            if (validTheme(next)) update(next)
            else sync()
        }
        const onVisibility = () => {
            if (document.visibilityState === "visible") sync()
        }
        window.addEventListener("storage", onStorage)
        window.addEventListener("focus", sync)
        window.addEventListener(SHARED_THEME_EVENT, onTheme)
        document.addEventListener("visibilitychange", onVisibility)
        sync()
        return () => {
            window.removeEventListener("storage", onStorage)
            window.removeEventListener("focus", sync)
            window.removeEventListener(SHARED_THEME_EVENT, onTheme)
            document.removeEventListener("visibilitychange", onVisibility)
        }
    }, [defaultTheme])
    const setTheme: React.Dispatch<React.SetStateAction<SharedTheme>> = React.useCallback(nextValue => {
        const next = typeof nextValue === "function" ? nextValue(current.current) : nextValue
        if (!validTheme(next)) return
        current.current = next
        setThemeState(next)
        if (typeof window === "undefined") return
        try { window.localStorage.setItem(SHARED_THEME_KEY, next) } catch { /* Keep the local toggle working. */ }
        window.dispatchEvent(new CustomEvent(SHARED_THEME_EVENT, { detail: { theme: next } }))
    }, [])
    return [theme, setTheme]
}
