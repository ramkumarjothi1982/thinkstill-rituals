import * as React from "react"
import { createRoot } from "react-dom/client"
import ThinkStillReframeV2 from "../deploy/ThinkStillReframeV2"
import "./preview.css"
const query = new URLSearchParams(location.search)
createRoot(document.getElementById("root")!).render(<React.StrictMode><ThinkStillReframeV2
    reframeAiUrl={query.get("ai") || ""} assetBaseUrl="" defaultTheme="dark"
/></React.StrictMode>)
