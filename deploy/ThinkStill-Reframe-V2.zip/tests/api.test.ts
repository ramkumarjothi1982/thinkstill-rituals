import assert from "node:assert/strict"
import { afterEach, test } from "node:test"
import { analyseReframe, isAppsScriptUrl, REQUEST_TIMEOUT_MS } from "../reframe/api"
import { localAnalysis } from "../reframe/engine"
import type { ReframeRequest } from "../reframe/types"

const url = "https://script.google.com/macros/s/AKfycb_TestDeployment_123456/exec"
const request: ReframeRequest = {
    input: "My boss hasn't replied. She must be unhappy with my work.", session_id: "anon_session-1234",
    previous_patterns: [], previous_game_families: [],
}
const originalFetch = globalThis.fetch
afterEach(() => { globalThis.fetch = originalFetch })

test("only a deployed HTTPS Apps Script URL is accepted", () => {
    assert.ok(isAppsScriptUrl(url))
    for (const invalid of ["", "garbage", url.replace("https:", "http:"), url.replace("script.google.com", "script.google.com.evil.test"),
        url.replace("/exec", "/dev"), url + "?key=secret", url + "#fragment", url.replace("https://", "https://user:pass@"),
        "https://example.com/macros/s/abcdef12345/exec", "https://script.google.com/macros/s/a/exec",
    ]) assert.equal(isAppsScriptUrl(invalid), false)
})

test("POST sends only compact scenario data using simple text/plain transport", async () => {
    globalThis.fetch = async (destination, options) => {
        assert.equal(destination, url)
        assert.equal(options?.method, "POST")
        assert.deepEqual(options?.headers, { "Content-Type": "text/plain;charset=UTF-8" })
        assert.equal(options?.credentials, "omit")
        assert.deepEqual(JSON.parse(String(options?.body)), request)
        return new Response(JSON.stringify({ ok: true, analysis: localAnalysis(request.input) }))
    }
    const result = await analyseReframe(url, request)
    assert.equal(result.kind, "analysis")
    if (result.kind === "analysis") assert.equal(result.source, "ai")
})

test("safety is checked before both network access and local fallback", async () => {
    let calls = 0
    globalThis.fetch = async () => { calls++; throw new Error("must not fetch") }
    for (const endpoint of [url, ""]) {
        for (const input of ["I am going to kill myself.", "I overdosed and can't breathe.", "My partner threatened to hit me."]) {
            const result = await analyseReframe(endpoint, { ...request, input })
            assert.equal(result.kind, "safety")
        }
    }
    assert.equal(calls, 0)
})

test("backend safety messages override normal fallback", async () => {
    globalThis.fetch = async () => new Response(JSON.stringify({ ok: false, safety: { kind: "threat", title: "Take this seriously", message: "Seek somewhere safe." } }))
    assert.deepEqual(await analyseReframe(url, request), { kind: "safety", safety: { kind: "threat", title: "Take this seriously", message: "Seek somewhere safe." } })
})

for (const [name, response] of [
    ["quota failure", () => new Response("quota", { status: 429 })],
    ["upstream error", () => new Response("bad gateway", { status: 500 })],
    ["blank response", () => new Response("")],
    ["malformed JSON", () => new Response("```json\n{bad}\n```")],
    ["HTML login page", () => new Response("<html>Login</html>")],
    ["invalid schema", () => new Response(JSON.stringify({ ok: true, analysis: { primary_pattern: "Invented" } }))],
    ["safe server error", () => new Response(JSON.stringify({ ok: false, error: "unavailable" }))],
    ["invalid safety payload", () => new Response(JSON.stringify({ ok: false, safety: { kind: "therapy", title: "bad", message: "bad" } }))],
    ["oversized response", () => new Response("x".repeat(64_001))],
] as const) test(`${name} returns a personalised local fallback`, async () => {
    globalThis.fetch = async () => response()
    const result = await analyseReframe(url, request)
    assert.equal(result.kind, "analysis")
    if (result.kind === "analysis") {
        assert.equal(result.source, "local")
        assert.equal(result.analysis.fact, "My boss hasn't replied.")
        assert.equal(result.analysis.primary_pattern, "Mind Reading")
    }
})

test("network rejection never exposes technical error text", async () => {
    globalThis.fetch = async () => { throw new Error("secret provider stack trace") }
    const result = await analyseReframe(url, request)
    assert.equal(result.kind, "analysis")
    assert.doesNotMatch(JSON.stringify(result), /secret provider|stack trace/u)
})

test("a timeout interrupts a hanging fetch and completes locally", async context => {
    context.mock.timers.enable({ apis: ["setTimeout"] })
    let fetchSignal: AbortSignal | null | undefined
    globalThis.fetch = async (_destination, options) => {
        fetchSignal = options?.signal
        return new Promise<Response>(() => {})
    }
    const pending = analyseReframe(url, request)
    context.mock.timers.tick(REQUEST_TIMEOUT_MS + 1)
    const result = await pending
    assert.ok(fetchSignal?.aborted)
    assert.equal(result.kind, "analysis")
    if (result.kind === "analysis") assert.equal(result.source, "local")
})

test("caller cancellation resolves without breaking the console", async () => {
    globalThis.fetch = async () => new Promise<Response>(() => {})
    const controller = new AbortController()
    const pending = analyseReframe(url, request, controller.signal)
    controller.abort()
    const result = await pending
    assert.equal(result.kind, "analysis")
    if (result.kind === "analysis") assert.equal(result.source, "local")
})

test("invalid configuration and oversize input do not send network requests", async () => {
    let calls = 0
    globalThis.fetch = async () => { calls++; throw new Error("must not fetch") }
    await analyseReframe("", request)
    await analyseReframe(url, { ...request, input: "x".repeat(1801) })
    await analyseReframe(url, { ...request, session_id: "bad" })
    const controller = new AbortController()
    controller.abort()
    await analyseReframe(url, request, controller.signal)
    assert.equal(calls, 0)
})
