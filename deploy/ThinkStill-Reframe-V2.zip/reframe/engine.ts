import { GAME_FAMILIES, PATTERNS } from "./types"
import type { BubbleSlug, ChoiceRole, ReframeAnalysis, ReframeGameContent, ReframeGameFamily, ReframePattern, SafetyResult } from "./types"

export const INPUT_LIMIT = 1800
export const TEXT_LIMIT = 420
export const KEEP_LIMIT = 180

/** Ordered compatible games. The model supplies data; this map controls routing. */
export const GAME_MAP: Record<ReframePattern, readonly ReframeGameFamily[]> = {
    "Mind Reading": ["FACT_VS_GUESS", "INTENT_MACHINE", "REJECTION_FILL"],
    "Fortune Telling": ["CRYSTAL_BALL", "MYSTERY_BOX"],
    "Catastrophising": ["DISASTER_CHAIN", "CRYSTAL_BALL"],
    "Personalisation": ["RESPONSIBILITY_PIE", "CONTROL_SORTER", "FACT_VS_GUESS"],
    "All-or-Nothing Thinking": ["MISSING_MIDDLE", "PEEL_LABEL"],
    "Overgeneralising": ["ONE_NOT_ALWAYS", "DISASTER_CHAIN", "REJECTION_FILL"],
    "Emotional Reasoning": ["FEELING_NOT_EVIDENCE", "FACT_VS_GUESS", "CRYSTAL_BALL"],
    "Negative Filter": ["FILTER_CLEANER", "FACT_VS_GUESS"],
    "Discounting the Positive": ["FILTER_CLEANER", "FACT_VS_GUESS"],
    "Should / Must": ["SHOULD_SHREDDER", "CONTROL_SORTER"],
    "Self-Labelling": ["PEEL_LABEL", "MISSING_MIDDLE"],
    "Comparison Story": ["WRONG_SCOREBOARD", "FILTER_CLEANER"],
    "Rejection Story": ["REJECTION_FILL", "FACT_VS_GUESS"],
    "Intent Assumption": ["INTENT_MACHINE", "FACT_VS_GUESS"],
    "Perfectionism": ["MISSING_MIDDLE", "SHOULD_SHREDDER"],
    "Blame": ["RESPONSIBILITY_PIE", "CONTROL_SORTER"],
    "Control Error": ["CONTROL_SORTER", "RESPONSIBILITY_PIE"],
    "Uncertainty Intolerance": ["MYSTERY_BOX", "FACT_VS_GUESS"],
    "Meaning-Making": ["FACT_VS_GUESS", "REJECTION_FILL"],
    "Failure Interpretation": ["PEEL_LABEL", "MISSING_MIDDLE", "CRYSTAL_BALL"],
}

export function compatibleGames(pattern: ReframePattern): ReframeGameFamily[] {
    return [...GAME_MAP[pattern]]
}

const normalise = (value: string) => value.toLowerCase().replace(/[‘’ʼ]/gu, "'").replace(/[“”]/gu, '"')
const clip = (value: string, max = TEXT_LIMIT) => {
    // eslint-disable-next-line no-control-regex -- Strip non-display control characters from user text.
    const text = value.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/gu, "").trim()
    return text.length > max ? `${text.slice(0, max - 1).trimEnd()}…` : text
}

const urgent: SafetyResult = {
    kind: "immediate", title: "Safety comes first",
    message: "Contact your local emergency services now. If you can, move away from immediate danger and ask someone you trust to stay with you. Don't wait for a reframe.",
}
const threat: SafetyResult = {
    kind: "threat", title: "Take the threat seriously",
    message: "If danger is immediate, contact local emergency services. Move somewhere safer if you can and reach someone you trust or a local violence support service. You deserve protection.",
}

/** Deliberately conservative: obvious emergencies override the model and every game. */
export function detectSafety(input: string): SafetyResult | null {
    // eslint-disable-next-line no-control-regex -- Invisible characters must not bypass the safety gate.
    const text = normalise(input).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/gu, "")
    const clauses = text.split(/(?:[.!?\n]|\bbut\b|\bhowever\b|\band (?=(?:now )?(?:i|my|he|she|they|someone)\b))/u).filter(Boolean)
    for (let clause of clauses) {
        // Fictional quotations, figurative sayings and explicit examples are not reports of danger.
        const contextual = /\b(?:movie|film|novel|book|lyrics?|song|fictional|character|quote|quotation|metaphor|example|test case|joke|joking|figurative|not literal)\b/u.test(clause)
        if (contextual) {
            clause = clause.replace(/"[^"]*"|'[^']{8,}'/gu, "")
            if (/\b(?:movie|film|novel|book|lyrics?|song|fictional|character|quote|quotation|example|test case|joke)\b.{0,60}\b(?:says?|said|reads?|contains?|goes?|uses?|about|with|is|was)\b/u.test(clause) || /\b(?:metaphor|figurative|not literal)\b/u.test(clause)) continue
        }
        if (/\b(?:if|when) (?:i|someone|a person|somebody) (?:were to |was |is |has )?(?:overdose|unconscious|not breathing|kill myself)/u.test(clause)) continue
        const historical = /\b(?:years? ago|last year|in the past|as a child|when i was a child|recovered|no longer|was treated)\b/u.test(clause)
        const intent = /\b(?:i(?:'m| am) (?:going to|about to|planning to|gonna)|i (?:will|intend to|plan to|want to|wanna|might|may))\s+(?:kill|harm|hurt|cut|stab|shoot|hang)\s+(?:myself|me)\b/u
        const suicidalIntent = /\b(?:i want to die|i(?:'m| am) suicidal|i (?:will|plan to|intend to) (?:end|take) my life|i(?:'m| am) (?:going to|about to) (?:end|take) my life)\b/u
        const activeSelf = /\b(?:i(?:'m| am) (?:killing|harming|hurting|cutting) myself|i (?:have|just) (?:cut|hurt|harmed) myself|i (?:have |just )?(?:taken|swallowed) (?:too many|a lot of|all (?:of )?my|(?:a |a whole |the whole )?bottle of) (?:pills|tablets))\b|\b(?:i(?:'m| am) (?:going to|about to)|i (?:will|plan to|want to)) (?:slit|cut) my wrists?\b|\b(?:i(?:'m| am) (?:going to|about to)|i (?:will|plan to|want to)) jump off (?:a|the) (?:bridge|roof|building)\b/u
        const deniesStatement = /\b(?:not saying|don't mean|do not mean|never said|didn't say|did not say|no intention of)\b/u.test(clause)
        const idiomatic = /\bkill myself (?:laughing|with (?:work|paperwork)|at the gym)\b/u.test(clause)
        if (!historical && !deniesStatement && !idiomatic && (intent.test(clause) || suicidalIntent.test(clause) || activeSelf.test(clause))) return { ...urgent }
        const thirdPartyIntent = /\b(?:my (?:friend|partner|child|son|daughter|parent|mother|father|mom|mum|dad|sister|brother)|he|she|they) (?:said |says )?(?:they |he |she )?(?:is|are|'s|'re) (?:going|about) to (?:kill|hurt|harm) (?:themselves|himself|herself)\b|\b(?:he's|she's|they're) (?:going|about|planning) to (?:kill|hurt|harm) (?:himself|herself|themselves)\b/u
        if (!historical && !deniesStatement && thirdPartyIntent.test(clause)) return { ...urgent }
        // A person, rather than an idiomatic target such as "the presentation", is required.
        const violenceIntent = /\b(?:i(?:'m| am) (?:going to|about to|planning to|gonna)|i (?:will|intend to|plan to|want to|wanna))\s+(?:kill|stab|shoot|attack|seriously hurt|seriously harm|hurt|harm)\s+(?:(?:my|our|the) (?:partner|boyfriend|girlfriend|wife|husband|boss|friend|mother|father|child|kids?|neighbou?r)|him|her|them|you|someone|somebody|people|another person)\b/u
        if (!historical && !deniesStatement && violenceIntent.test(clause) && !/hurt (?:his|her|their) feelings/u.test(clause)) return { ...urgent }
        const overdose = /\b(?:i|he|she|they|my (?:friend|partner|child|son|daughter|mother|father|mom|mum|dad|sister|brother|baby)) (?:have |has |just |have just |has just )?overdosed\b|\b(?:i'm|i am|he is|she is|they are) overdosing\b|\bi (?:took|have taken|swallowed) too many (?:pills|tablets)\b/u
        const breathing = /\b(?:i|he|she|they|my (?:friend|partner|child|son|daughter|mother|father|mom|mum|dad|sister|brother|baby)) (?:can't|cannot|can not|is not|isn't|are not|aren't|am not) breath(?:e|ing)\b|\b(?:someone|a person|my (?:friend|partner|child|son|daughter|mother|father|mom|mum|dad|sister|brother|baby)) (?:is |isn't )?not breathing\b/u
        const unconscious = /\b(?:i|he|she|they|someone|my (?:friend|partner|child|son|daughter|mother|father|mom|mum|dad|sister|brother|baby)) (?:is|are|am|'s|'re) unconscious\b/u
        const chest = /\b(?:i (?:have|am having)|i'm having|he has|she has|they have|my (?:partner|mother|father|friend|mom|mum|dad|sister|brother) has) (?:severe|crushing|intense) chest pain\b/u
        const bareEmergency = /^(?:(?:severe|crushing|intense) chest pain|not breathing|unconscious|overdose|overdosed)$/u.test(clause.trim())
        if (!historical && (overdose.test(clause) || breathing.test(clause) || unconscious.test(clause) || chest.test(clause) || bareEmergency)) return { ...urgent }
        // A reported threat is factual harm. It never becomes a catastrophe game.
        const reportedThreat = /\b(?:threatened|threatening|threatens) (?:to |that (?:he|she|they) (?:will|would) )?(?:hit|hurt|kill|attack|stab|shoot|beat|assault)\b/u
        const directedThreat = /\b(?:he|she|they|my (?:partner|boyfriend|girlfriend|wife|husband|boss|friend)) (?:said |says )?(?:he |she |they )?(?:will|would|is going to|are going to) (?:hit|hurt|kill|attack|stab|shoot|beat) me\b|\b(?:he'll|she'll|they'll) (?:hit|hurt|kill|attack|stab|shoot|beat) me\b/u
        const currentViolence = /\b(?:he|she|they|my (?:partner|boyfriend|girlfriend|wife|husband|parent)) (?:is |are |keeps? )?(?:hitting|beating|attacking|choking|strangling) me\b|\b(?:i(?:'m| am) in immediate danger|i(?:'m| am) being (?:attacked|assaulted|held hostage))\b/u
        const deniesThreat = /\b(?:not|never|nobody|no one|hasn't|haven't|hadn't|didn't|doesn't|don't|isn't|aren't|wasn't|weren't)\s+(?:ever\s+)?(?:threatened|threatening|threatens|threaten|hitting|beating|attacking|choking|strangling)\b/u.test(clause)
        const deniesCurrent = /\b(?:not|never|isn't|aren't|wasn't|weren't)\s+(?:ever\s+)?(?:hitting|beating|attacking|choking|strangling)\b/u.test(clause)
        if (currentViolence.test(clause) && !deniesCurrent) return { ...threat }
        if ((reportedThreat.test(clause) || directedThreat.test(clause)) && !deniesThreat && !deniesStatement) return { ...threat }
    }
    return null
}

type RecordValue = Record<string, unknown>
const record = (value: unknown): value is RecordValue => typeof value === "object" && value !== null && !Array.isArray(value)
// eslint-disable-next-line no-control-regex -- Reject control characters at the model/storage trust boundary.
const textField = (value: unknown, max = TEXT_LIMIT): value is string => typeof value === "string" && value.trim().length > 0 && value.length <= max && !/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F\u202A-\u202E\u2066-\u2069]/u.test(value) && !/https?:\/\/|www\.|javascript:|data:|```|<[^>]*>|(?:^|\n)\s*(?:import\s|export\s|function\s|(?:const|let|var)\s+\w+\s*=)/iu.test(value)
const isPattern = (value: unknown): value is ReframePattern => typeof value === "string" && (PATTERNS as readonly string[]).includes(value)
const isGame = (value: unknown): value is ReframeGameFamily => typeof value === "string" && (GAME_FAMILIES as readonly string[]).includes(value)
const roles: readonly ChoiceRole[] = ["fact", "story", "grounded", "distorted", "unknown"]
const contentFields = new Set(["fact_card", "story_card", "unknown_card", "choices", "prediction_text", "chain_items", "label_text", "scale_start", "scale_target", "control_items", "responsibility_items"])

function validateContent(value: unknown, fact: string, story: string, unknown: string): ReframeGameContent | null {
    if (!record(value) || Object.keys(value).some(key => !contentFields.has(key))) return null
    const content: ReframeGameContent = { fact_card: fact, story_card: story, unknown_card: unknown }
    for (const key of ["fact_card", "story_card", "unknown_card", "prediction_text", "label_text"] as const) {
        if (value[key] !== undefined) {
            if (!textField(value[key])) return null
            content[key] = value[key].trim()
        }
    }
    for (const key of ["scale_start", "scale_target"] as const) {
        const number = value[key]
        if (number !== undefined) {
            if (typeof number !== "number" || !Number.isFinite(number) || number < 0 || number > 100) return null
            content[key] = number
        }
    }
    if (value.choices !== undefined) {
        if (!Array.isArray(value.choices) || value.choices.length < 2 || value.choices.length > 8) return null
        const choices: NonNullable<ReframeGameContent["choices"]> = []
        const ids = new Set<string>()
        for (const choice of value.choices) {
            if (!record(choice) || Object.keys(choice).some(key => !["id", "text", "role"].includes(key)) || typeof choice.id !== "string" || !/^[A-Za-z0-9_-]{1,40}$/u.test(choice.id) || ids.has(choice.id) || !textField(choice.text)) return null
            if (choice.role !== undefined && (typeof choice.role !== "string" || !(roles as readonly string[]).includes(choice.role))) return null
            ids.add(choice.id)
            choices.push({ id: choice.id, text: choice.text.trim(), ...(choice.role !== undefined ? { role: choice.role as ChoiceRole } : {}) })
        }
        content.choices = choices
    }
    if (value.chain_items !== undefined) {
        if (!Array.isArray(value.chain_items) || value.chain_items.length < 2 || value.chain_items.length > 6 || !value.chain_items.every(item => textField(item))) return null
        content.chain_items = value.chain_items.map(item => (item as string).trim())
    }
    if (value.control_items !== undefined) {
        if (!Array.isArray(value.control_items) || value.control_items.length < 2 || value.control_items.length > 8) return null
        const items: NonNullable<ReframeGameContent["control_items"]> = []
        for (const item of value.control_items) {
            if (!record(item) || Object.keys(item).some(key => !["text", "controllable", "influence"].includes(key)) || !textField(item.text) || typeof item.controllable !== "boolean" || (item.influence !== undefined && typeof item.influence !== "boolean")) return null
            items.push({ text: item.text.trim(), controllable: item.controllable, ...(item.influence !== undefined ? { influence: item.influence } : {}) })
        }
        content.control_items = items
    }
    if (value.responsibility_items !== undefined) {
        if (!Array.isArray(value.responsibility_items) || value.responsibility_items.length < 2 || value.responsibility_items.length > 8) return null
        const items: NonNullable<ReframeGameContent["responsibility_items"]> = []
        for (const item of value.responsibility_items) {
            if (!record(item) || Object.keys(item).some(key => !["text", "weight"].includes(key)) || !textField(item.text) || (item.weight !== undefined && (typeof item.weight !== "number" || !Number.isFinite(item.weight) || item.weight < 0 || item.weight > 100))) return null
            items.push({ text: item.text.trim(), ...(item.weight !== undefined ? { weight: item.weight } : {}) })
        }
        content.responsibility_items = items
    }
    return content
}

/** Whitelist and copy model data. Unknown game content can never become UI or executable code. */
export function validateAnalysis(value: unknown): ReframeAnalysis | null {
    if (!record(value) || (value.ok !== undefined && value.ok !== true)) return null
    const allowed = new Set(["ok", "event", "interpretation", "emotion", "primary_pattern", "secondary_patterns", "fact", "story", "unknown", "reframe", "keep", "game_family", "game_content", "confidence"])
    if (Object.keys(value).some(key => !allowed.has(key))) return null
    for (const key of ["event", "interpretation", "fact", "story", "unknown", "reframe"] as const) if (!textField(value[key])) return null
    if (!textField(value.keep, KEEP_LIMIT) || !isPattern(value.primary_pattern) || !isGame(value.game_family) || !GAME_MAP[value.primary_pattern].includes(value.game_family)) return null
    if (typeof value.confidence !== "number" || !Number.isFinite(value.confidence) || value.confidence < 0 || value.confidence > 1) return null
    const secondary = value.secondary_patterns ?? []
    if (!Array.isArray(secondary) || secondary.length > 3 || !secondary.every(isPattern) || new Set(secondary).size !== secondary.length || secondary.includes(value.primary_pattern)) return null
    let emotion: string[] | undefined
    if (value.emotion !== undefined) {
        if (!Array.isArray(value.emotion) || value.emotion.length > 5 || !value.emotion.every(item => textField(item, 60))) return null
        emotion = value.emotion.map(item => (item as string).trim())
    }
    const fact = (value.fact as string).trim()
    const story = (value.story as string).trim()
    const unknown = (value.unknown as string).trim()
    const game_content = validateContent(value.game_content ?? {}, fact, story, unknown)
    if (!game_content) return null
    return {
        ok: true, event: (value.event as string).trim(), interpretation: (value.interpretation as string).trim(),
        ...(emotion ? { emotion } : {}), primary_pattern: value.primary_pattern, secondary_patterns: secondary,
        fact, story, unknown, reframe: (value.reframe as string).trim(), keep: value.keep.trim(),
        game_family: value.game_family, game_content, confidence: value.confidence,
    }
}

function isUnconfirmedThought(value: string): boolean {
    if (/\b(?:said|told|wrote|called|texted|messaged)\b/iu.test(value)) return false
    return /\b(?:i['’]m|i am) (?:a |an |just )?(?:useless|worthless|failure|loser|stupid|idiot|terrible|incompetent|bad (?:parent|person|mother|father)|going to fail)\b|\b(?:he|she|they|my (?:boss|manager|friend|partner))\b.{0,60}\b(?:probably thinks?|must think|thinks? i|hate(?:s)? me|unhappy with me|losing interest)\b|^(?:nobody|everyone|no one)\b/iu.test(value)
}

function observedEvent(value: string): string {
    return isUnconfirmedThought(value) ? clip(`I put this thought into words: “${clip(value, 350)}”`) : clip(value)
}

function splitSituation(input: string): { event: string; interpretation: string; explicit: boolean } {
    const sentences = input.split(/(?<=[.!?])\s+|\n+/u).map(part => part.trim()).filter(Boolean)
    if (sentences.length > 1) return { event: observedEvent(sentences[0]), interpretation: clip(sentences.slice(1).join(" ")), explicit: true }
    const connective = /\s*,?\s+(?:so|therefore|that (?:probably )?means|which means|and (?:he|she|they) (?:probably |must |definitely )?(?:think|thinks|hate|hates))\s+/iu.exec(input)
    if (connective && connective.index > 5) {
        const event = input.slice(0, connective.index).replace(/,$/u, "").trim()
        const interpretation = input.slice(connective.index).replace(/^\s*,?\s*(?:so|therefore|that (?:probably )?means|which means|and)\s+/iu, "")
        return { event: observedEvent(event), interpretation: clip(interpretation), explicit: true }
    }
    if (isUnconfirmedThought(input)) return { event: observedEvent(input), interpretation: clip(input), explicit: true }
    return { event: clip(input), interpretation: "What this event says beyond the words I've described is still open.", explicit: false }
}

type Candidate = { pattern: ReframePattern; score: number }
function findPatterns(input: string, interpretation: string, explicit: boolean): Candidate[] {
    const text = normalise(input)
    const thought = normalise(explicit ? interpretation : input)
    const scores = new Map<ReframePattern, number>()
    const add = (pattern: ReframePattern, score: number, condition: boolean) => { if (condition) scores.set(pattern, Math.max(scores.get(pattern) ?? 0, score)) }
    const inferredOtherThought = /\b(?:he|she|they|boss|manager|friend|partner)\b.{0,70}\b(?:think|thinks|believes?|says?|said)\b/u.test(thought)
    const selfLabel = !inferredOtherThought && /\b(?:i'm|i am|i feel like (?:i'm|i am|a)) (?:just |such |a |an )*(?:useless|worthless|a failure|failure|loser|stupid|idiot|terrible|incompetent|bad (?:parent|person|mother|father)|not good enough|a disaster)\b/u.test(thought)
    const acceptedInsult = /\b(?:called me|told me (?:i'm|i am)|said (?:i'm|i am))\b/u.test(text) && /\b(?:maybe (?:they're|they are|he's|he is|she's|she is) right|maybe (?:i'm|i am)|(?:they're|they are|he's|she's) right)\b/u.test(thought)
    add("Self-Labelling", 100, selfLabel || acceptedInsult)
    add("Emotional Reasoning", 98, /\b(?:i feel|i'm feeling|i am feeling|because i feel)\b/u.test(text) && /\b(?:so|therefore|must|means|proof)\b/u.test(text))
    add("Uncertainty Intolerance", 94, /\b(?:don't know|do not know|not sure|no idea|can't tell|cannot tell|haven't heard|have not heard)\b/u.test(text) && /\b(?:failed|bad|worst|rejected|wrong|must mean|probably means)\b/u.test(thought))
    add("Overgeneralising", 90, /\b(?:always|never|everyone|everybody|nobody|no one|nothing ever|every time)\b/u.test(thought))
    add("Intent Assumption", 88, /\b(?:on purpose|deliberately|wanted to hurt me|trying to hurt me|did it to hurt me|trying to upset me)\b/u.test(thought))
    add("Mind Reading", 86, /\b(?:he|she|they|my (?:boss|manager|friend|partner|boyfriend|girlfriend|daughter|son))\b.{0,90}\b(?:thinks?|hate|hates|unhappy|angry|mad|losing interest|getting distant|judging|don't like|doesn't like|do not like|does not like)\b/u.test(thought))
    add("Comparison Story", 84, /\b(?:better than me|behind everyone|behind them|compared (?:to|with)|their life|everyone else|more successful than me|doing better than me)\b/u.test(thought))
    add("Catastrophising", 84, /\b(?:everything is ruined|life is over|relationship is over|total disaster|the worst|catastrophe|everything will fall apart|ruined everything|end of the world)\b/u.test(thought))
    add("Rejection Story", 80, /\b(?:losing interest|don't like me|doesn't like me|do not like me|does not like me|nobody wants me|unwanted|they hate me|abandon me|leave me|don't want me|doesn't want me)\b/u.test(thought))
    add("Perfectionism", 78, /\b(?:perfect|perfection|any mistake|no mistakes|get everything right|anything less than)\b/u.test(thought))
    add("All-or-Nothing Thinking", 77, /\b(?:completely|totally|total failure|all or nothing|either .+ or|terrible at|nothing right|everything wrong|one mistake)\b/u.test(thought) || selfLabel && /\b(?:one mistake|a mistake)\b/u.test(text))
    add("Discounting the Positive", 76, /\b(?:doesn't count|does not count|just luck|only luck|anyone could|they're just being nice|they are just being nice|not a real achievement)\b/u.test(thought))
    add("Negative Filter", 75, /\b(?:only (?:see|remember|notice) the bad|all i (?:see|remember|notice)|can't see anything good|can not see anything good|only the mistake)\b/u.test(thought))
    add("Control Error", 74, /\b(?:control everything|make (?:them|him|her) (?:happy|like me)|must control|responsible for (?:their|his|her) feelings|i can control)\b/u.test(thought))
    add("Should / Must", 73, /\b(?:i|we|everyone|people|they) (?:should|must|have to)|\bshouldn't have|\bshould not have/u.test(thought))
    add("Blame", 72, /\b(?:all (?:my|their|his|her) fault|entirely (?:my|their|his|her) fault|only (?:my|their|his|her) fault|i blame|to blame for everything)\b/u.test(thought))
    add("Personalisation", 71, /\b(?:because of me|my fault|it's me|it is me|about me|unhappy with my work|angry with me|mad at me)\b/u.test(thought))
    add("Fortune Telling", 70, /\b(?:going to|will|won't|will not|about to|definitely|probably)\b.{0,90}\b(?:fail|failed|bad|happen|get hired|work out|reject|lose|end|leave|never)\b/u.test(thought))
    add("Failure Interpretation", 69, /\b(?:means i failed|means i'm a failure|means i am a failure|proof i failed|can't succeed|cannot succeed)\b/u.test(thought))
    add("Mind Reading", 86, /\b(?:he|she|they) (?:probably |must |definitely )?(?:is|are|'s|'re) (?:unhappy|angry|mad)\b/u.test(thought))
    // Secondary patterns from the specific situation, without inventing a new interpretation.
    add("Fortune Telling", 70, scores.has("Emotional Reasoning") && /\b(?:about to|will|going to)\b/u.test(thought))
    add("Meaning-Making", 35, true)
    return [...scores].map(([pattern, score]) => ({ pattern, score })).sort((a, b) => b.score - a.score)
}

const frames: Record<ReframePattern, { reframe: string; unknown: string; keep: string; twist: string; bubble: BubbleSlug }> = {
    "Mind Reading": { reframe: "I don't yet know what they think or what this response means.", unknown: "What they think and why they responded this way.", keep: "Missing information isn't proof of criticism.", twist: "You know the event. Their thoughts are still unknown.", bubble: "sync" },
    "Fortune Telling": { reframe: "This prediction is not a settled outcome. I can take the next step and find out more.", unknown: "What the outcome will actually be.", keep: "A prediction isn't a result.", twist: "The future hasn't handed in its answer.", bubble: "still" },
    "Catastrophising": { reframe: "The event matters. The worst ending is not established by it.", unknown: "Which next steps or outcomes will actually follow.", keep: "A possible ending isn't a proven chain.", twist: "The first event doesn't prove every link after it.", bubble: "rush" },
    "Personalisation": { reframe: "I can look at my part without assuming this whole situation is about me.", unknown: "How much of this situation relates to me and what else contributed.", keep: "My part doesn't automatically mean all of it.", twist: "A contribution and total responsibility are different.", bubble: "sync" },
    "All-or-Nothing Thinking": { reframe: "This moment can be difficult without becoming a total verdict on my ability.", unknown: "The fuller picture beyond this moment.", keep: "One moment isn't the whole scale.", twist: "There is space between perfect and total failure.", bubble: "patch" },
    "Overgeneralising": { reframe: "This is one described event. It doesn't settle every person, every attempt or every future outcome.", unknown: "How other people, attempts or future situations will turn out.", keep: "One isn't always.", twist: "One event can't speak for every event.", bubble: "loopie" },
    "Emotional Reasoning": { reframe: "My feeling is real. It doesn't by itself establish what is happening or what will happen next.", unknown: "What evidence, beyond the feeling, supports the conclusion.", keep: "The feeling is real. The conclusion needs evidence.", twist: "A feeling can be valid without being a forecast.", bubble: "still" },
    "Negative Filter": { reframe: "The difficult part matters. I can also check for other relevant facts without forcing a positive spin.", unknown: "What relevant information my current focus might be leaving out.", keep: "Widen the frame without erasing the difficulty.", twist: "The part in focus may not be the whole picture.", bubble: "patch" },
    "Discounting the Positive": { reframe: "I can let supported information count without dismissing it or letting it cancel what was difficult.", unknown: "Which parts are supported and which parts I'm dismissing without checking.", keep: "Relevant information is allowed to count.", twist: "Evidence doesn't need to fit the old story to count.", bubble: "patch" },
    "Should / Must": { reframe: "This matters to me. I can choose a workable next step without turning a rule into a verdict on my worth.", unknown: "Which expectations are real requirements and which are extra pressure.", keep: "A preference can guide me without judging me.", twist: "A goal doesn't need to become a sentence against you.", bubble: "drop" },
    "Self-Labelling": { reframe: "This describes a moment, not my whole ability or identity.", unknown: "The fuller picture of my ability and identity beyond this moment.", keep: "An event isn't my identity.", twist: "A label can't contain a whole person.", bubble: "glitch" },
    "Comparison Story": { reframe: "I can notice the comparison without treating incomplete information about another life as a fair score for mine.", unknown: "The full context on both sides of the comparison.", keep: "Different data makes a poor scoreboard.", twist: "A fair comparison needs the same kind of information.", bubble: "glitch" },
    "Rejection Story": { reframe: "The event can hurt. It doesn't establish my worth or every person's feelings about me.", unknown: "What this event means beyond what was actually said or done.", keep: "A response isn't a verdict on my worth.", twist: "The automatic ending added more than the event said.", bubble: "drop" },
    "Intent Assumption": { reframe: "I can take the behaviour seriously while keeping its unconfirmed motive separate.", unknown: "Their motive, unless they have clearly stated it.", keep: "Behaviour and guessed intent are different facts.", twist: "Observed behaviour doesn't expose the whole motive.", bubble: "sync" },
    "Perfectionism": { reframe: "I can aim to do this well without treating any imperfection as total failure.", unknown: "What a workable, good-enough standard would look like here.", keep: "An imperfect step can still count.", twist: "The middle contains more than failure.", bubble: "patch" },
    "Blame": { reframe: "I can look for supported responsibility without assigning all of it where the evidence is incomplete.", unknown: "The actual contribution of each known or unknown part.", keep: "Responsibility needs evidence, not a reflex.", twist: "Unknown is a valid part of the responsibility picture.", bubble: "sync" },
    "Control Error": { reframe: "I can choose my next action. I may influence an outcome without being able to control it.", unknown: "Which outcomes are open to influence and which are outside my control.", keep: "My next move is mine. Every outcome isn't.", twist: "Influence doesn't come with complete control.", bubble: "drop" },
    "Uncertainty Intolerance": { reframe: "Not knowing yet doesn't establish bad news. I can leave the answer open while deciding my next step.", unknown: "The answer I haven't received or established yet.", keep: "Unknown doesn't mean bad news.", twist: "An unopened answer is still unopened.", bubble: "still" },
    "Meaning-Making": { reframe: "I can keep what I've described and leave its larger meaning open until I have more information.", unknown: "What additional information would support a larger conclusion.", keep: "Keep the event. Check the added meaning.", twist: "An event and its meaning aren't the same thing.", bubble: "glitch" },
    "Failure Interpretation": { reframe: "An outcome can matter without settling my identity or every future attempt.", unknown: "What this result says about this attempt, rather than my whole identity.", keep: "A result isn't my whole story.", twist: "The outcome belongs to an attempt, not a whole identity.", bubble: "patch" },
}

function extractLabel(input: string, story: string): string {
    const self = /\b(?:i['’]m|i am|i feel like (?:i['’]m|i am|a))\s+(.+?)(?:[.!?]|$)/iu.exec(story)
    const insult = /\b(?:called me|told me (?:i['’]m|i am)|said (?:i['’]m|i am))\s+["“]?(.+?)(?:[.!?"”]|$)/iu.exec(input)
    return clip(self?.[1] ?? insult?.[1] ?? story, 160)
}

export function localAnalysis(input: string, previousPatterns: ReframePattern[] = [], previousGames: ReframeGameFamily[] = []): ReframeAnalysis {
    const cleaned = clip(input, INPUT_LIMIT) || "I haven't put the event into words yet."
    const situation = splitSituation(cleaned)
    const candidates = findPatterns(cleaned, situation.interpretation, situation.explicit)
    let primary = candidates[0]
    // A retry can use a genuinely close secondary angle; it cannot invent a different diagnosis.
    if (previousPatterns[previousPatterns.length - 1] === primary.pattern) {
        const alternate = candidates.find(candidate => candidate.pattern !== primary.pattern && candidate.score >= primary.score * 0.9)
        if (alternate) primary = alternate
    }
    const secondary = candidates.filter(candidate => candidate.pattern !== primary.pattern && candidate.score >= 65).slice(0, 3).map(candidate => candidate.pattern)
    const frame = frames[primary.pattern]
    const fact = situation.event
    const story = situation.interpretation
    const acceptsInsult = primary.pattern === "Self-Labelling" && /\b(?:called me|told me|said)\b/iu.test(cleaned)
    // Keep the cognitive move even when the observed event fills its entire text allowance.
    const reframe = clip(`${clip(fact, 200)} ${acceptsInsult ? "That label is something said to me, not a complete account of who I am. I can take the hurt seriously without accepting it as my identity." : frame.reframe}`)
    const keep = acceptsInsult ? "A label said to me isn't my identity." : frame.keep
    const games = compatibleGames(primary.pattern)
    // Prefer an unplayed compatible game; don't route a pattern into an unrelated game for novelty.
    let game = games.find(item => !previousGames.includes(item)) ?? games.find(item => item !== previousGames[previousGames.length - 1]) ?? games[0]
    if (!previousGames.length && primary.pattern === "Mind Reading" && secondary.includes("Rejection Story")) game = "REJECTION_FILL"
    const unknown = acceptsInsult ? "A fuller picture of me; the insult alone cannot establish my identity." : frame.unknown
    const choices: NonNullable<ReframeGameContent["choices"]> = game === "FILTER_CLEANER" || game === "WRONG_SCOREBOARD" || game === "SHOULD_SHREDDER"
        ? [{ id: "added", text: story, role: "distorted" }, { id: "grounded", text: clip(frame.reframe), role: "grounded" }]
        : [{ id: "fact", text: fact, role: "fact" }, { id: "story", text: story, role: "story" }, { id: "unknown", text: unknown, role: "unknown" }]
    const game_content: ReframeGameContent = {
        fact_card: fact, story_card: story, unknown_card: unknown, choices,
        prediction_text: story, chain_items: [fact, story], label_text: extractLabel(cleaned, story), scale_start: 0, scale_target: 50,
        control_items: [
            { text: "My next action in this situation", controllable: true },
            { text: "Other people's responses", controllable: false, influence: true },
            { text: "My choice to seek more information", controllable: true },
        ],
        responsibility_items: [{ text: "My part, where supported" }, { text: "Unknown contribution" }],
    }
    const emotion = [...normalise(cleaned).matchAll(/\b(anxious|angry|sad|scared|hurt|ashamed|frustrated|rejected|lonely)\b/gu)].map(match => match[1])
    return {
        ok: true, event: fact, interpretation: story, emotion: [...new Set(emotion)].slice(0, 5),
        primary_pattern: primary.pattern, secondary_patterns: secondary, fact, story, unknown,
        reframe, keep, game_family: game, game_content,
        confidence: primary.score >= 90 ? 0.66 : primary.score >= 65 ? 0.55 : 0.3,
    }
}

export function plotTwist(analysis: ReframeAnalysis): string {
    if (analysis.primary_pattern === "Self-Labelling" && /called me|told me/iu.test(analysis.fact)) return "A label said to you isn't your identity."
    return frames[analysis.primary_pattern].twist
}

export function bubbleForPattern(pattern: ReframePattern): BubbleSlug {
    return frames[pattern].bubble
}
