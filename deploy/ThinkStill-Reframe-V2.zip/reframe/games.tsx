import * as React from "react"
import type { ReframeAnalysis, ReframeGameFamily, ReframeGameProps } from "./types"

export const GAME_NAMES: Record<ReframeGameFamily, string> = {
    FACT_VS_GUESS: "Fact vs guess", CRYSTAL_BALL: "Crystal ball", DISASTER_CHAIN: "Disaster chain",
    MISSING_MIDDLE: "The missing middle", ONE_NOT_ALWAYS: "One ≠ always", FEELING_NOT_EVIDENCE: "Feeling ≠ evidence",
    PEEL_LABEL: "Peel the label", WRONG_SCOREBOARD: "Wrong scoreboard", SHOULD_SHREDDER: "Should shredder",
    CONTROL_SORTER: "Control sorter", RESPONSIBILITY_PIE: "Responsibility pie", MYSTERY_BOX: "Mystery box",
    FILTER_CLEANER: "Filter cleaner", INTENT_MACHINE: "Intent machine", REJECTION_FILL: "Rejection fill-in",
}

const textOr = (value: unknown, fallback: string) => typeof value === "string" && value.trim() ? value.trim() : fallback
const cards = (a: ReframeAnalysis) => ({
    fact: textOr(a.game_content?.fact_card, a.fact),
    story: textOr(a.game_content?.story_card, a.story),
    unknown: textOr(a.game_content?.unknown_card, a.unknown),
})
const grounded = (a: ReframeAnalysis) => a.game_content?.choices?.find(c => c.role === "grounded")?.text || a.reframe
const FullTextContext = React.createContext<(label: string, text: string) => void>(() => {})

function useOverflow(text: string) {
    const ref = React.useRef<HTMLParagraphElement | HTMLSpanElement | null>(null)
    const [overflow, setOverflow] = React.useState(false)
    React.useEffect(() => {
        const node = ref.current
        if (!node) return
        const measure = () => setOverflow(node.scrollHeight > node.clientHeight + 1)
        measure()
        const observer = typeof ResizeObserver === "undefined" ? undefined : new ResizeObserver(measure)
        observer?.observe(node)
        return () => observer?.disconnect()
    }, [text])
    return { ref, overflow }
}
function ReadMore({ label, text, className = "" }: { label: string; text: string; className?: string }) {
    const open = React.useContext(FullTextContext)
    return <button type="button" className={`ts-game-read-more ${className}`} aria-label={`Read complete ${label.toLowerCase()}`} title="Read complete text" onClick={() => open(label, text)}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M6 18 18 6M7 6h11v11" /></svg></button>
}

/** Each mounted game can complete only once, including repeated taps / keypresses. */
function useMove({ onComplete, onInteraction }: ReframeGameProps) {
    const done = React.useRef(false)
    const timeout = React.useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
    const completeRef = React.useRef(onComplete)
    completeRef.current = onComplete
    React.useEffect(() => () => { if (timeout.current) clearTimeout(timeout.current) }, [])
    return {
        interact: () => { if (!done.current) onInteraction?.() },
        complete: () => {
            if (done.current) return
            done.current = true
            // Let the final physical move register before the console's CAUGHT transition.
            timeout.current = setTimeout(() => completeRef.current(), 220)
        },
    }
}

function Shell({ title, instruction, children, status, className = "" }: {
    title: string; instruction: string; children: React.ReactNode; status?: string; className?: string
}) {
    const [fullText, setFullText] = React.useState<{ label: string; text: string } | null>(null)
    const dialog = React.useRef<HTMLDialogElement>(null)
    const headingId = React.useId()
    React.useEffect(() => {
        if (fullText && !dialog.current?.open) dialog.current?.showModal()
        else if (!fullText && dialog.current?.open) dialog.current.close()
    }, [fullText])
    return <FullTextContext.Provider value={(label, text) => setFullText({ label, text })}><section className={`ts-game ${className}`} aria-label={title}>
        <div className="ts-game-heading"><span className="ts-game-kicker">CATCH THE MOVE</span><h2>{title}</h2><p>{instruction}</p></div>
        <div className="ts-game-stage">{children}</div>
        <div className="ts-game-status" role="status" aria-live="polite" aria-atomic="true">{status || "Your situation. A little more room."}</div>
        <dialog ref={dialog} className="ts-game-full-text" aria-labelledby={headingId} onClose={() => setFullText(null)}>
            <h3 id={headingId}>{fullText?.label}</h3><p>{fullText?.text}</p><Action onClick={() => { dialog.current?.close(); setFullText(null) }}>Back to the game</Action>
        </dialog>
    </section></FullTextContext.Provider>
}
function Card({ label, text, className = "" }: { label: string; text: string; className?: string }) {
    const { ref, overflow } = useOverflow(text)
    return <div className={`ts-game-card ${overflow ? "ts-game-has-more" : ""} ${className}`}><span className="ts-game-label">{label}</span><p ref={ref as React.Ref<HTMLParagraphElement>}>{text}</p>{overflow && <ReadMore label={label} text={text} />}</div>
}
function Action({ children, onClick, disabled, className = "", label }: {
    children: React.ReactNode; onClick: () => void; disabled?: boolean; className?: string; label?: string
}) {
    return <button type="button" className={`ts-game-action ${className}`} onClick={onClick} disabled={disabled} aria-label={label}>{children}</button>
}
function ChoiceOption({ text, index, onChoose }: { text: string; index: number; onChoose: () => void }) {
    const { ref, overflow } = useOverflow(text)
    return <div className={`ts-game-choice-container ${overflow ? "ts-game-has-more" : ""}`}><Action onClick={onChoose} className="ts-game-choice"><span ref={ref as React.Ref<HTMLSpanElement>} className="ts-game-choice-copy">{text}</span></Action>{overflow && <ReadMore label={`option ${index + 1}`} text={text} />}</div>
}
function FactorOption({ text, share, selected, reviewed, onSelect }: { text: string; share: number; selected: boolean; reviewed: boolean; onSelect: () => void }) {
    const open = React.useContext(FullTextContext)
    return <button type="button" className={`ts-game-factor ${selected ? "ts-game-selected" : ""}`} aria-pressed={selected} onClick={() => { onSelect(); if (text.length > 70) open("Responsibility factor", text) }} aria-label={`${text}, ${share} percent${reviewed ? ", reviewed" : ""}${text.length > 70 ? ". Opens complete factor text." : ""}`}><span>{reviewed ? "✓ " : ""}{text}</span><strong>{share}%</strong></button>
}
function GroundedChoice({ analysis, onChoose, interact, prompt = "Which frame leaves room for the evidence?" }: {
    analysis: ReframeAnalysis; onChoose: () => void; interact: () => void; prompt?: string
}) {
    const [hint, setHint] = React.useState("")
    const right = grounded(analysis)
    // Avoid an ambiguous choice if the response repeats the interpretation verbatim.
    const left = analysis.story === right ? "The interpretation is already a proven fact." : analysis.story
    const rightFirst = React.useRef(analysis.game_family.length % 2 === 0).current
    const options = [{ text: left, correct: false }, { text: right, correct: true }]
    if (rightFirst) options.reverse()
    return <div className="ts-game-choice-block"><p className="ts-game-small">{prompt}</p>
        <div className="ts-game-choices">{options.map((o, i) => <ChoiceOption key={i} index={i} text={o.text} onChoose={() => {
            interact()
            if (o.correct) onChoose()
            else setHint("That adds certainty beyond what is known. Try the frame that keeps the gap open.")
        }} />)}</div>
        {hint && <p className="ts-game-feedback" role="status">{hint}</p>}
    </div>
}

function FactVsGuessGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const c = cards(a)
    const items = [{ text: c.story, category: "story" }, { text: c.fact, category: "fact" }, { text: c.unknown, category: "unknown" }]
    const [index, setIndex] = React.useState(0)
    const [hint, setHint] = React.useState("")
    const [placed, setPlaced] = React.useState<string[]>([])
    const item = items[Math.min(index, 2)]
    const bins = [{ id: "fact", label: "What I know" }, { id: "story", label: "My brain added" }, { id: "unknown", label: "Still unknown" }]
    const place = (id: string) => {
        move.interact()
        if (index >= 3) return
        if (id !== item.category) {
            setHint(item.category === "fact" ? "This is the event described. Keep it with what is known." : item.category === "story" ? "This is a meaning added to the event, rather than the event itself." : "This is information that has not been established yet.")
            return
        }
        setHint("")
        setPlaced(p => [...p, id])
        setIndex(index + 1)
        if (index === 2) move.complete()
    }
    return <Shell title="Fact vs guess" instruction="Place each thought where it belongs." status={hint || `${Math.min(index + 1, 3)} of 3 · Event, meaning, missing information.`}>
        <Card label={index >= 3 ? "SEPARATED" : "WHERE DOES THIS BELONG?"} text={index >= 3 ? c.fact : item.text} className="ts-game-floating" />
        <div className="ts-game-bins">{bins.map(b => <Action key={b.id} onClick={() => place(b.id)} disabled={index >= 3} className={placed.includes(b.id) ? "ts-game-placed" : ""}>
            <span className="ts-game-bin-symbol" aria-hidden="true">{placed.includes(b.id) ? "✓" : b.id === "fact" ? "●" : b.id === "story" ? "+" : "?"}</span>{b.label}
        </Action>)}</div>
    </Shell>
}

function CrystalBallGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [cracked, setCracked] = React.useState(false)
    const [hint, setHint] = React.useState("")
    const prediction = textOr(a.game_content?.prediction_text, a.story)
    return <Shell title="Crystal ball" instruction="A vivid prediction can feel like a fact. Test the certainty." status={hint || (cracked ? "Prediction ≠ evidence. The future stays open." : "Tap the ball to crack the certainty.")}>
        <div className="ts-game-orb-scene"><button type="button" className={`ts-game-orb ${cracked ? "ts-game-cracked" : ""}`} aria-label={cracked ? "Prediction, not established evidence" : `Crack the prediction: ${prediction}`} onClick={() => { move.interact(); setCracked(true) }}>
            <span className="ts-game-orb-light" aria-hidden="true" /><span className="ts-game-label">{cracked ? "A PREDICTION" : "MY BRAIN'S FORECAST"}</span><span className="ts-game-orb-text">{prediction}</span>
            <span className="ts-game-orb-mark" aria-hidden="true">{cracked ? "≠" : "✦"}</span>
        </button>{prediction.length > 130 && <ReadMore label="prediction" text={prediction} />}</div>
        {cracked ? <div className="ts-game-choices"><Action onClick={() => { move.interact(); move.complete() }}>A possible outcome</Action><Action onClick={() => { move.interact(); setHint("Feeling certain does not make a future outcome established evidence.") }}>A proven future</Action></div> : <p className="ts-game-small">What happened is known. What happens next is not decided here.</p>}
    </Shell>
}

function DisasterChainGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const comparable = (text: string) => text.toLocaleLowerCase().replace(/[\s\p{P}]+/gu, " ").trim()
    const links = (a.game_content?.chain_items || [a.story]).filter(t => t.trim() && comparable(t) !== comparable(a.fact) && comparable(t) !== comparable(a.event)).slice(0, 3)
    if (!links.length) links.push(a.story)
    const [cut, setCut] = React.useState<number[]>([])
    const breakLink = (i: number) => {
        move.interact()
        if (cut.includes(i)) return
        const next = [...cut, i]
        setCut(next)
        if (next.length === links.length) move.complete()
    }
    return <Shell title="Disaster chain" instruction="Keep the real event. Break the unsupported leaps." status={`${cut.length} of ${links.length} leaps broken · The factual starting point stays.`}>
        <Card label="THE EVENT STAYS" text={a.fact} className="ts-game-fact-anchor" />
        <div className="ts-game-chain">{links.map((link, i) => <div key={i} className={`ts-game-chain-link ${cut.includes(i) ? "ts-game-cut" : ""} ${link.length > 90 ? "ts-game-chain-has-more" : ""}`}>
            <span className="ts-game-chain-connector" aria-hidden="true">{cut.includes(i) ? "⋯" : "↓"}</span>
            <span className="ts-game-chain-text">{link}</span>
            {link.length > 90 && <ReadMore label="chain link" text={link} className="ts-game-read-inline" />}
            <Action onClick={() => breakLink(i)} disabled={cut.includes(i)} label={`${cut.includes(i) ? "Broken" : "Break unsupported link"}: ${link}`}>{cut.includes(i) ? "Broken ✓" : "Break leap"}</Action>
        </div>)}</div>
    </Shell>
}

function MissingMiddleGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const initial = Number.isFinite(a.game_content?.scale_start) ? Math.min(100, Math.max(0, a.game_content.scale_start!)) : 0
    const [position, setPosition] = React.useState(initial)
    const [moved, setMoved] = React.useState(false)
    return <Shell title="The missing middle" instruction="Move away from the total verdict. Find room for the actual event." status={moved ? "A slider isn't a score of your worth. Choose a grounded frame." : "There is more than one possible position."}>
        <Card label="THE TOTAL VERDICT" text={a.story} />
        <div className="ts-game-scale"><div className="ts-game-scale-labels"><span>Nothing counts</span><span>Everything must be perfect</span></div>
            <input type="range" min="0" max="100" value={position} aria-label="Explore the space between all-or-nothing extremes" aria-valuetext={position === 0 ? "One extreme" : position === 100 ? "The other extreme" : "Room between the extremes"} onChange={e => { move.interact(); const value = Number(e.target.value); setPosition(value); setMoved(value !== initial && value > 0 && value < 100) }} />
            <div className="ts-game-scale-ticks" aria-hidden="true"><span>0</span><span>Room for nuance</span><span>100</span></div>
        </div>
        {moved ? <GroundedChoice analysis={a} onChoose={move.complete} interact={move.interact} /> : <Card label="WHAT ACTUALLY HAPPENED" text={a.fact} className="ts-game-subtle" />}
    </Shell>
}

function OneNotAlwaysGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const words = Array.from(new Set(a.story.match(/\b(?:always|never|everyone|nothing|everything|everybody|every|all)\b|\bno one\b/gi)?.map(w => w.toUpperCase()) || [] )).slice(0, 4)
    if (!words.length) words.push("ONE → ALL")
    const [removed, setRemoved] = React.useState<string[]>([])
    const remove = (word: string) => {
        move.interact()
        if (removed.includes(word)) return
        const next = [...removed, word]
        setRemoved(next)
        if (next.length === words.length) move.complete()
    }
    return <Shell title="One ≠ always" instruction="Remove the words that stretch this event into a universal rule." status={removed.length === words.length ? "Back to this event. One does not establish always." : "An absolute word needs more than one moment of evidence."}>
        <Card label="THE EXPANDED STORY" text={a.story} />
        <div className="ts-game-absolutes">{words.map(word => <button type="button" key={word} className={`ts-game-absolute ${removed.includes(word) ? "ts-game-removed" : ""}`} onClick={() => remove(word)} disabled={removed.includes(word)} aria-label={`Remove the generalisation ${word}`}><span>{word}</span><span aria-hidden="true">{removed.includes(word) ? "✓" : "×"}</span></button>)}</div>
        <Card label="THIS EVENT" text={a.fact} className="ts-game-fact-anchor" />
    </Shell>
}

function FeelingNotEvidenceGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [separated, setSeparated] = React.useState(false)
    const [hint, setHint] = React.useState("")
    const feeling = a.emotion?.filter(Boolean).join(" · ") || "A real feeling"
    return <Shell title="Feeling ≠ evidence" instruction="The feeling is real. Separate it from the conclusion it seems to prove." status={hint || (separated ? "The conclusion still needs evidence." : "Tap the connection to separate feeling and fact.")}>
        <div className={`ts-game-two-zones ${separated ? "ts-game-separated" : ""}`}><Card label="I FEEL" text={feeling} /><button type="button" className="ts-game-connector" aria-label="Separate the feeling from proof of the conclusion" onClick={() => { move.interact(); setSeparated(true) }}>{separated ? "≠" : "="}</button><Card label="MY BRAIN CONCLUDES" text={a.story} /></div>
        <Card label="WHAT I KNOW · THE EVENT STAYS" text={a.fact} className="ts-game-fact-anchor" />
        {separated && <div className="ts-game-choices"><Action onClick={() => { move.interact(); setHint("The feeling matters, but it does not independently prove this interpretation.") }}>The feeling proves it</Action><Action onClick={() => { move.interact(); move.complete() }}>Real feeling. Unconfirmed meaning.</Action></div>}
    </Shell>
}

function PeelLabelGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [peeled, setPeeled] = React.useState(false)
    const origin = React.useRef<{ x: number; y: number } | null>(null)
    const label = textOr(a.game_content?.label_text, a.story)
    const peel = () => { move.interact(); setPeeled(true); move.complete() }
    return <Shell title="Peel the label" instruction="Peel off the identity label. Keep the event underneath." status={peeled ? "An event is not your whole identity." : "Swipe the label away, or tap to peel."}>
        <div className="ts-game-label-scene"><div className="ts-game-person" aria-hidden="true"><span className="ts-game-person-eye" /><span className="ts-game-person-eye" /></div>
            <button type="button" className={`ts-game-sticker ${peeled ? "ts-game-peeled" : ""}`} aria-label={`Peel away the label: ${label}`} onClick={peel} onPointerDown={e => { origin.current = { x: e.clientX, y: e.clientY }; e.currentTarget.setPointerCapture(e.pointerId) }} onPointerUp={e => { if (origin.current && Math.hypot(e.clientX - origin.current.x, e.clientY - origin.current.y) > 28) peel(); origin.current = null }} onPointerCancel={() => { origin.current = null }}><span>{label}</span><span className="ts-game-sticker-corner" aria-hidden="true">↗</span></button>{label.length > 110 && <ReadMore label="identity label" text={label} />}
        </div><Card label="WHAT REMAINS: THE EVENT" text={a.fact} className="ts-game-fact-anchor" />
    </Shell>
}

function WrongScoreboardGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [removed, setRemoved] = React.useState(false)
    return <Shell title="Wrong scoreboard" instruction="Remove a comparison built from different information." status={removed ? "Different data cannot give you a fair verdict." : "You know your whole context. You may only see part of theirs."}>
        <div className="ts-game-scoreboard"><Card label="MY LIFE · KNOWN CONTEXT" text={a.fact} /><span className="ts-game-versus" aria-hidden="true">vs</span><Card label="THEIR HIGHLIGHTS · GAPS" text={a.unknown} /></div>
        <Card label={removed ? "INVALID COMPARISON REMOVED" : "THE BORROWED SCORE"} text={a.story} className={`ts-game-metric ${removed ? "ts-game-metric-off" : ""}`} />
        <Action onClick={() => { move.interact(); if (removed) move.complete(); else setRemoved(true) }}>{removed ? "Return to my own evidence" : "Remove this comparison"}</Action>
    </Shell>
}

function softenRule(rule: string, choice: string): string {
    const standard = rule.replace(/[.!?]+$/u, "").trim()
    const match = /^I\s+(?:(shouldn't|mustn't|should not|must not|ought not to)|(should|must|need to|have to|ought to))\s+(.+)$/iu.exec(standard)
    if (match) {
        const goal = match[3]
        const joining = match[1] ? "not to " : "to "
        const prefix = choice.startsWith("I'd") ? "I'd prefer " : choice.startsWith("I want") ? "I want " : choice.startsWith("It matters") ? "It matters to me " : "I can aim "
        return `${prefix}${joining}${goal}.`
    }
    // Preserve the actual standard when its grammar is not a first-person command.
    const softened = standard.replace(/\b(?:shouldn't|mustn't|should not|must not|ought not to)\b/giu, "not").replace(/\b(?:should|must|ought to|have to|has to|need to|needs to)\b/giu, "").replace(/\s+/gu, " ").trim()
    return `${choice.replace(/…$/u, "")}: “${softened || standard}”.`
}
function ShouldShredderGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [selected, setSelected] = React.useState("")
    const options = ["I'd prefer…", "I want…", "It matters to me…", "I can aim for…"]
    return <Shell title="Should shredder" className="ts-game-should" instruction="Keep what matters. Replace a rigid command with a flexible intention." status={selected ? "A value can guide you without becoming an absolute demand." : "Choose a gentler way to hold the standard."}>
        <Card label="THE RIGID RULE" text={a.story} />
        <div className="ts-game-prefixes">{options.map(option => <button type="button" key={option} className={`ts-game-action ${selected === option ? "ts-game-selected" : ""}`} aria-pressed={selected === option} onClick={() => { move.interact(); setSelected(option) }}>{option}</button>)}</div>
        {selected ? <><Card label="MY STANDARD, HELD MORE FLEXIBLY" text={softenRule(a.story, selected)} className="ts-game-softened" /><Action onClick={() => { move.interact(); move.complete() }}>Keep the value, loosen the rule</Action></> : <p className="ts-game-small">This changes the pressure, not the things you care about.</p>}
    </Shell>
}

function ControlSorterGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const supplied = a.game_content?.control_items?.filter(i => i.text?.trim())
    const items = supplied?.length ? supplied.slice(0, 4) : [{ text: "My next response", controllable: true }, { text: a.unknown, controllable: false }]
    const [index, setIndex] = React.useState(0)
    const [hint, setHint] = React.useState("")
    const item = items[Math.min(index, items.length - 1)]
    const hasInfluence = items.some(i => i.influence && !i.controllable)
    const bins = [{ id: "control", label: "My control" }, ...(hasInfluence ? [{ id: "influence", label: "My influence" }] : []), { id: "outside", label: "Not my control" }]
    const expected = item.controllable ? "control" : item.influence ? "influence" : "outside"
    const sort = (bin: string) => {
        move.interact()
        if (index >= items.length) return
        if (bin !== expected) {
            setHint(expected === "control" ? "This is a response or action you can choose." : expected === "influence" ? "You can affect this, without being able to decide the outcome." : "Your actions may matter here, but you cannot choose this outcome on your own.")
            return
        }
        setHint("")
        setIndex(index + 1)
        if (index + 1 === items.length) move.complete()
    }
    return <Shell title="Control sorter" instruction={hasInfluence ? "Separate choosing, influencing, and outcomes beyond you." : "Put your effort where you can make a choice."} status={hint || `${Math.min(index + 1, items.length)} of ${items.length} · Influence is not the same as control.`}>
        <Card label="WHERE CAN MY EFFORT GO?" text={index >= items.length ? a.fact : item.text} className="ts-game-floating" />
        <div className="ts-game-bins">{bins.map((bin, i) => <Action key={bin.id} onClick={() => sort(bin.id)} disabled={index >= items.length}><span className="ts-game-bin-symbol" aria-hidden="true">{["◎", "↗", "○"][i]}</span>{bin.label}</Action>)}</div>
        <p className="ts-game-small">You can choose your part without having to control every result.</p>
    </Shell>
}

function ResponsibilityPieGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const provided = a.game_content?.responsibility_items || []
    // Do not invent another person, cause, or circumstance. UNKNOWN is always an option.
    const factors = ["My part", ...Array.from(new Set(provided.map(i => i.text.trim()).filter(t => t && !/^(?:me|my (?:part|responsibility|contribution)|unknown|not known|uncertain)(?:\b|$)/i.test(t)))).slice(0, 3), "Unknown"]
    const rangeId = React.useId()
    const [shares, setShares] = React.useState<number[]>(factors.map((_, i) => i === 0 ? 100 : 0))
    const [selected, setSelected] = React.useState(0)
    const [reviewed, setReviewed] = React.useState<number[]>([])
    const review = (i: number) => { move.interact(); setSelected(i); setReviewed(old => old.includes(i) ? old : [...old, i]) }
    const allocate = (amount: number) => {
        move.interact()
        setReviewed(old => old.includes(selected) ? old : [...old, selected])
        setShares(old => {
            const next = [...old]
            next[selected] = amount
            const rest = 100 - amount
            const sum = old.reduce((s, n, i) => s + (i === selected ? 0 : n), 0)
            const others = old.map((_, i) => i).filter(i => i !== selected)
            let left = rest
            others.forEach((i, j) => {
                const n = j === others.length - 1 ? left : sum > 0 ? Math.min(left, Math.round(old[i] / sum * rest)) : (i === (selected === 0 ? factors.length - 1 : 0) ? rest : 0)
                next[i] = n
                left -= n
            })
            return next
        })
    }
    let angle = 0
    const palette = ["var(--gold)", "var(--blue)", "#8e9f91", "#bf927e", "var(--muted)"]
    const gradient = shares.map((n, i) => { const start = angle; angle += n * 3.6; return `${palette[i]} ${start}deg ${angle}deg` }).join(",")
    const allReviewed = reviewed.length === factors.length
    return <Shell title="Responsibility pie" instruction="Review the known factors. Adjust only where the evidence supports it." status={`${reviewed.length} of ${factors.length} factors reviewed · Estimates, not established facts.`}>
        <div className="ts-game-responsibility"><div className="ts-game-pie" style={{ background: `conic-gradient(${gradient})` }} role="img" aria-label={`Responsibility estimate: ${factors.map((f, i) => `${f} ${shares[i]} percent`).join(", ")}`}><span><strong>{shares[0]}%</strong><small>my part</small></span></div>
            <div className="ts-game-factor-list">{factors.map((factor, i) => <FactorOption key={`${factor}-${i}`} text={factor} share={shares[i]} selected={selected === i} reviewed={reviewed.includes(i)} onSelect={() => review(i)} />)}</div>
        </div>
        <div className="ts-game-allocation"><label htmlFor={rangeId}>Estimate for {factors[selected]}: <strong>{shares[selected]}%</strong></label><input id={rangeId} type="range" min="0" max="100" step="5" value={shares[selected]} onChange={e => allocate(Number(e.target.value))} /></div>
        <p className="ts-game-small">100% can stay if the evidence supports it. Unknown is not proof of somebody else's fault.</p>
        <Action onClick={() => { move.interact(); move.complete() }} disabled={!allReviewed}>{allReviewed ? "Keep this considered estimate" : "Review each factor first"}</Action>
    </Shell>
}

function MysteryBoxGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [removed, setRemoved] = React.useState(false)
    const [hint, setHint] = React.useState("")
    return <Shell title="Mystery box" instruction="Remove the assumed outcome. You can leave the box unopened." status={hint || (removed ? "Not knowing is not proof that something bad happened." : "UNKNOWN does not automatically mean BAD NEWS.")}>
        <div className="ts-game-box-scene"><div className="ts-game-box"><span aria-hidden="true">?</span><strong>UNKNOWN</strong></div>
            {!removed && <><button type="button" className={`ts-game-bad-news ${a.story.length > 90 ? "ts-game-has-more" : ""}`} aria-label={`Remove the assumed bad outcome: ${a.story}`} onClick={() => { move.interact(); setRemoved(true) }}><span className="ts-game-label">ASSUMED OUTCOME · REMOVE ×</span><span>{a.story}</span></button>{a.story.length > 90 && <ReadMore label="assumed outcome" text={a.story} className="ts-game-outcome-read" />}</>}
        </div>
        {removed ? <><Card label="WHAT REMAINS UNKNOWN" text={a.unknown} /><div className="ts-game-choices"><Action onClick={() => { move.interact(); move.complete() }}>Leave room for unknown</Action><Action onClick={() => { move.interact(); setHint("The information is still missing. Removing one assumption does not reveal the answer.") }}>The answer is now certain</Action></div></> : <Card label="THE KNOWN EVENT" text={a.fact} className="ts-game-subtle" />}
    </Shell>
}

function FilterCleanerGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [clear, setClear] = React.useState(false)
    const [wiped, setWiped] = React.useState(0)
    const start = React.useRef<number | null>(null)
    const clean = () => { move.interact(); setWiped(100); setClear(true) }
    return <Shell title="Filter cleaner" instruction="Widen the view. Include what is known and what is missing." status={clear ? "A wider frame does not have to be a positive frame." : "Swipe the filter, or use Clear filter."}>
        <div className={`ts-game-filter-frame ${clear ? "ts-game-filter-clear" : ""}`} onPointerDown={e => { if (!clear && !(e.target as HTMLElement).closest("button")) { start.current = e.clientX; e.currentTarget.setPointerCapture(e.pointerId) } }} onPointerMove={e => { if (start.current !== null && !clear) { const n = Math.min(100, Math.abs(e.clientX - start.current) / Math.max(e.currentTarget.clientWidth * .45, 1) * 100); setWiped(n); if (n >= 100) { start.current = null; clean() } } }} onPointerUp={() => { start.current = null }} onPointerCancel={() => { start.current = null }}>
            <Card label="KNOWN" text={a.fact} /><Card label="ALSO PART OF THE PICTURE" text={a.unknown} />
            {!clear && <div className="ts-game-filter" style={{ opacity: 1 - wiped / 130 }}><Card label="THE NARROW VIEW" text={a.story} className="ts-game-filter-story" /><span aria-hidden="true">↔</span></div>}
        </div>
        {clear ? <GroundedChoice analysis={a} onChoose={move.complete} interact={move.interact} prompt="Which view includes the whole picture?" /> : <Action onClick={clean}>Clear filter</Action>}
    </Shell>
}

function IntentMachineGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [opened, setOpened] = React.useState(false)
    const [removed, setRemoved] = React.useState(false)
    return <Shell title="Intent machine" instruction="See how an observed action became an assumed motive." status={removed ? "Behaviour may be known. Intent may still be unknown." : opened ? "Remove the assumption from the machine." : "Open the machine to inspect what it added."}>
        <Card label="BEHAVIOUR IN" text={a.fact} className="ts-game-fact-anchor" />
        <div className={`ts-game-machine ${opened ? "ts-game-machine-open" : ""}`}><span className="ts-game-machine-gear" aria-hidden="true">⚙</span>
            {!opened ? <Action onClick={() => { move.interact(); setOpened(true) }}>Open the brain's machine</Action> : <><button type="button" className={`ts-game-cartridge ${removed ? "ts-game-removed" : ""}`} disabled={removed} onClick={() => { move.interact(); setRemoved(true); move.complete() }} aria-label={`Remove assumed intent: ${a.story}`}><span className="ts-game-label">ASSUMED INTENT</span><span>{a.story}</span><strong>{removed ? "Removed ✓" : "Remove ×"}</strong></button>{a.story.length > 90 && <ReadMore label="assumed intent" text={a.story} className="ts-game-read-inline" />}</>}
        </div><Card label={removed ? "WHAT REMAINS UNKNOWN" : "MEANING OUT"} text={removed ? a.unknown : a.story} className="ts-game-subtle" />
    </Shell>
}

function RejectionFillGame(props: ReframeGameProps) {
    const { analysis: a } = props
    const move = useMove(props)
    const [erased, setErased] = React.useState(false)
    return <Shell title="Rejection fill-in" instruction="Erase the automatic ending. Choose one the evidence can support." status={erased ? "An empty gap is allowed. You do not have to fill it with rejection." : "Your brain filled in the blank. That doesn't make the ending a fact."}>
        <Card label="WHAT HAPPENED" text={a.fact} className="ts-game-fact-anchor" />
        {erased ? <div className="ts-game-fill"><span className="ts-game-label">THEREFORE…</span><div className="ts-game-ending ts-game-ending-erased"><span aria-label="An unfilled gap">________________</span></div></div> : <Card label="THEREFORE…" text={a.story} className="ts-game-fill" />}
        {erased ? <GroundedChoice analysis={a} onChoose={move.complete} interact={move.interact} prompt="What can go in the gap without inventing a motive?" /> : <Action onClick={() => { move.interact(); setErased(true) }}>Erase the automatic ending</Action>}
    </Shell>
}

const ROUTES: Record<ReframeGameFamily, React.ComponentType<ReframeGameProps>> = {
    FACT_VS_GUESS: FactVsGuessGame, CRYSTAL_BALL: CrystalBallGame, DISASTER_CHAIN: DisasterChainGame,
    MISSING_MIDDLE: MissingMiddleGame, ONE_NOT_ALWAYS: OneNotAlwaysGame, FEELING_NOT_EVIDENCE: FeelingNotEvidenceGame,
    PEEL_LABEL: PeelLabelGame, WRONG_SCOREBOARD: WrongScoreboardGame, SHOULD_SHREDDER: ShouldShredderGame,
    CONTROL_SORTER: ControlSorterGame, RESPONSIBILITY_PIE: ResponsibilityPieGame, MYSTERY_BOX: MysteryBoxGame,
    FILTER_CLEANER: FilterCleanerGame, INTENT_MACHINE: IntentMachineGame, REJECTION_FILL: RejectionFillGame,
}

/** AI selects only a known key. Its text is rendered as React text, never markup or code. */
export function ReframeGameRouter(props: ReframeGameProps) {
    const family = props.analysis.game_family
    const Game = Object.prototype.hasOwnProperty.call(ROUTES, family) ? ROUTES[family] : FactVsGuessGame
    return <Game {...props} />
}

export const GAME_CSS = `
.ts-reframe-v2 .ts-game{width:100%;height:100%;min-height:0;display:flex;flex-direction:column;gap:10px;color:var(--text);text-align:left}
.ts-reframe-v2 .ts-game *{box-sizing:border-box}
.ts-reframe-v2 .ts-game-heading{flex:none}
.ts-reframe-v2 .ts-game-kicker,.ts-reframe-v2 .ts-game-label{display:block;font-size:9px;font-weight:700;letter-spacing:.14em;color:var(--gold);line-height:1.45}
.ts-reframe-v2 .ts-game h2{font-size:23px;line-height:1.12;font-weight:650;letter-spacing:-.035em;margin:4px 0 6px}
.ts-reframe-v2 .ts-game-heading p{margin:0;color:var(--muted);font-size:12px;line-height:1.4;max-width:70ch}
.ts-reframe-v2 .ts-game-stage{flex:1;min-height:0;display:flex;flex-direction:column;justify-content:center;gap:12px}
.ts-reframe-v2 .ts-game-status{font-size:10px;line-height:1.35;color:var(--muted);min-height:14px;flex:none}
.ts-reframe-v2 .ts-game-card{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:13px 16px;min-width:0;position:relative}
.ts-reframe-v2 .ts-game-card p{margin:7px 0 0;font-size:15px;line-height:1.38;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-card.ts-game-has-more{padding-right:59px}
.ts-reframe-v2 .ts-game-read-more{position:absolute;right:6px;top:6px;width:44px;height:44px;min-width:44px;min-height:44px;border:1px solid var(--line);border-radius:10px;background:var(--panel);font:inherit;font-size:20px;color:var(--gold);cursor:pointer;display:grid;place-items:center;touch-action:manipulation}
.ts-reframe-v2 .ts-game-read-inline{position:static;flex:none}
.ts-reframe-v2 .ts-game-full-text{width:min(90vw,560px);max-height:80vh;max-height:80svh;border:1px solid var(--line);border-radius:20px;padding:23px;color:var(--text);background:var(--panel);box-shadow:0 20px 70px #00000055;overflow:hidden;font:inherit}
.ts-reframe-v2 .ts-game-full-text[open]{display:flex;flex-direction:column;gap:18px}
.ts-reframe-v2 .ts-game-full-text::backdrop{background:#00000099;backdrop-filter:blur(5px)}
.ts-reframe-v2 .ts-game-full-text h3{font-size:12px;line-height:1.4;color:var(--gold);font-weight:600;letter-spacing:.07em;margin:0;overflow-wrap:anywhere}
.ts-reframe-v2 .ts-game-full-text p{font-size:16px;line-height:1.55;overflow-wrap:anywhere;margin:0;overflow:auto;min-height:0;overscroll-behavior:contain}
.ts-reframe-v2 .ts-game-full-text .ts-game-action{flex:none}
.ts-reframe-v2 .ts-game-subtle{background:transparent}
.ts-reframe-v2 .ts-game-fact-anchor{border-left:3px solid var(--gold)}
.ts-reframe-v2 .ts-game-floating{padding:23px 20px;box-shadow:0 10px 32px #00000012}
.ts-reframe-v2 .ts-game-floating p{font-size:20px;line-height:1.38}
.ts-reframe-v2 .ts-game-action{font:inherit;font-size:12px;font-weight:600;line-height:1.35;color:var(--text);background:var(--panel);border:1px solid var(--line);border-radius:12px;min-height:44px;padding:11px 13px;cursor:pointer;transition:border-color .16s,transform .16s,background .16s;overflow-wrap:anywhere;white-space:normal;touch-action:manipulation}
.ts-reframe-v2 .ts-game-action:hover{border-color:var(--gold);background:color-mix(in srgb,var(--gold) 9%,var(--panel))}
.ts-reframe-v2 .ts-game-action:active{transform:scale(.98)}
.ts-reframe-v2 .ts-game button:focus-visible,.ts-reframe-v2 .ts-game input:focus-visible{outline:2px solid var(--gold);outline-offset:3px}
.ts-reframe-v2 .ts-game button:disabled{cursor:default;opacity:.58;transform:none}
.ts-reframe-v2 .ts-game-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}
.ts-reframe-v2 .ts-game-choice-container{position:relative;min-width:0;display:flex}
.ts-reframe-v2 .ts-game-choice{text-align:left;font-size:12px;font-weight:500;min-height:56px;width:100%}
.ts-reframe-v2 .ts-game-choice-copy{display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-choice-container.ts-game-has-more .ts-game-choice{padding-right:59px}
.ts-reframe-v2 .ts-game-choice-block{display:flex;flex-direction:column;gap:8px}
.ts-reframe-v2 .ts-game-small{font-size:11px;line-height:1.45;margin:0;color:var(--muted)}
.ts-reframe-v2 .ts-game-feedback{font-size:11px;line-height:1.35;margin:0;color:var(--gold)}
.ts-reframe-v2 .ts-game-bins{display:grid;grid-template-columns:repeat(auto-fit,minmax(85px,1fr));gap:9px}
.ts-reframe-v2 .ts-game-bins .ts-game-action{min-height:78px;display:flex;align-items:center;justify-content:center;gap:7px;flex-direction:column;text-align:center}
.ts-reframe-v2 .ts-game-bin-symbol{color:var(--gold);font-size:24px;font-weight:400;line-height:1}
.ts-reframe-v2 .ts-game-placed,.ts-reframe-v2 .ts-game-selected{border-color:var(--gold)!important;background:color-mix(in srgb,var(--gold) 9%,var(--panel))!important}
.ts-reframe-v2 .ts-game-orb-scene{align-self:center;position:relative;display:flex;align-items:center;justify-content:center;width:min(100%,300px)}
.ts-reframe-v2 .ts-game-orb{align-self:center;width:min(100%,300px);height:220px;min-height:130px;border:1px solid color-mix(in srgb,var(--blue) 55%,var(--line));border-radius:50%;background:radial-gradient(ellipse at 35% 25%,color-mix(in srgb,var(--blue) 18%,var(--panel)),var(--panel) 75%);color:var(--text);box-shadow:0 0 34px color-mix(in srgb,var(--blue) 13%,transparent),inset 0 -12px 28px #00000020;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:13px;padding:28px 32px;cursor:pointer;position:relative;touch-action:manipulation;transition:border-radius .22s,transform .22s}
.ts-reframe-v2 .ts-game-orb-text{font:inherit;font-size:17px;line-height:1.4;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-orb-mark{font-size:28px;color:var(--blue);line-height:1}
.ts-reframe-v2 .ts-game-cracked{border-radius:46% 51% 45% 53%;border-style:dashed;transform:rotate(-2deg)}
.ts-reframe-v2 .ts-game-cracked>*{transform:rotate(2deg)}
.ts-reframe-v2 .ts-game-chain{display:flex;flex-direction:column;gap:7px}
.ts-reframe-v2 .ts-game-chain-link{display:grid;grid-template-columns:21px minmax(0,1fr) auto;gap:9px;align-items:center;transition:opacity .2s}
.ts-reframe-v2 .ts-game-chain-link.ts-game-chain-has-more{grid-template-columns:21px minmax(0,1fr) 44px auto}
.ts-reframe-v2 .ts-game-chain-connector{font-size:23px;color:var(--gold);text-align:center}
.ts-reframe-v2 .ts-game-chain-text{font-size:13px;line-height:1.3;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-chain-link .ts-game-action{font-size:11px;padding:9px;min-width:90px}
.ts-reframe-v2 .ts-game-cut .ts-game-chain-text{text-decoration:line-through;color:var(--muted)}
.ts-reframe-v2 .ts-game-cut .ts-game-chain-connector{color:var(--muted)}
.ts-reframe-v2 .ts-game-scale{padding:6px 4px}
.ts-reframe-v2 .ts-game input[type=range]{accent-color:var(--gold);width:100%;height:35px;cursor:pointer;touch-action:pan-x;margin:3px 0}
.ts-reframe-v2 .ts-game-scale-labels,.ts-reframe-v2 .ts-game-scale-ticks{display:flex;justify-content:space-between;gap:16px;font-size:10px;line-height:1.35;color:var(--muted)}
.ts-reframe-v2 .ts-game-scale-labels span{max-width:46%}
.ts-reframe-v2 .ts-game-scale-labels span:last-child{text-align:right}
.ts-reframe-v2 .ts-game-scale-ticks span:nth-child(2){color:var(--gold)}
.ts-reframe-v2 .ts-game-absolutes{display:flex;flex-wrap:wrap;gap:9px;justify-content:center;padding:7px 0}
.ts-reframe-v2 .ts-game-absolute{min-height:52px;font:inherit;font-size:17px;font-weight:700;letter-spacing:.02em;border:1px solid var(--gold);color:var(--text);background:color-mix(in srgb,var(--gold) 8%,var(--panel));border-radius:12px;padding:10px 14px;display:flex;align-items:center;gap:14px;cursor:pointer;touch-action:manipulation}
.ts-reframe-v2 .ts-game-absolute span:last-child{font-weight:400;color:var(--gold);font-size:22px}
.ts-reframe-v2 .ts-game-removed{opacity:.4;text-decoration:line-through}
.ts-reframe-v2 .ts-game-two-zones{display:grid;grid-template-columns:minmax(0,1fr) 44px minmax(0,1fr);gap:6px;align-items:center}
.ts-reframe-v2 .ts-game-two-zones .ts-game-card{height:100%;display:flex;flex-direction:column;justify-content:center}
.ts-reframe-v2 .ts-game-connector{font:inherit;font-size:31px;color:var(--gold);background:transparent;border:1px solid var(--line);border-radius:12px;width:44px;min-height:52px;cursor:pointer;touch-action:manipulation}
.ts-reframe-v2 .ts-game-separated .ts-game-connector{border-color:var(--gold)}
.ts-reframe-v2 .ts-game-label-scene{display:flex;align-items:center;justify-content:center;position:relative;min-height:155px}
.ts-reframe-v2 .ts-game-person{width:150px;height:150px;border-radius:50%;border:1px solid var(--line);background:radial-gradient(circle at 40% 28%,color-mix(in srgb,var(--gold) 18%,var(--panel)),var(--panel) 75%);display:flex;gap:23px;align-items:center;justify-content:center;box-shadow:0 8px 30px #00000014}
.ts-reframe-v2 .ts-game-person-eye{width:6px;height:12px;border-radius:100%;background:var(--text);opacity:.7;transform:translateY(-19px)}
.ts-reframe-v2 .ts-game-sticker{position:absolute;left:50%;top:58%;transform:translate(-50%,-50%) rotate(-5deg);width:min(100%,280px);min-height:65px;background:var(--gold);color:var(--ink);font:inherit;font-size:18px;font-weight:700;padding:13px 25px 13px 17px;border:0;border-radius:4px 4px 16px 4px;cursor:grab;box-shadow:0 8px 22px #00000026;touch-action:none;overflow-wrap:anywhere;transition:transform .22s,opacity .22s}
.ts-reframe-v2 .ts-game-sticker>span:first-child{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-sticker-corner{position:absolute;right:7px;bottom:4px;font-size:17px;opacity:.75}
.ts-reframe-v2 .ts-game-peeled{transform:translate(30%,-100%) rotate(20deg);opacity:0;pointer-events:none}
.ts-reframe-v2 .ts-game-scoreboard{display:grid;grid-template-columns:minmax(0,1fr) 26px minmax(0,1fr);align-items:stretch;gap:5px}
.ts-reframe-v2 .ts-game-scoreboard .ts-game-card{padding:13px 12px}
.ts-reframe-v2 .ts-game-scoreboard p{font-size:13px}
.ts-reframe-v2 .ts-game-versus{align-self:center;color:var(--muted);font-size:12px;text-align:center}
.ts-reframe-v2 .ts-game-metric{text-align:center;padding:13px;border:1px dashed var(--gold);border-radius:12px;transition:opacity .2s}
.ts-reframe-v2 .ts-game-metric p{font-size:15px;margin:8px 0 0;line-height:1.35;overflow-wrap:anywhere}
.ts-reframe-v2 .ts-game-metric-off p{text-decoration:line-through;color:var(--muted)}
.ts-reframe-v2 .ts-game-prefixes{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
.ts-reframe-v2 .ts-game-softened{border-color:color-mix(in srgb,var(--gold) 40%,var(--line))}
.ts-reframe-v2 .ts-game-responsibility{display:grid;grid-template-columns:100px minmax(0,1fr);align-items:center;gap:16px}
.ts-reframe-v2 .ts-game-pie{width:100px;height:100px;border-radius:50%;display:grid;place-items:center;flex:none}
.ts-reframe-v2 .ts-game-pie>span{width:76px;height:76px;background:var(--ink);border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px}
.ts-reframe-v2 .ts-game-pie strong{font-size:20px;font-weight:600}
.ts-reframe-v2 .ts-game-pie small{font-size:9px;color:var(--muted)}
.ts-reframe-v2 .ts-game-factor-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
.ts-reframe-v2 .ts-game-factor{font:inherit;font-size:10px;line-height:1.3;text-align:left;background:var(--panel);color:var(--text);border:1px solid var(--line);border-radius:9px;padding:8px;min-height:44px;display:flex;align-items:center;justify-content:space-between;gap:7px;cursor:pointer;touch-action:manipulation}
.ts-reframe-v2 .ts-game-factor>span{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;overflow-wrap:anywhere}
.ts-reframe-v2 .ts-game-factor>strong{color:var(--gold);white-space:nowrap;font-size:10px}
.ts-reframe-v2 .ts-game-allocation label{font-size:11px;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;color:var(--muted);overflow-wrap:anywhere}
.ts-reframe-v2 .ts-game-allocation label strong{color:var(--text)}
.ts-reframe-v2 .ts-game-box-scene{position:relative;display:flex;align-items:center;justify-content:center;min-height:140px}
.ts-reframe-v2 .ts-game-box{width:148px;height:127px;border:1px solid var(--line);border-top:11px solid color-mix(in srgb,var(--gold) 35%,var(--panel));background:linear-gradient(130deg,var(--panel),color-mix(in srgb,var(--gold) 8%,var(--panel)));border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:9px;transform:rotate(-3deg);box-shadow:8px 8px 0 #0000000c}
.ts-reframe-v2 .ts-game-box>span{font-size:38px;color:var(--gold);line-height:1}
.ts-reframe-v2 .ts-game-box>strong{font-size:11px;letter-spacing:.14em}
.ts-reframe-v2 .ts-game-bad-news{position:absolute;max-width:95%;width:330px;bottom:10px;transform:rotate(3deg);font:inherit;font-size:13px;text-align:left;color:var(--text);background:var(--panel);border:1px solid var(--gold);border-radius:10px;padding:12px 15px;cursor:pointer;box-shadow:0 8px 24px #00000019;touch-action:manipulation}
.ts-reframe-v2 .ts-game-bad-news>span:last-child{display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;overflow-wrap:anywhere;margin-top:6px}
.ts-reframe-v2 .ts-game-bad-news.ts-game-has-more{padding-right:60px}
.ts-reframe-v2 .ts-game-outcome-read{top:auto;bottom:22px;right:max(2.5%,calc(50% - 157px));transform:rotate(3deg)}
.ts-reframe-v2 .ts-game-filter-frame{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;position:relative;overflow:hidden;min-height:132px;border:1px solid var(--line);border-radius:16px;touch-action:none}
.ts-reframe-v2 .ts-game-filter-frame .ts-game-card{border:0;border-radius:0;padding:14px 12px}
.ts-reframe-v2 .ts-game-filter-frame:not(.ts-game-filter-clear)>.ts-game-card .ts-game-read-more{visibility:hidden}
.ts-reframe-v2 .ts-game-filter-frame .ts-game-card p{font-size:13px}
.ts-reframe-v2 .ts-game-filter{position:absolute;inset:0;background:var(--panel);backdrop-filter:blur(12px);display:flex;flex-direction:column;align-items:center;justify-content:center;padding:18px 22px;text-align:center;cursor:ew-resize;transition:opacity .12s}
.ts-reframe-v2 .ts-game-filter .ts-game-filter-story{background:transparent;border:0;max-width:100%;width:100%;padding:0}
.ts-reframe-v2 .ts-game-filter .ts-game-filter-story.ts-game-has-more{padding-right:52px}
.ts-reframe-v2 .ts-game-filter .ts-game-filter-story .ts-game-read-more{right:0;top:0}
.ts-reframe-v2 .ts-game-filter .ts-game-filter-story p{font-size:15px;line-height:1.35;margin:7px 0;overflow-wrap:anywhere}
.ts-reframe-v2 .ts-game-filter>span:last-child{color:var(--gold);font-size:25px}
.ts-reframe-v2 .ts-game-machine{border:1px dashed var(--line);border-radius:16px;padding:13px 16px;display:flex;align-items:center;justify-content:center;gap:16px;min-height:93px;background:repeating-linear-gradient(135deg,transparent,transparent 8px,color-mix(in srgb,var(--line) 30%,transparent) 8px,color-mix(in srgb,var(--line) 30%,transparent) 9px)}
.ts-reframe-v2 .ts-game-machine-gear{font-size:37px;color:var(--gold);transition:transform .35s;line-height:1}
.ts-reframe-v2 .ts-game-machine-open .ts-game-machine-gear{transform:rotate(90deg)}
.ts-reframe-v2 .ts-game-cartridge{font:inherit;color:var(--text);background:var(--panel);border:1px solid var(--gold);padding:10px 13px;min-height:66px;border-radius:10px;text-align:left;cursor:pointer;display:flex;flex:1;min-width:0;flex-direction:column;gap:5px;touch-action:manipulation}
.ts-reframe-v2 .ts-game-cartridge>span:nth-child(2){font-size:13px;line-height:1.35;overflow-wrap:anywhere;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.ts-reframe-v2 .ts-game-cartridge>strong{font-size:10px;color:var(--gold)}
.ts-reframe-v2 .ts-game-fill{padding:10px 15px}
.ts-reframe-v2 .ts-game-ending{border-bottom:1px dashed var(--gold);min-height:49px;display:flex;align-items:center;overflow-wrap:anywhere;padding:5px 0 10px}
.ts-reframe-v2 .ts-game-ending p{font-size:16px;line-height:1.4;margin:0}
.ts-reframe-v2 .ts-game-ending-erased{color:var(--muted)}
@media(max-width:520px){
 .ts-reframe-v2 .ts-game{gap:8px}.ts-reframe-v2 .ts-game-stage{gap:10px}.ts-reframe-v2 .ts-game h2{font-size:21px}.ts-reframe-v2 .ts-game-heading p{font-size:11px}
 .ts-reframe-v2 .ts-game-card{padding:11px 12px}.ts-reframe-v2 .ts-game-card.ts-game-has-more{padding-right:59px}.ts-reframe-v2 .ts-game-card p{font-size:13px}.ts-reframe-v2 .ts-game-floating{padding:20px 15px}.ts-reframe-v2 .ts-game-floating p{font-size:17px}
 .ts-reframe-v2 .ts-game-bins{gap:6px}.ts-reframe-v2 .ts-game-bins .ts-game-action{font-size:10px;padding:10px 6px;min-height:72px}.ts-reframe-v2 .ts-game-choice{font-size:11px;padding:10px}
 .ts-reframe-v2 .ts-game-orb{height:190px;width:min(100%,250px);padding:24px 27px;gap:10px}.ts-reframe-v2 .ts-game-orb-text{font-size:15px}
 .ts-reframe-v2 .ts-game-two-zones{grid-template-columns:minmax(0,1fr) 44px minmax(0,1fr);gap:5px}.ts-reframe-v2 .ts-game-two-zones .ts-game-card{padding:11px 9px}
 .ts-reframe-v2 .ts-game-scoreboard .ts-game-card{padding:11px 9px}.ts-reframe-v2 .ts-game-scoreboard p{font-size:11px}.ts-reframe-v2 .ts-game-scoreboard .ts-game-label{font-size:8px}
 .ts-reframe-v2 .ts-game-responsibility{grid-template-columns:76px minmax(0,1fr);gap:10px}.ts-reframe-v2 .ts-game-pie{width:76px;height:76px}.ts-reframe-v2 .ts-game-pie>span{width:58px;height:58px}.ts-reframe-v2 .ts-game-pie strong{font-size:16px}.ts-reframe-v2 .ts-game-factor{padding:7px;font-size:9px}.ts-reframe-v2 .ts-game-factor-list{gap:5px}
 .ts-reframe-v2 .ts-game-chain-link{gap:5px;grid-template-columns:15px minmax(0,1fr) auto}.ts-reframe-v2 .ts-game-chain-link.ts-game-chain-has-more{grid-template-columns:15px minmax(0,1fr) 44px auto}.ts-reframe-v2 .ts-game-chain-text{font-size:11px}.ts-reframe-v2 .ts-game-chain-link .ts-game-action{min-width:78px;font-size:10px;padding:8px}
 .ts-reframe-v2 .ts-game-filter-frame{gap:6px}.ts-reframe-v2 .ts-game-filter-frame .ts-game-card{padding:12px 9px}.ts-reframe-v2 .ts-game-filter-frame .ts-game-card p{font-size:11px}
 .ts-reframe-v2 .ts-game-status{font-size:9px}.ts-reframe-v2 .ts-game-small{font-size:10px}.ts-reframe-v2 .ts-game-feedback{font-size:10px}
}
@media(max-height:650px) and (min-width:521px){.ts-reframe-v2 .ts-game-stage{gap:8px}.ts-reframe-v2 .ts-game-orb{height:160px;width:240px}.ts-reframe-v2 .ts-game-label-scene{min-height:120px}.ts-reframe-v2 .ts-game-person{width:120px;height:120px}}
@media(max-width:520px) and (max-height:690px){.ts-reframe-v2 .ts-game-should .ts-game-softened p{-webkit-line-clamp:2}.ts-reframe-v2 .ts-game-should .ts-game-stage{gap:8px}}
@media(prefers-reduced-motion:reduce){.ts-reframe-v2 .ts-game *{transition:none!important;animation:none!important;scroll-behavior:auto!important}}
`
