# Reframe V2 validation

The new V2 implementation and generated Framer component were tested in the cloud checkout. Existing tracked repository files have no changes; supplied Reset, Release and legacy Reframe references were read only.

| Check | Observed result |
| --- | --- |
| Frozen dependency installation | `npm ci --cache /workspace/.cache/reframe-npm --no-audit --no-fund` passed. |
| TypeScript | `npm run typecheck` passed with strict checking. |
| Lint | `npm run lint` passed. |
| Unit and contract tests | `npm test`: **233 passed**, 0 failed, 0 skipped. Includes 109 Apps Script tests, 102 engine/API/storage tests, 4 media tests and 18 frontend/backend contract tests. |
| Production build | `npm run build` passed: Vite preview build plus complete typed Framer artifact. |
| Actual standalone deliverable | Generated `deploy/ThinkStillReframeV2.tsx` separately passes strict TypeScript checking, retains Framer layout annotations, and imports only React and Framer. Browser smoke of that regenerated file passed. |
| Browser coverage | **101 unique cases validated**. The full run passed 100 and found one layout defect; the defect was fixed and all 6 affected checks passed, followed by the rebuilt standalone smoke. No unresolved failures or uncaught JavaScript errors. |

## Browser outcomes and the corrected defect

`npm run test:browser` ran 101 cases using Playwright 1.56.1 and the platform's Chromium 151.0.7922.173. It passed 100; the maximum-text Should Shredder case at 320×640 placed its final button 8.5 pixels below the stage. A fix scoped to that game's short mobile layout reduced spacing and retained an accessible full-text reader.

After the fix:

- `npm run test:browser -- --grep 'SHOULD_SHREDDER|composer'`: **6 passed**. Includes long content, three normal viewports, the bright theme and the composer limit/keyboard behavior.
- `npm run test:browser -- --grep 'standalone Framer'`: **1 passed** after regenerating the artifact. Exercises personalised AI-shaped data, game completion, reveal and Save through the complete single-file component.

These runs cover all 101 unique browser cases; this report does not describe the initial full run as 101 passing.

Browser checks exercise:

- Every one of the 15 families at 1280×850, 375×812 and 320×640; incorrect moves must not complete games.
- All 15 games in the bright theme, and all 15 with maximum valid text at 320×640. Controls remain within the stage; full clauses/results remain accessible through text readers.
- All eight brief examples, immediate self-harm/overdose/violence overrides, and preservation of the factual insult in the partner example.
- Malformed AI data, quota/upstream/network failures, timeout, cancellation and local fallback.
- Completion, Helpful/Another angle, bounded retries, Save/Vault restoration, history Previous/Next, share fallback, theme/media synchronization and the 1,800-character composer cap.
- Mocked voice recognition support, permission failure and transcript handling; Enter/Shift+Enter and pointer interactions.

Screenshots of desktop and narrow-phone game/reveal views were also inspected. The optional Playwright-pinned browser download was blocked with HTTP 403; tests used the existing platform Chromium without disabling package, TLS or artifact verification.

## Limits of this validation

AI responses in browser tests are intercepted structured fixtures. Apps Script and Gemini runtime APIs are mocked in backend tests. The cross-module contract checks execute the actual Apps Script validation functions and pass serialized results through the actual frontend validator; they do not invoke a live provider.

The following remain **unrun** because no user-owned deployment/key or relevant hardware was supplied:

- A live Gemini call, current account/model free-tier eligibility and quota.
- A published Apps Script web app's browser redirects/CORS from the actual Framer origin.
- Framer's hosted editor/canvas and published component.
- Real microphone hardware/permissions, mobile virtual keyboards, Safari/iOS and other browser engines.
- Publication of the updated cloud environment and restoration into a new task.

Follow `REFRAME_SETUP.txt` for those checks before replacing the legacy component. Gemini credentials belong only in Apps Script Script Properties. The implementation contains no paid provider fallback.

## Reusable environment configuration

The tested `install_script` and V2 `start_skill` were saved in the cloud environment draft. The existing static asset startup instructions were preserved. Network policy, repositories and secret requirements were not changed. Saving the draft does not publish it or restart services; review and save it in environment settings, then publish when desired.
