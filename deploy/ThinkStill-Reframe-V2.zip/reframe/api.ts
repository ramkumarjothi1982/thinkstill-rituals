import { detectSafety, INPUT_LIMIT, localAnalysis, validateAnalysis } from "./engine"
import { GAME_FAMILIES, PATTERNS } from "./types"
import type { AnalysisResult, ReframeRequest, SafetyResult } from "./types"

export const REQUEST_TIMEOUT_MS = 10_000

export function isAppsScriptUrl(value: string): boolean {
    if (value.length > 512) return false
    try {
        const url = new URL(value)
        return url.protocol === "https:" && url.hostname === "script.google.com" && !url.username && !url.password && !url.port && !url.search && !url.hash && /^\/macros\/s\/[A-Za-z0-9_-]{10,200}\/exec$/u.test(url.pathname)
    } catch {
        return false
    }
}

function safetyFromResponse(value: unknown): SafetyResult | null {
    if (typeof value !== "object" || value === null || Array.isArray(value)) return null
    const candidate = value as Record<string, unknown>
    if ((candidate.kind !== "immediate" && candidate.kind !== "threat") || typeof candidate.title !== "string" || !candidate.title.trim() || candidate.title.length > 80 || typeof candidate.message !== "string" || !candidate.message.trim() || candidate.message.length > 420) return null
    return { kind: candidate.kind, title: candidate.title.trim(), message: candidate.message.trim() }
}

/** Apps Script accepts a simple text/plain POST; no browser secret or CORS preflight. */
export async function analyseReframe(url: string, request: ReframeRequest, signal?: AbortSignal): Promise<AnalysisResult> {
    const input = request.input.trim().slice(0, INPUT_LIMIT)
    const safety = detectSafety(request.input)
    if (safety) return { kind: "safety", safety }
    const previous_patterns = request.previous_patterns.filter(value => (PATTERNS as readonly string[]).includes(value)).slice(-8)
    const previous_game_families = request.previous_game_families.filter(value => (GAME_FAMILIES as readonly string[]).includes(value)).slice(-8)
    const fallback = (): AnalysisResult => ({ kind: "analysis", analysis: localAnalysis(input, previous_patterns, previous_game_families), source: "local" })
    if (!input || request.input.length > INPUT_LIMIT || !isAppsScriptUrl(url) || !/^[A-Za-z0-9_-]{8,96}$/u.test(request.session_id) || signal?.aborted || typeof fetch === "undefined") return fallback()

    const controller = new AbortController()
    let timer: ReturnType<typeof setTimeout> | undefined
    let onAbort: (() => void) | undefined
    try {
        const cancelled = new Promise<never>((_, reject) => {
            onAbort = () => { controller.abort(); reject(new Error("cancelled")) }
            signal?.addEventListener("abort", onAbort, { once: true })
            timer = setTimeout(() => { controller.abort(); reject(new Error("timeout")) }, REQUEST_TIMEOUT_MS)
        })
        const operation = async (): Promise<AnalysisResult> => {
            const response = await fetch(url, {
                method: "POST", headers: { "Content-Type": "text/plain;charset=UTF-8" },
                body: JSON.stringify({ input, session_id: request.session_id, previous_patterns, previous_game_families }),
                signal: controller.signal, credentials: "omit", redirect: "follow", cache: "no-store",
            })
            if (!response.ok) return fallback()
            const size = response.headers.get("content-length")
            if (size && Number(size) > 64_000) return fallback()
            const body = await response.text()
            if (body.length > 64_000) return fallback()
            const parsed: unknown = JSON.parse(body)
            if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) return fallback()
            const result = parsed as Record<string, unknown>
            if (result.ok === false && result.safety !== undefined) {
                const backendSafety = safetyFromResponse(result.safety)
                return backendSafety ? { kind: "safety", safety: backendSafety } : fallback()
            }
            if (result.ok !== true) return fallback()
            const analysis = validateAnalysis(result.analysis)
            return analysis ? { kind: "analysis", analysis, source: "ai" } : fallback()
        }
        return await Promise.race([operation(), cancelled])
    } catch {
        return fallback()
    } finally {
        if (timer !== undefined) clearTimeout(timer)
        if (onAbort) signal?.removeEventListener("abort", onAbort)
    }
}
