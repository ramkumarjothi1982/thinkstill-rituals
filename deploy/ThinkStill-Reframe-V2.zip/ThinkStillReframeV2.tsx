import * as React from "react"
import { addPropertyControls, ControlType } from "framer"
import { analyseReframe } from "./reframe/api"
import { bubbleForPattern, compatibleGames, plotTwist } from "./reframe/engine"
import { GAME_CSS, ReframeGameRouter } from "./reframe/games"
import { safeMediaUrl, useSharedMedia, useSharedTheme } from "./reframe/media"
import { loadHistory, loadMomentum, loadVault, saveHistory, saveMomentum, saveVault, shareText, toSaved } from "./reframe/storage"
import type { BubbleSlug, ReframeAnalysis, ReframeSession, SafetyResult, SavedReframe } from "./reframe/types"
import { CONSOLE_CSS } from "./reframe/styles"

type Theme = "dark" | "bright"
type Props = {
    reframeAiUrl?: string; assetBaseUrl?: string; defaultTheme?: Theme
    transitionMedia?: string; avatarGlitch?: string; avatarSync?: string; avatarPatch?: string
    avatarDrop?: string; avatarStill?: string; avatarRush?: string; avatarLoopie?: string
    style?: React.CSSProperties
}
type Phase =
    | { kind: "idle" }
    | { kind: "transition"; input: string; attempt: number }
    | { kind: "playing" | "success" | "reveal"; session: ReframeSession; attempt: number }
    | { kind: "safety"; safety: SafetyResult }
type SpeechEvent = { results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }
type Recognizer = {
    lang: string; continuous: boolean; interimResults: boolean
    onresult: ((event: SpeechEvent) => void) | null
    onerror: ((event: { error: string }) => void) | null
    onend: (() => void) | null; start: () => void; stop: () => void; abort: () => void
}
type SpeechWindow = Window & { SpeechRecognition?: new () => Recognizer; webkitSpeechRecognition?: new () => Recognizer }
const DEFAULT_ASSETS = "https://raw.githubusercontent.com/ramkumarjothi1982/thinkstill-rituals/main"
const guides = [
    ["PUT IT INTO WORDS", "What happened? What did your brain make it mean?"],
    ["CATCH THE PATTERN", "Your situation becomes a tiny game."],
    ["PLAY THE TRICK", "Spot the part your brain added."],
    ["FLIP THE FRAME", "Leave with a grounded thought to keep."],
]
function anonymousId(): string {
    return typeof crypto !== "undefined" && typeof crypto.randomUUID === "function"
        ? crypto.randomUUID() : `ts-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`
}
function haptic() {
    if (typeof navigator !== "undefined" && typeof navigator.vibrate === "function") navigator.vibrate(12)
}
function Arrow() {
    return <svg viewBox="0 0 20 20" width="17" height="17" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" aria-hidden="true"><path d="M5 15 15 5M5 5h10v10" /></svg>
}
function Icon({ name }: { name: "save" | "vault" | "share" | "help" | "other" | "mic" | "history" | "close" }) {
    const paths = {
        save: "M6 3h12v18l-6-4-6 4V3Z", vault: "M4 5h16v15H4V5Zm3-3h10v3M8 10h8m-4 0v5",
        share: "M15 3h6v6m0-6L10 14M9 5H4v15h15v-5", help: "m5 12 4 4 10-10",
        other: "M4 8h11a5 5 0 0 1 0 10h-2M4 8l4-4M4 8l4 4", mic: "M9 5a3 3 0 0 1 6 0v7a3 3 0 0 1-6 0V5ZM6 10v2a6 6 0 0 0 12 0v-2M12 18v4m-4 0h8",
        history: "M3 11a9 9 0 1 1 3 8M3 4v7h7m2-5v6l4 3", close: "m6 6 12 12M6 18 18 6",
    }
    return <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={paths[name]} /></svg>
}
function Avatar({ url, bubble, positive = false }: { url: string; bubble: BubbleSlug; positive?: boolean }) {
    const [failed, setFailed] = React.useState(false)
    React.useEffect(() => setFailed(false), [url])
    return <div className={`ts-avatar ${positive ? "ts-avatar-positive" : ""}`} aria-label={`${bubble} ThinkStill character`}>
        {url && !failed ? <img src={url} alt="" draggable={false} onError={() => setFailed(true)} /> : <span aria-hidden="true">✦</span>}
    </div>
}
function Transition({ url, video }: { url: string; video: boolean }) {
    const [failed, setFailed] = React.useState(false)
    React.useEffect(() => setFailed(false), [url])
    return <div className="ts-transition" role="status" aria-label="Preparing your reframe">
        {url && !failed && (video
            ? <video src={url} autoPlay muted playsInline loop aria-hidden="true" onError={() => setFailed(true)} />
            : <img src={url} alt="" onError={() => setFailed(true)} />)}
        <div className="ts-eclipse ts-eclipse-thinking"><i /><span /></div>
        <p>CATCHING THE THREAD<span>One moment. Your words become the game.</span></p>
    </div>
}

/**
 * @framerIntrinsicWidth 1100
 * @framerIntrinsicHeight 780
 * @framerSupportedLayoutWidth any
 * @framerSupportedLayoutHeight any
 */
export default function ThinkStillReframeV2(props: Props) {
    const { reframeAiUrl = "", defaultTheme = "dark", assetBaseUrl = DEFAULT_ASSETS, style } = props
    const [theme, setTheme] = useSharedTheme(defaultTheme)
    const shared = useSharedMedia()
    const [phase, setPhase] = React.useState<Phase>({ kind: "idle" })
    const [input, setInput] = React.useState("")
    const [history, setHistory] = React.useState<ReframeSession[]>([])
    const [vault, setVault] = React.useState<SavedReframe[]>([])
    const [momentum, setMomentum] = React.useState(0)
    const [panel, setPanel] = React.useState<"vault" | "history" | "frame" | null>(null)
    const panelTitleId = React.useId()
    const [message, setMessage] = React.useState("")
    const [guideIndex, setGuideIndex] = React.useState(0)
    const [listening, setListening] = React.useState(false)
    const [canListen, setCanListen] = React.useState(false)
    const [shareCopy, setShareCopy] = React.useState("")
    const historyRef = React.useRef<ReframeSession[]>([])
    const vaultRef = React.useRef<SavedReframe[]>([])
    const requestRef = React.useRef<AbortController | null>(null)
    const requestNumber = React.useRef(0)
    const sessionId = React.useRef("")
    const speechRef = React.useRef<Recognizer | null>(null)
    const composerRef = React.useRef<HTMLTextAreaElement>(null)
    const stageRef = React.useRef<HTMLElement>(null)
    const panelRef = React.useRef<HTMLDivElement>(null)
    const restoreFocus = React.useRef<HTMLElement | null>(null)
    const current = "session" in phase ? phase.session : null
    const longFrame = !!current && (current.analysis.reframe.length > 190 || current.analysis.keep.length > 100)
    const attempt = "attempt" in phase ? phase.attempt : 0
    const busy = phase.kind === "transition" || phase.kind === "success"
    const bubble = current ? bubbleForPattern(current.analysis.primary_pattern) : "glitch"
    const overrideAvatar: Record<BubbleSlug, string | undefined> = {
        glitch: props.avatarGlitch, sync: props.avatarSync, patch: props.avatarPatch, drop: props.avatarDrop,
        still: props.avatarStill, rush: props.avatarRush, loopie: props.avatarLoopie,
    }
    const avatarUrl = safeMediaUrl(shared.avatars?.[bubble]) || safeMediaUrl(overrideAvatar[bubble])
        || `${assetBaseUrl.replace(/\/$/, "")}/bubble-expressions/${bubble}_E${phase.kind === "reveal" ? "62" : "17"}.webp`
    const mediaKey = `${bubble}_overlay_1`
    const transitionUrl = safeMediaUrl(shared.overlays?.[mediaKey]) || safeMediaUrl(props.transitionMedia)
    const transitionVideo = !!shared.videoOverlayKeys?.includes(mediaKey) || /\.(mp4|webm|mov|m4v|ogv)(?:[?#]|$)/i.test(transitionUrl)

    React.useEffect(() => {
        const loadedHistory = loadHistory(); const loadedVault = loadVault()
        historyRef.current = loadedHistory; vaultRef.current = loadedVault
        setHistory(loadedHistory); setVault(loadedVault); setMomentum(loadMomentum())
        sessionId.current = anonymousId()
        const win = window as SpeechWindow
        setCanListen(!!(win.SpeechRecognition || win.webkitSpeechRecognition))
        return () => { requestRef.current?.abort(); speechRef.current?.abort() }
    }, [])
    React.useEffect(() => {
        if (phase.kind !== "idle") return
        const timer = setInterval(() => setGuideIndex(value => (value + 1) % guides.length), 5000)
        return () => clearInterval(timer)
    }, [phase.kind])
    React.useEffect(() => {
        if (phase.kind !== "success") return
        const timer = setTimeout(() => setPhase(previous => previous.kind === "success" ? { ...previous, kind: "reveal" } : previous), 850)
        return () => clearTimeout(timer)
    }, [phase.kind])
    React.useEffect(() => {
        if (phase.kind === "playing" || phase.kind === "reveal" || phase.kind === "safety") stageRef.current?.focus()
    }, [phase.kind])
    React.useEffect(() => {
        if (!message) return
        const timer = setTimeout(() => setMessage(""), 4500)
        return () => clearTimeout(timer)
    }, [message])
    React.useEffect(() => {
        if (!panel) return
        restoreFocus.current = document.activeElement as HTMLElement
        const first = panelRef.current?.querySelector<HTMLButtonElement>("button")
        first?.focus()
        return () => restoreFocus.current?.focus()
    }, [panel])

    function persistHistory(items: ReframeSession[]) {
        const capped = items.slice(0, 30)
        historyRef.current = capped; setHistory(capped)
        if (!saveHistory(capped)) setMessage("This browser couldn't keep your history. You can still play.")
    }
    function persistVault(items: SavedReframe[]) {
        const capped = items.slice(0, 50)
        vaultRef.current = capped; setVault(capped)
        const saved = saveVault(capped)
        if (!saved) setMessage("Saved for this visit. This browser couldn't keep it for next time.")
        return saved
    }
    function reward(points: number) {
        setMomentum(previous => { const next = Math.min(99999, previous + points); saveMomentum(next); return next })
    }
    function reset() {
        requestNumber.current++; requestRef.current?.abort(); speechRef.current?.stop()
        setPhase({ kind: "idle" }); setInput(""); setPanel(null); setShareCopy("")
        requestAnimationFrame(() => composerRef.current?.focus())
    }
    async function submit(text = input, retry = 0, previous: ReframeSession | null = null) {
        const clean = text.trim()
        if (!clean) { setMessage("Put what happened into a few words first."); composerRef.current?.focus(); return }
        if (clean.length > 1800) { setMessage("Keep this frame under 1,800 characters."); return }
        speechRef.current?.stop(); requestRef.current?.abort()
        const controller = new AbortController(); requestRef.current = controller
        const ticket = ++requestNumber.current
        setPanel(null); setShareCopy(""); setMessage("")
        setPhase({ kind: "transition", input: clean, attempt: retry })
        const recent = previous ? [previous, ...historyRef.current.filter(item => item.id !== previous.id)] : []
        try {
            const result = await analyseReframe(reframeAiUrl, {
                input: clean, session_id: sessionId.current || anonymousId(),
                previous_patterns: [...new Set(recent.map(item => item.analysis.primary_pattern))].slice(0, 8),
                previous_game_families: [...new Set(recent.map(item => item.gameFamily))].slice(0, 8),
            }, controller.signal)
            if (ticket !== requestNumber.current || controller.signal.aborted) return
            if (result.kind === "safety") { setPhase({ kind: "safety", safety: result.safety }); return }
            let analysis = result.analysis
            // Even a successful AI reply must take a different compatible angle on retry.
            if (previous && analysis.game_family === previous.gameFamily && analysis.primary_pattern === previous.analysis.primary_pattern) {
                const alternative = compatibleGames(analysis.primary_pattern).find(game => !recent.some(item => item.gameFamily === game))
                if (alternative) analysis = { ...analysis, game_family: alternative }
                else { setPhase({ kind: "reveal", session: previous, attempt: 2 }); setMessage("Let's start fresh with what feels missing from this frame."); return }
            }
            const session: ReframeSession = {
                id: anonymousId(), input: clean, analysis, gameFamily: analysis.game_family,
                completed: false, createdAt: Date.now(), source: result.source,
            }
            setPhase({ kind: "playing", session, attempt: retry })
        } catch {
            if (ticket !== requestNumber.current || controller.signal.aborted) return
            setPhase({ kind: "idle" }); setMessage("Couldn't catch that thread. Your words are still here — try again.")
        }
    }
    function complete() {
        if (phase.kind !== "playing") return
        const finished = { ...phase.session, completed: true }
        if (!historyRef.current.some(item => item.id === finished.id)) {
            persistHistory([finished, ...historyRef.current]); reward(10)
        }
        haptic(); setPhase({ kind: "success", session: finished, attempt: phase.attempt })
    }
    function feedback(value: "helpful" | "not-helpful") {
        if (!current || phase.kind !== "reveal") return
        const updated = { ...current, feedback: value }
        persistHistory(historyRef.current.map(item => item.id === current.id ? updated : item))
        setPhase({ ...phase, session: updated })
        if (value === "helpful") {
            if (!current.feedback) reward(2)
            haptic(); setMessage("That shift is yours. Keep it.")
        } else if (attempt < 2) {
            setInput(current.input); void submit(current.input, attempt + 1, updated)
        } else setMessage("Two new angles tried. Add what's missing or start a fresh frame.")
    }
    function saveCurrent() {
        if (!current) return
        if (vaultRef.current.some(item => item.id === current.id)) { setMessage("This frame is already in your Vault."); return }
        if (persistVault([toSaved(current), ...vaultRef.current])) setMessage("Saved to your Vault on this device.")
        haptic()
    }
    async function share(item: ReframeSession | SavedReframe) {
        const text = shareText(item)
        try {
            if (navigator.share) { await navigator.share({ title: "ThinkStill · A new frame", text }); return }
            if (navigator.clipboard?.writeText) { await navigator.clipboard.writeText(text); setMessage("Frame copied. Share it wherever you like."); return }
        } catch (error) {
            if (error instanceof DOMException && error.name === "AbortError") return
        }
        setShareCopy(text); setMessage("Copy your frame from the text below.")
    }
    function openSaved(item: SavedReframe) {
        const existing = historyRef.current.find(row => row.id === item.id)
        const analysis: ReframeAnalysis = {
            ok: true, event: item.event, interpretation: item.interpretation, primary_pattern: item.primaryPattern,
            secondary_patterns: item.secondaryPatterns, fact: item.fact, story: item.story, unknown: item.unknown,
            reframe: item.reframe, keep: item.keep, game_family: item.gameFamily, game_content: {}, confidence: 0,
        }
        const session = existing || { id: item.id, input: item.input, analysis, gameFamily: item.gameFamily, completed: true, createdAt: item.createdAt, source: "local" as const }
        setPanel(null); setPhase({ kind: "reveal", session, attempt: retryCount(item.input) }); setInput(item.input)
    }
    function retryCount(text: string) {
        return Math.min(2, historyRef.current.filter(item => item.input === text && item.feedback === "not-helpful").length)
    }
    function navigateHistory(direction: "older" | "newer") {
        if (!current) return
        const index = history.findIndex(item => item.id === current.id)
        const next = history[index + (direction === "older" ? 1 : -1)]
        if (index < 0 || !next) return
        setInput(next.input); setPhase({ kind: "reveal", session: next, attempt: retryCount(next.input) }); setShareCopy("")
    }
    function toggleMic() {
        if (listening) { speechRef.current?.stop(); return }
        const win = window as SpeechWindow; const Speech = win.SpeechRecognition || win.webkitSpeechRecognition
        if (!Speech) { setMessage("Voice isn't available in this browser. You can type your words."); return }
        const recognition = new Speech(); speechRef.current = recognition
        const base = input.trim()
        recognition.lang = "en-AU"; recognition.continuous = false; recognition.interimResults = true
        recognition.onresult = event => {
            const text = Array.from(event.results, result => result[0].transcript).join(" ")
            setInput(`${base}${base && text ? " " : ""}${text}`.slice(0, 1800))
        }
        recognition.onerror = event => {
            setListening(false)
            setMessage(event.error === "not-allowed" ? "Microphone permission wasn't granted. You can type instead." : "Couldn't hear that clearly. Try again or type it.")
        }
        recognition.onend = () => { setListening(false); speechRef.current = null }
        try { recognition.start(); setListening(true); setMessage("Listening. Review your words before sending.") }
        catch { setMessage("Voice couldn't start. Type your words or try again."); setListening(false) }
    }
    const historyIndex = current ? history.findIndex(item => item.id === current.id) : -1
    const isSaved = !!current && vault.some(item => item.id === current.id)
    return <div className={`ts-reframe-v2 ts-theme-${theme} ts-phase-${phase.kind}`} style={style}>
        <style>{CONSOLE_CSS + GAME_CSS}</style>
        <header className="ts-topbar">
            <div className="ts-brand"><div className="ts-mini-eclipse" aria-hidden="true" /><div><b>THINKSTILL</b><span>REFRAME CONSOLE <i>V2</i></span></div></div>
            <div className="ts-top-controls">
                <button type="button" className="ts-theme-control" aria-label={`Switch to ${theme === "dark" ? "bright" : "dark"} theme`} onClick={() => setTheme(theme === "dark" ? "bright" : "dark")}><span aria-hidden="true">{theme === "dark" ? "◐" : "◑"}</span>{theme === "dark" ? "DARK" : "BRIGHT"}</button>
                <button type="button" className="ts-icon-button" aria-label="Open history" onClick={() => setPanel("history")} disabled={busy}><Icon name="history" /></button>
                <button type="button" className="ts-icon-button" aria-label="Open Vault" onClick={() => setPanel("vault")} disabled={busy}><Icon name="vault" /></button>
            </div>
        </header>
        <div className="ts-momentum"><span><i aria-hidden="true" /> A LITTLE SHIFT GOES A LONG WAY</span><span aria-label={`${momentum} momentum points`}>MOMENTUM <b>{momentum}</b></span></div>
        <main className="ts-stage" ref={stageRef} tabIndex={-1} aria-label="Reframe stage">
            {phase.kind === "idle" && <div className="ts-idle">
                <div className="ts-idle-orbit"><div className="ts-eclipse"><i /><span /></div><Avatar url={avatarUrl} bubble={bubble} /></div>
                <div className="ts-idle-copy"><span className="ts-eyebrow">A TINY GAME. A DIFFERENT VIEW.</span><h1>Catch your brain<br /><em>in the act.</em></h1><p>Tell us what happened. Then catch what your brain added.</p></div>
                <div className="ts-guide"><span>{String(guideIndex + 1).padStart(2, "0")} / 04</span><div><b>{guides[guideIndex][0]}</b><p>{guides[guideIndex][1]}</p></div><div className="ts-guide-dots" aria-hidden="true">{guides.map((_, index) => <i key={index} className={index === guideIndex ? "active" : ""} />)}</div></div>
                <div className="ts-quickstart" aria-label="Optional examples"><span>Need a start?</span>{[["A silent reply", "My boss hasn't replied. She must be unhappy with my work."], ["One mistake", "I made one mistake in the presentation. I'm terrible at my job."], ["An unknown outcome", "I don't know whether I got the job. That probably means I failed."]].map(([label, text]) => <button type="button" key={label} onClick={() => { setInput(text); composerRef.current?.focus() }}>{label}<span aria-hidden="true"><Arrow /></span></button>)}</div>
            </div>}
            {phase.kind === "transition" && <Transition url={transitionUrl} video={transitionVideo} />}
            {phase.kind === "playing" && <div className="ts-play-layout">
                <div className="ts-game-context"><Avatar url={avatarUrl} bubble={bubble} /><div><span className="ts-eyebrow">YOUR REFRAME</span><p>{phase.session.source === "local" ? "Let's catch the closest pattern." : "Your words. A new angle."}</p></div></div>
                <div className="ts-game-host" key={phase.session.id}><ReframeGameRouter analysis={phase.session.analysis} onComplete={complete} onInteraction={haptic} /></div>
                {phase.session.source === "local" && reframeAiUrl && <small className="ts-fallback-note">Couldn't sharpen the frame fully this time. Your words still lead.</small>}
            </div>}
            {phase.kind === "success" && <div className="ts-success" role="status"><div className="ts-eclipse ts-eclipse-success"><i /><span /></div><Avatar url={avatarUrl} bubble={bubble} positive /><span className="ts-eyebrow">CAUGHT</span><h2>{phase.session.analysis.primary_pattern}</h2><p>That's the move.</p></div>}
            {phase.kind === "reveal" && <div className="ts-reveal-layout">
                <div className="ts-reveal-avatar"><Avatar url={avatarUrl} bubble={bubble} positive /><span>{bubble.toUpperCase()}</span></div>
                <article className={`ts-reveal ${longFrame ? "ts-reveal-long" : ""}`}>
                    <div className="ts-caught"><span className="ts-eyebrow">CAUGHT</span><h2>{phase.session.analysis.primary_pattern}</h2></div>
                    <div className="ts-plot"><span className="ts-eyebrow">PLOT TWIST</span><p>{plotTwist(phase.session.analysis)}</p></div>
                    <div className="ts-new-frame"><span className="ts-eyebrow">NEW FRAME</span><p>{phase.session.analysis.reframe}</p></div>
                    <div className="ts-keep"><span className="ts-eyebrow">KEEP</span><p>{phase.session.analysis.keep}</p></div>
                    {longFrame && <button type="button" className="ts-read-frame" onClick={() => setPanel("frame")}>Read full frame</button>}
                    {shareCopy && <textarea className="ts-share-copy" aria-label="Frame text to copy" readOnly value={shareCopy} onFocus={event => event.currentTarget.select()} />}
                    <div className="ts-reveal-nav"><button type="button" aria-label="Previous completed reframe" disabled={historyIndex < 0 || historyIndex >= history.length - 1} onClick={() => navigateHistory("older")}>← Previous</button><button type="button" className="ts-new-button" onClick={reset}>New reframe <span aria-hidden="true"><Arrow /></span></button><button type="button" aria-label="Next completed reframe" disabled={historyIndex <= 0} onClick={() => navigateHistory("newer")}>Next →</button></div>
                </article>
                <aside className="ts-action-rail" aria-label="Reframe actions">
                    <button type="button" aria-label={isSaved ? "Frame saved" : "Save reframe"} aria-pressed={isSaved} onClick={saveCurrent}><Icon name="save" /><span>{isSaved ? "Saved" : "Save"}</span></button>
                    <button type="button" aria-label="Open Vault" onClick={() => setPanel("vault")}><Icon name="vault" /><span>Vault</span></button>
                    <button type="button" aria-label="Helpful" aria-pressed={phase.session.feedback === "helpful"} onClick={() => feedback("helpful")}><Icon name="help" /><span>Helpful</span></button>
                    <button type="button" aria-label="Not helpful, try another angle" disabled={attempt >= 2} onClick={() => feedback("not-helpful")}><Icon name="other" /><span>Another angle</span></button>
                    <button type="button" aria-label="Share reframe" onClick={() => void share(phase.session)}><Icon name="share" /><span>Share</span></button>
                </aside>
            </div>}
            {phase.kind === "safety" && <div className="ts-safety" role="alert"><span className="ts-eyebrow">SUPPORT FIRST</span><div className="ts-safety-ring" aria-hidden="true">✦</div><h2>{phase.safety.title}</h2><p>{phase.safety.message}</p><p className="ts-safety-note">If there is immediate danger, contact local emergency services now. If you can, reach someone nearby you trust.</p><button type="button" className="ts-primary" onClick={reset}>Back to the console</button></div>}
        </main>
        <footer className="ts-footer">
            <form className={`ts-composer ${listening ? "ts-listening" : ""}`} onSubmit={event => { event.preventDefault(); if (!busy) void submit() }}>
                <textarea ref={composerRef} aria-label="What happened and what are you telling yourself it means?" value={input} maxLength={1800} rows={2} disabled={busy} placeholder="What happened — and what are you telling yourself it means?" onChange={event => setInput(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) { event.preventDefault(); if (!busy) void submit() } }} />
                <button type="button" className="ts-mic" aria-label={listening ? "Stop microphone" : "Start microphone"} aria-pressed={listening} disabled={busy} onClick={toggleMic} title={canListen ? "Speak, then review and send" : "Voice may not be available in this browser"}><Icon name="mic" /></button>
                <button type="submit" className="ts-send" disabled={busy || !input.trim()} aria-label="Catch this thought"><span>{busy ? "CATCHING" : "CATCH IT"}</span><span aria-hidden="true"><Arrow /></span></button>
            </form>
            <div className="ts-footer-note"><span>FACT. STORY. UNKNOWN. <b>A BETTER FRAME.</b></span><span>{input.length ? `${input.length} / 1800` : "YOUR WORDS LEAD."}</span></div>
        </footer>
        <div className={`ts-toast ${message ? "ts-toast-visible" : ""}`} role="status" aria-live="polite">{message}</div>
        {panel && <div className="ts-modal-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) setPanel(null) }}>
            <div className="ts-panel" role="dialog" aria-modal="true" aria-labelledby={panelTitleId} ref={panelRef} onKeyDown={event => {
                if (event.key === "Escape") { setPanel(null); return }
                if (event.key !== "Tab") return
                const items = Array.from(panelRef.current?.querySelectorAll<HTMLElement>("button:not(:disabled), textarea, [tabindex='0']") || [])
                const first = items[0]; const last = items[items.length - 1]
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus() }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
            }}>
                <header><div><span className="ts-eyebrow">THINKSTILL · {panel === "frame" ? "YOUR COMPLETE FRAME" : "ON THIS DEVICE"}</span><h2 id={panelTitleId}>{panel === "vault" ? "Your Vault" : panel === "frame" ? "A little more room" : "Your shifts"}</h2></div><button type="button" aria-label="Close panel" className="ts-icon-button" onClick={() => setPanel(null)}><Icon name="close" /></button></header>
                {panel !== "frame" && <p className="ts-panel-note">{panel === "vault" ? "Personal frames you've chosen to keep. Up to 50." : "Your last 30 completed frames."} Saved in this browser, without account sync.</p>}
                <div className="ts-panel-list">
                    {panel === "frame" && current && <div className="ts-full-frame">{[["WHAT I KNOW", current.analysis.fact], ["WHAT MY BRAIN ADDED", current.analysis.story], ["STILL UNKNOWN", current.analysis.unknown], ["NEW FRAME", current.analysis.reframe], ["KEEP", current.analysis.keep]].map(([label, text]) => <section key={label}><span className="ts-eyebrow">{label}</span><p>{text}</p></section>)}</div>}
                    {panel === "vault" && !vault.length && <p className="ts-empty">Your next good frame can live here. Play a game, then tap Save.</p>}
                    {panel === "history" && !history.length && <p className="ts-empty">Your completed frames will appear here.</p>}
                    {panel === "vault" ? vault.map(item => <article key={item.id}><button type="button" className="ts-entry" onClick={() => openSaved(item)}><span>{item.primaryPattern}</span><p>{item.keep}</p><time>{new Date(item.createdAt).toLocaleDateString()}</time></button><button type="button" className="ts-remove" aria-label={`Remove saved reframe ${item.keep}`} onClick={() => persistVault(vaultRef.current.filter(row => row.id !== item.id))}>Remove</button></article>)
                        : panel === "history" && history.map(item => <article key={item.id}><button type="button" className="ts-entry" onClick={() => { setPhase({ kind: "reveal", session: item, attempt: retryCount(item.input) }); setInput(item.input); setPanel(null) }}><span>{item.analysis.primary_pattern}</span><p>{item.analysis.keep}</p><time>{new Date(item.createdAt).toLocaleDateString()}</time></button></article>)}
                </div>
                {(panel === "vault" ? vault.length > 0 : panel === "history" && history.length > 0) && <button type="button" className="ts-clear" onClick={() => {
                    if (window.confirm(`Clear all ${panel === "vault" ? "saved frames" : "history"} on this device?`)) {
                        if (panel === "vault") persistVault([]); else persistHistory([])
                    }
                }}>Clear {panel === "vault" ? "Vault" : "history"}</button>}
            </div>
        </div>}
    </div>
}

ThinkStillReframeV2.defaultProps = { defaultTheme: "dark", assetBaseUrl: DEFAULT_ASSETS }
const imageControl = (title: string) => ({ type: ControlType.File, title, allowedFileTypes: ["webp", "png", "jpg", "gif", "avif"] })
addPropertyControls(ThinkStillReframeV2, {
    reframeAiUrl: { type: ControlType.String, title: "Reframe AI URL", defaultValue: "", placeholder: "https://script.google.com/macros/s/…/exec", description: "Optional Apps Script deployment. Leave empty for local frames." },
    assetBaseUrl: { type: ControlType.String, title: "Asset Base URL", defaultValue: DEFAULT_ASSETS },
    defaultTheme: { type: ControlType.Enum, title: "Initial Theme", options: ["dark", "bright"], optionTitles: ["Dark", "Bright"], defaultValue: "dark" },
    transitionMedia: { type: ControlType.File, title: "Transition", allowedFileTypes: ["mp4", "webm", "png", "jpg", "webp", "gif"] },
    avatarGlitch: imageControl("Avatar Glitch"), avatarSync: imageControl("Avatar Sync"), avatarPatch: imageControl("Avatar Patch"),
    avatarDrop: imageControl("Avatar Drop"), avatarStill: imageControl("Avatar Still"), avatarRush: imageControl("Avatar Rush"), avatarLoopie: imageControl("Avatar Loopie"),
})
