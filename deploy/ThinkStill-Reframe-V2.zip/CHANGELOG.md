# Changelog

## Reframe V2 — 2026-10-08

Built a new Reframe experience alongside legacy ThinkStill assets and the supplied Reset, Release and old Reframe references. The central loop is free-text input, fact/story/unknown analysis, a personalised predefined microgame, and Caught / Plot Twist / New Frame / Keep.

### Added

- Modular `ThinkStillReframeV2.tsx` source and a complete standalone Framer bundle generated at `deploy/ThinkStillReframeV2.tsx`. The bundle preserves TypeScript types and Framer annotations and is independently typechecked during the build.
- All 15 core game families with bounded data, explicit completion and shared interfaces.
- Strong TypeScript types and the controlled 20-pattern ThinkStill taxonomy.
- A separate complete `ThinkStill_Reframe_Gemini.gs` backend with configurable Gemini model, structured JSON validation and lightweight abuse limits. The API key belongs in Apps Script Script Properties, never in browser code.
- A conservative local fallback for absent AI configuration, quota, timeout, network failure and invalid model responses. There is no paid-provider fallback.
- Safety-first routing for obvious immediate danger and threats, plus instructions and validation intended to preserve factual mistreatment rather than reframe it away.
- Helpful feedback, bounded Another Angle retries, momentum, personalised saves, Vault, completed-session history and readable sharing.
- Browser speech-input controls, dark/bright behaviour, reduced-motion handling, keyboard/touch interactions and responsive console layouts.
- Full-text game readers and Read Full Frame for long results, with reading contained inside the console experience. Separate history/Vault clearing and individual Vault removal support local privacy controls.
- A Vite development preview, TypeScript/lint/build commands and meaningful engine, storage, backend and browser validation tooling.
- Simple deployment instructions, a pattern/game map and architecture documentation.

### ThinkStill visual references

The new console references the obsidian, ivory and solar-gold palette; eclipse and diamond-ring motifs; circular bubble avatars; glass controls; typography; restrained animation; and the existing dark/bright and Reset-shared media behaviour. Existing bubble-expression images can be used without loading the old ritual library.

### Legacy boundaries

Reset, Release and the old Reframe references remain unchanged. Existing ritual data and asset files are preserved. V2 does not copy the old Cloudflare Worker, Airtable selector, old endpoint URL, ritual/video selection, required Vimeo/YouTube media, obsolete loaders, video metadata or monolithic legacy state. Circle membership and payment logic remain outside Reframe.

### Validation and external setup

See `VALIDATION.md` for checks actually run and browser setup. The build provides a complete component and backend, but local tests do not establish a live Framer deployment, a working user-owned Apps Script/Gemini project, current Google free-tier availability or real microphone hardware. The owner must complete and verify those external steps in `REFRAME_SETUP.txt` before replacing the old Reframe. The old component is not deleted automatically.

### Optional future work

- Authenticated server-side membership checks if a public anonymous endpoint is insufficient.
- Opt-in account-synced saves with an explicit privacy design.
- More games and better-tested language coverage across additional languages.
- Further assistive-technology and real-device checks in the published Framer page.
- Optional transition media where it improves the experience; videos remain unnecessary for the core game loop.
